MASTER RESPONDE v1.17.2

CORREÇÕES PRINCIPAIS

1. TESTE EM SEGUNDO PLANO
O WebView oculto agora recebe largura e altura reais de tela antes de carregar
o Dashboard Sigma. Isso evita que o SPA do Sigma deixe de montar a seção
Teste Rápido em segundo plano.

O motor também aguarda explicitamente a seção Teste Rápido aparecer antes de
acionar a mesma rotina usada pelo botão GERAR TESTE.

2. ASSINATURA ESTÁVEL
O workflow deixou de gerar APK debug com chave aleatória.
Agora ele compila APK release usando uma chave fixa armazenada em GitHub Secrets.

Secrets obrigatórios:
ANDROID_KEYSTORE_BASE64
ANDROID_KEYSTORE_PASSWORD
ANDROID_KEY_ALIAS
ANDROID_KEY_PASSWORD

IMPORTANTE:
A primeira APK assinada com a chave estável ainda exige desinstalar a versão antiga
uma última vez, pois a APK já instalada possui outra assinatura.
A partir dessa instalação, todas as próximas versões assinadas com a mesma chave
podem ser instaladas por cima preservando os dados.

VERSÃO
1.17.2
versionCode 46
