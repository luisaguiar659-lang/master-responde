MASTER RESPONDE v1.17.14

Correções de concorrência para múltiplos contatos/leads:

- fila de respostas continua isolada por conversa;
- chaves persistentes da fila e do anti-eco agora usam SHA-256 truncado,
  evitando colisões práticas de hashCode entre contatos;
- deduplicação privada persistente agora é armazenada por contactKey,
  sem depender de um único "último conteúdo" global;
- mensagens idênticas vindas de pessoas diferentes não se bloqueiam;
- em grupos, quando MessagingStyle fornece o remetente, a deduplicação usa
  grupo + remetente + evento + conteúdo;
- anti-eco em grupos só é aplicado a mensagens sem remetente, padrão usado
  para mensagens de saída do próprio aparelho;
- conteúdo sensível de mensagens não é persistido pelo anti-eco, apenas hash.

Base: v1.17.13.
