MASTER RESPONDE v1.17.13

Correções desta revisão:
- Mantida a correção da v1.17.12 que limpa o teste pendente ao finalizar.
- Adicionada proteção contra eco das respostas enviadas pelo próprio bot via RemoteInput.
- O listener ignora, por 30 segundos, uma mensagem idêntica que acabou de ser enviada pelo bot na mesma conversa.
- A proteção usa somente SHA-256 do conteúdo; não persiste usuário, senha, link ou texto do teste.
- A proteção foi aplicada aos fluxos privados e de grupos.
- Corrigido BUILD-WORKFLOW.yml, que ainda apontava para a v1.17.6 e para uma estrutura de diretórios antiga.
- Workflow agora compila diretamente o projeto atual e gera MASTER-RESPONDE-v1.17.13.apk.

Versão:
- versionName 1.17.13
- versionCode 57

Observação de validação:
- O ambiente local usado nesta revisão não contém Android SDK/Gradle instalados, então a compilação APK final deve ser executada pelo workflow do GitHub ou em um ambiente Android configurado.
