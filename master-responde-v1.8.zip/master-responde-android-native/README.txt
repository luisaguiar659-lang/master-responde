MASTER RESPONDE v1.8

BASE ESTÁVEL:
- dashboard
- Bot + acesso às notificações
- autorespostas privadas
- regras configuráveis
- categorias com várias respostas
- @infor em grupos
- MASTERFLIX login + sessão
- geração automática de teste em segundo plano

ÚNICA FUNÇÃO NOVA:
NOVA REVENDA + 50 CRÉDITOS INICIAIS

GATILHOS PRIVADOS:
- quero ser revenda
- quero ser uma revenda
- quero revenda
- ser revenda

FLUXO:
1. Cliente envia "Quero ser Revenda".
2. Bot envia o link de cadastro configurado no módulo REVENDAS.
3. Cliente conclui o cadastro e envia o mesmo e-mail usado.
4. MASTER RESPONDE valida o formato do e-mail.
5. Procura esse e-mail exato em:
   https://masterflix.sigmab.pro/#/resellers
6. Se encontrar, responde:
   "Encontrei o cadastro <email>. Responda CONFIRMAR..."
7. Cliente responde CONFIRMAR.
8. MASTER RESPONDE localiza novamente o e-mail exato.
9. Lê o saldo atual antes de qualquer envio.
10. Abre o botão de adicionar créditos.
11. Preenche exatamente 50.
12. Marca a operação como tentada ANTES do clique final.
13. Clica no botão final UMA ÚNICA VEZ.
14. Verifica o novo saldo.
15. Só confirma sucesso se:
    saldo_final = saldo_inicial + 50

PROTEÇÃO CONTRA CRÉDITO DUPLICADO:
- depois do clique final, o app nunca repete automaticamente o envio;
- se não conseguir confirmar o saldo final, muda para REVISÃO NECESSÁRIA;
- informa o cliente;
- exige conferência manual no MASTERFLIX antes de qualquer nova tentativa.

PÓS-PAGO:
- não existe etapa de pagamento;
- não existe aprovação financeira;
- são adicionados 50 créditos diretamente após CONFIRMAR.

MÓDULO REVENDAS:
- o link de cadastro é editável;
- o link atual já vem preenchido como padrão;
- mostra o último status da automação;
- o valor inicial permanece fixo em +50.

SEGURANÇA:
- e-mail pendente e e-mail vinculado são salvos usando SecureStore/Android Keystore;
- não tenta resolver CAPTCHA;
- não contorna "Verificado" ou proteção antibot;
- se a sessão MASTERFLIX expirar, é necessário abrir o app e renovar manualmente.

AINDA NÃO EXISTE:
- créditos +50 para revenda já vinculada (entra na próxima etapa);
- opção 7 automática do @infor para revenda existente.
