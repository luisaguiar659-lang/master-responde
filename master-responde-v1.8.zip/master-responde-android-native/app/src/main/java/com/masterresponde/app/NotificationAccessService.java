package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NotificationAccessService extends NotificationListenerService {

    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    private static final Map<String, Long> RECENT = new ConcurrentHashMap<>();
    private static final Map<String, Long> GROUP_MENU_OPEN = new ConcurrentHashMap<>();
    private static final Map<String, Long> GROUP_RECENT = new ConcurrentHashMap<>();
    private static final Object SEND_LOCK = new Object();

    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final long GROUP_MENU_TIMEOUT = 120000L;
    private static final long SEQUENCE_DELAY = 400L;

    private static final String[] GROUP_CATEGORIES = new String[]{
            "Tutoriais",
            "Promoções e Planos",
            "Aplicativos Parceiros",
            "Banners",
            "Avisos",
            "Apresentação do Servidor"
    };

    private static final String GROUP_MENU =
            "🤖 *MASTER RESPONDE — CENTRAL DE SUPORTE*\n\n" +
            "1️⃣ Tutoriais\n" +
            "2️⃣ Promoções e Planos\n" +
            "3️⃣ Aplicativos Parceiros\n" +
            "4️⃣ Banners\n" +
            "5️⃣ Avisos\n" +
            "6️⃣ Apresentação do Servidor\n" +
            "7️⃣ Solicitar 50 Créditos\n" +
            "8️⃣ Gerar Teste\n" +
            "0️⃣ Falar com Suporte\n\n" +
            "Atalhos diretos:\n" +
            "@infor 1\n" +
            "@infor planos\n" +
            "@infor tutoriais";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (!WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        SharedPreferences prefs =
                getSharedPreferences("master_responde", MODE_PRIVATE);

        if (!prefs.getBoolean("bot_enabled", false)) return;

        Notification notification = sbn.getNotification();
        if (notification == null || notification.extras == null) return;

        String notificationKey =
                sbn.getKey() == null ? "no-key" : sbn.getKey();

        boolean isGroup =
                isGroupNotification(notification);

        if (isGroup) {
            handleGroupNotification(
                    sbn,
                    notification,
                    notificationKey,
                    prefs
            );
            return;
        }

        CharSequence value =
                notification.extras.getCharSequence(
                        Notification.EXTRA_TEXT
                );

        if (value == null) return;

        String incoming =
                normalize(value.toString());

        if (incoming.isEmpty()) return;

        handlePrivate(
                notification,
                notificationKey,
                incoming,
                prefs
        );
    }

    private void handleGroupNotification(
            StatusBarNotification sbn,
            Notification notification,
            String notificationKey,
            SharedPreferences prefs
    ) {
        List<GroupMessage> messages =
                extractRecentGroupMessages(
                        notification,
                        sbn.getPostTime()
                );

        if (!messages.isEmpty()) {
            for (GroupMessage message : messages) {
                handleGroup(
                        notification,
                        notificationKey,
                        message.text,
                        message.eventId,
                        prefs
                );
            }
            return;
        }

        // Fallback para aparelhos onde EXTRA_MESSAGES não é fornecido.
        CharSequence value =
                notification.extras.getCharSequence(
                        Notification.EXTRA_TEXT
                );

        if (value == null) return;

        String incoming =
                normalize(value.toString());

        if (incoming.isEmpty()) return;

        handleGroup(
                notification,
                notificationKey,
                incoming,
                "fallback|" + sbn.getPostTime(),
                prefs
        );
    }

    private List<GroupMessage> extractRecentGroupMessages(
            Notification notification,
            long postTime
    ) {
        List<GroupMessage> result =
                new ArrayList<>();

        if (notification == null
                || notification.extras == null) {
            return result;
        }

        Parcelable[] rawMessages =
                notification.extras.getParcelableArray(
                        Notification.EXTRA_MESSAGES
                );

        if (rawMessages == null
                || rawMessages.length == 0) {
            return result;
        }

        for (int i = 0; i < rawMessages.length; i++) {
            Parcelable raw =
                    rawMessages[i];

            if (!(raw instanceof Bundle)) {
                continue;
            }

            Bundle bundle =
                    (Bundle) raw;

            CharSequence textValue =
                    bundle.getCharSequence("text");

            if (textValue == null) {
                continue;
            }

            String text =
                    normalize(
                            textValue.toString()
                    );

            if (text.isEmpty()) {
                continue;
            }

            long messageTime =
                    bundle.getLong(
                            "time",
                            0L
                    );

            // O WhatsApp costuma devolver também mensagens antigas
            // no histórico da notificação. Só olhamos as recentes.
            if (messageTime > 0L
                    && postTime > 0L
                    && postTime - messageTime > 30000L) {
                continue;
            }

            String eventId;

            if (messageTime > 0L) {
                eventId =
                        "msg|"
                                + messageTime;
            } else {
                // Fallback: posição + postTime da atualização atual.
                eventId =
                        "idx|"
                                + i
                                + "|"
                                + postTime;
            }

            result.add(
                    new GroupMessage(
                            text,
                            eventId
                    )
            );
        }

        return result;
    }

    private static class GroupMessage {
        final String text;
        final String eventId;

        GroupMessage(
                String text,
                String eventId
        ) {
            this.text = text;
            this.eventId = eventId;
        }
    }

    private boolean isGroupNotification(Notification notification) {
        if (notification == null || notification.extras == null) {
            return false;
        }

        // Indicador oficial quando o WhatsApp o fornece.
        if (notification.extras.getBoolean(
                Notification.EXTRA_IS_GROUP_CONVERSATION,
                false
        )) {
            return true;
        }

        // Em alguns aparelhos/versões do WhatsApp Business,
        // a PRIMEIRA mensagem do grupo ainda não vem com o boolean acima.
        // O título da conversa, porém, já vem preenchido.
        CharSequence conversationTitle =
                notification.extras.getCharSequence(
                        Notification.EXTRA_CONVERSATION_TITLE
                );

        return conversationTitle != null
                && conversationTitle.toString().trim().length() > 0;
    }

    private void handleGroup(
            Notification notification,
            String notificationKey,
            String incoming,
            String eventId,
            SharedPreferences prefs
    ) {
        String groupKey = groupConversationKey(notification);

        // Proteção lógica específica para grupos.
        // O WhatsApp pode disparar duas callbacks da mesma mensagem
        // com notificationKey diferente.
        // v1.5.5: deduplicação ATÔMICA.
        // Duas callbacks podem chegar praticamente juntas.
        // Agora a checagem e o registro acontecem dentro da mesma trava.
        if (isDuplicateGroupMessage(
                notification,
                incoming,
                eventId,
                prefs
        )) {
            return;
        }

        if ("@infor".equals(incoming)) {
            GROUP_MENU_OPEN.put(groupKey, System.currentTimeMillis());

            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "group_menu|" + groupKey,
                    incoming,
                    GROUP_MENU
            );
            return;
        }

        // Permite executar direto no mesmo comando:
        // @infor 1 / @infor planos / @infor tutoriais...
        if (incoming.startsWith("@infor ")) {
            String command = incoming.substring("@infor ".length()).trim();

            executeGroupCommand(
                    notification,
                    notificationKey,
                    command,
                    prefs
            );

            GROUP_MENU_OPEN.put(groupKey, System.currentTimeMillis());
            return;
        }

        // Mantém o menu aberto para várias escolhas seguidas sem novo @infor.
        Long openedAt = GROUP_MENU_OPEN.get(groupKey);
        if (openedAt == null) return;

        if (System.currentTimeMillis() - openedAt > GROUP_MENU_TIMEOUT) {
            GROUP_MENU_OPEN.remove(groupKey);
            return;
        }

        if (isRecognizedGroupCommand(incoming)) {
            executeGroupCommand(
                    notification,
                    notificationKey,
                    incoming,
                    prefs
            );

            GROUP_MENU_OPEN.put(groupKey, System.currentTimeMillis());
        }
    }

    private boolean isRecognizedGroupCommand(String command) {
        String c = normalize(command);

        return c.equals("0")
                || c.equals("1")
                || c.equals("2")
                || c.equals("3")
                || c.equals("4")
                || c.equals("5")
                || c.equals("6")
                || c.equals("7")
                || c.equals("8")
                || c.contains("tutorial")
                || c.contains("plano")
                || c.contains("promoc")
                || c.contains("aplicativo")
                || c.equals("apps")
                || c.contains("banner")
                || c.contains("aviso")
                || c.contains("apresent")
                || c.contains("credito")
                || c.contains("teste")
                || c.contains("suporte");
    }

    private boolean isDuplicateGroupMessage(
            Notification notification,
            String incoming,
            String eventId,
            SharedPreferences prefs
    ) {
        String stableGroupKey =
                stableGroupKey(notification);

        String fingerprint =
                stableGroupKey
                        + "|"
                        + eventId
                        + "|"
                        + incoming;

        synchronized (SEND_LOCK) {
            long now =
                    System.currentTimeMillis();

            Long memoryTime =
                    GROUP_RECENT.get(
                            fingerprint
                    );

            if (memoryTime != null
                    && now - memoryTime < 120000L) {
                return true;
            }

            String stored =
                    prefs.getString(
                            "recent_group_messages",
                            ""
                    );

            String marker =
                    "\n"
                            + fingerprint
                            + "\n";

            String paddedStored =
                    "\n"
                            + stored
                            + "\n";

            if (paddedStored.contains(marker)) {
                GROUP_RECENT.put(
                        fingerprint,
                        now
                );
                return true;
            }

            // Reserva ANTES de responder.
            GROUP_RECENT.put(
                    fingerprint,
                    now
            );

            String updated;

            if (stored.isEmpty()) {
                updated = fingerprint;
            } else {
                updated =
                        stored
                                + "\n"
                                + fingerprint;
            }

            // Mantém somente as últimas 30 mensagens vistas.
            String[] parts =
                    updated.split("\\n");

            if (parts.length > 30) {
                StringBuilder builder =
                        new StringBuilder();

                for (int i = parts.length - 30;
                     i < parts.length;
                     i++) {

                    if (builder.length() > 0) {
                        builder.append('\n');
                    }

                    builder.append(
                            parts[i]
                    );
                }

                updated =
                        builder.toString();
            }

            prefs.edit()
                    .putString(
                            "recent_group_messages",
                            updated
                    )
                    .commit();

            if (GROUP_RECENT.size() > 300) {
                GROUP_RECENT.clear();

                GROUP_RECENT.put(
                        fingerprint,
                        now
                );
            }

            return false;
        }
    }

    private String stableGroupKey(
            Notification notification
    ) {
        if (notification == null) {
            return "grupo";
        }

        String shortcutId =
                notification.getShortcutId();

        if (shortcutId != null
                && !shortcutId.trim().isEmpty()) {
            return "shortcut|"
                    + shortcutId.trim();
        }

        if (notification.extras != null) {
            CharSequence conversation =
                    notification.extras.getCharSequence(
                            Notification.EXTRA_CONVERSATION_TITLE
                    );

            if (conversation != null
                    && conversation.length() > 0) {
                return "title|"
                        + normalize(
                                conversation.toString()
                        );
            }
        }

        return "grupo";
    }

    private void executeGroupCommand(
            Notification notification,
            String notificationKey,
            String command,
            SharedPreferences prefs
    ) {
        String c = normalize(command);
        int option = resolveGroupOption(c);

        if (option >= 1 && option <= 6) {
            String categoryName = GROUP_CATEGORIES[option - 1];

            JSONArray responses = categoryResponsesByName(
                    prefs,
                    categoryName
            );

            if (responses.length() == 0) {
                sendSingleWithProtection(
                        notification,
                        notificationKey,
                        "group_missing|" + option,
                        c,
                        "⚠️ A categoria \"" + categoryName +
                                "\" ainda não foi configurada no MASTER RESPONDE."
                );
            } else {
                sendSequenceWithProtection(
                        notification,
                        notificationKey,
                        "group_category|" + option,
                        c,
                        responses
                );
            }

            return;
        }

        if (option == 7 || option == 8) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "group_future|" + option,
                    c,
                    "🔒 Essa opção será liberada nas próximas etapas do MASTER RESPONDE."
            );
            return;
        }

        if (option == 0) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "group_support",
                    c,
                    "👤 Um atendente continuará o suporte."
            );
            return;
        }

        sendSingleWithProtection(
                notification,
                notificationKey,
                "group_unknown",
                c,
                "⚠️ Opção não reconhecida. Envie @infor para ver o menu."
        );
    }

    private int resolveGroupOption(String command) {
        String c = normalize(command);

        if ("1".equals(c) || c.contains("tutorial")) return 1;
        if ("2".equals(c) || c.contains("plano") || c.contains("promoc")) return 2;

        if ("3".equals(c)
                || c.contains("aplicativo")
                || "apps".equals(c)
                || c.contains("app parceiro")) {
            return 3;
        }

        if ("4".equals(c) || c.contains("banner")) return 4;
        if ("5".equals(c) || c.contains("aviso")) return 5;
        if ("6".equals(c) || c.contains("apresent")) return 6;
        if ("7".equals(c) || c.contains("credito")) return 7;
        if ("8".equals(c) || c.contains("teste")) return 8;
        if ("0".equals(c) || c.contains("suporte")) return 0;

        return -1;
    }

    private void handlePrivate(
            Notification notification,
            String notificationKey,
            String incoming,
            SharedPreferences prefs
    ) {
        if ("teste bot".equals(incoming)) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "fixed_test",
                    incoming,
                    "✅ MASTER RESPONDE ativo e funcionando."
            );
            return;
        }

        String resellerContactKey =
                privateContactKey(
                        notification
                );

        if (handlePendingResellerFlow(
                notification,
                resellerContactKey,
                incoming,
                prefs
        )) {
            return;
        }

        if (isNewResellerRequest(incoming)) {
            beginNewResellerFlow(
                    notification,
                    resellerContactKey,
                    prefs
            );
            return;
        }

        if (isTestRequest(incoming)) {
            startMasterflixTest(
                    notification,
                    notificationKey,
                    incoming,
                    prefs
            );
            return;
        }

        try {
            JSONArray rules = new JSONArray(
                    prefs.getString("text_rules", "[]")
            );

            for (int i = 0; i < rules.length(); i++) {
                JSONObject rule = rules.optJSONObject(i);
                if (rule == null) continue;

                String trigger = normalize(
                        rule.optString("trigger", "")
                );

                boolean exact = rule.optBoolean("exact", false);
                if (trigger.isEmpty()) continue;

                boolean match = exact
                        ? incoming.equals(trigger)
                        : incoming.contains(trigger);

                if (!match) continue;

                String ruleId = rule.optString("id", String.valueOf(i));
                String categoryId = rule.optString("category_id", "");

                if (!categoryId.isEmpty()) {
                    JSONArray responses = categoryResponsesById(
                            prefs,
                            categoryId
                    );

                    if (responses.length() > 0) {
                        sendSequenceWithProtection(
                                notification,
                                notificationKey,
                                "category_rule|" + ruleId,
                                incoming,
                                responses
                        );
                    }

                    return;
                }

                String response = rule.optString("reply", "").trim();

                if (!response.isEmpty()) {
                    sendSingleWithProtection(
                            notification,
                            notificationKey,
                            "rule|" + ruleId,
                            incoming,
                            response
                    );
                }

                return;
            }

        } catch (Exception ignored) {
        }
    }

    private boolean isNewResellerRequest(
            String incoming
    ) {
        String value =
                normalize(
                        incoming
                );

        return "quero ser revenda".equals(value)
                || "quero ser uma revenda".equals(value)
                || "quero revenda".equals(value)
                || "ser revenda".equals(value);
    }

    private void beginNewResellerFlow(
            Notification notification,
            String contactKey,
            SharedPreferences prefs
    ) {
        String state =
                prefs.getString(
                        "reseller_state_" + contactKey,
                        ""
                );

        if ("REVIEW_REQUIRED".equals(state)) {
            WhatsAppReply.send(
                    this,
                    notification,
                    "⚠️ Existe uma operação anterior dessa revenda que precisa ser conferida manualmente no MASTERFLIX antes de iniciar outra."
            );

            return;
        }

        if ("COMPLETE".equals(state)) {
            WhatsAppReply.send(
                    this,
                    notification,
                    "✅ Este WhatsApp já possui uma revenda vinculada no MASTER RESPONDE."
            );

            return;
        }

        String signupLink =
                prefs.getString(
                        "reseller_signup_link",
                        ResellersActivity.DEFAULT_SIGNUP_LINK
                );

        prefs.edit()
                .putString(
                        "reseller_state_" + contactKey,
                        "WAITING_EMAIL"
                )
                .putString(
                        "last_reseller_status",
                        "Revenda: aguardando e-mail do cadastro"
                )
                .apply();

        WhatsAppReply.send(
                this,
                notification,
                "🚀 Para ser Revenda, faça seu cadastro pelo link:\n\n" +
                        signupLink +
                        "\n\nDepois de concluir o cadastro, envie aqui *o mesmo e-mail* que você usou."
        );
    }

    private boolean handlePendingResellerFlow(
            Notification notification,
            String contactKey,
            String incoming,
            SharedPreferences prefs
    ) {
        String state =
                prefs.getString(
                        "reseller_state_" + contactKey,
                        ""
                );

        if (state.isEmpty()
                || "COMPLETE".equals(state)
                || "ERROR".equals(state)
                || "REVIEW_REQUIRED".equals(state)) {
            return false;
        }

        if ("cancelar".equals(
                normalize(incoming)
        )) {
            prefs.edit()
                    .remove(
                            "reseller_state_" + contactKey
                    )
                    .putString(
                            "last_reseller_status",
                            "Revenda: fluxo cancelado"
                    )
                    .apply();

            try {
                new SecureStore(this).remove(
                        "pending_reseller_email_" + contactKey
                );
            } catch (Exception ignored) {
            }

            WhatsAppReply.send(
                    this,
                    notification,
                    "Fluxo de revenda cancelado."
            );

            return true;
        }

        if ("WAITING_EMAIL".equals(state)) {
            String email =
                    incoming == null
                            ? ""
                            : incoming.trim().toLowerCase(Locale.ROOT);

            if (!isValidEmail(email)) {
                WhatsAppReply.send(
                        this,
                        notification,
                        "Envie somente o mesmo e-mail usado no cadastro da revenda."
                );

                return true;
            }

            try {
                new SecureStore(this).put(
                        "pending_reseller_email_" + contactKey,
                        email
                );

            } catch (Exception e) {
                WhatsAppReply.send(
                        this,
                        notification,
                        "Não consegui salvar o e-mail com segurança. Tente novamente."
                );

                return true;
            }

            prefs.edit()
                    .putString(
                            "reseller_state_" + contactKey,
                            "SEARCHING"
                    )
                    .putString(
                            "last_reseller_status",
                            "Revenda: procurando e-mail exato no MASTERFLIX"
                    )
                    .apply();

            WhatsAppReply.send(
                    this,
                    notification,
                    "Recebi seu e-mail. Localizando seu cadastro no MASTERFLIX, aguarde..."
            );

            boolean started =
                    MasterflixResellerAutomation.findReseller(
                            this,
                            notification,
                            prefs,
                            contactKey,
                            email
                    );

            if (!started) {
                prefs.edit()
                        .putString(
                                "reseller_state_" + contactKey,
                                "WAITING_EMAIL"
                        )
                        .putString(
                                "last_reseller_status",
                                "Revenda: automação ocupada"
                        )
                        .apply();

                WhatsAppReply.send(
                        this,
                        notification,
                        "O MASTER RESPONDE está concluindo outra operação. Envie o e-mail novamente em alguns instantes."
                );
            }

            return true;
        }

        if ("WAITING_CONFIRM".equals(state)) {
            if (!"confirmar".equals(
                    normalize(incoming)
            )) {
                WhatsAppReply.send(
                        this,
                        notification,
                        "Para adicionar os 50 créditos, responda exatamente *CONFIRMAR*. Para sair, envie *CANCELAR*."
                );

                return true;
            }

            String email =
                    new SecureStore(this).get(
                            "pending_reseller_email_" + contactKey
                    );

            if (email.isEmpty()) {
                prefs.edit()
                        .putString(
                                "reseller_state_" + contactKey,
                                "ERROR"
                        )
                        .putString(
                                "last_reseller_status",
                                "Revenda: e-mail pendente não encontrado"
                        )
                        .apply();

                WhatsAppReply.send(
                        this,
                        notification,
                        "Não encontrei o e-mail pendente dessa revenda. Inicie novamente com “Quero ser Revenda”."
                );

                return true;
            }

            boolean alreadyAttempted =
                    prefs.getBoolean(
                            "reseller_submit_attempted_" + contactKey,
                            false
                    );

            if (alreadyAttempted) {
                prefs.edit()
                        .putString(
                                "reseller_state_" + contactKey,
                                "REVIEW_REQUIRED"
                        )
                        .apply();

                WhatsAppReply.send(
                        this,
                        notification,
                        "⚠️ Já existe uma tentativa anterior de adicionar créditos. Por segurança, não vou repetir automaticamente. Confira no MASTERFLIX."
                );

                return true;
            }

            prefs.edit()
                    .putString(
                            "reseller_state_" + contactKey,
                            "ADDING"
                    )
                    .putString(
                            "last_reseller_status",
                            "Revenda: adicionando 50 créditos"
                    )
                    .apply();

            WhatsAppReply.send(
                    this,
                    notification,
                    "Adicionando 50 créditos. Aguarde a confirmação do saldo..."
            );

            boolean started =
                    MasterflixResellerAutomation.addCredits(
                            this,
                            notification,
                            prefs,
                            contactKey,
                            email
                    );

            if (!started) {
                prefs.edit()
                        .putString(
                                "reseller_state_" + contactKey,
                                "WAITING_CONFIRM"
                        )
                        .apply();

                WhatsAppReply.send(
                        this,
                        notification,
                        "O MASTER RESPONDE está concluindo outra operação. Envie CONFIRMAR novamente em alguns instantes."
                );
            }

            return true;
        }

        if ("SEARCHING".equals(state)
                || "ADDING".equals(state)) {
            WhatsAppReply.send(
                    this,
                    notification,
                    "A operação da revenda ainda está em andamento. Aguarde a conclusão."
            );

            return true;
        }

        return false;
    }

    private boolean isValidEmail(
            String value
    ) {
        return value != null
                && value.length() <= 254
                && android.util.Patterns.EMAIL_ADDRESS
                .matcher(value)
                .matches();
    }

    private String privateContactKey(
            Notification notification
    ) {
        String raw =
                "";

        if (notification != null) {
            String shortcut =
                    notification.getShortcutId();

            if (shortcut != null
                    && !shortcut.trim().isEmpty()) {
                raw =
                        "shortcut|"
                                + shortcut.trim();
            }

            if (raw.isEmpty()
                    && notification.extras != null) {
                CharSequence title =
                        notification.extras.getCharSequence(
                                Notification.EXTRA_TITLE
                        );

                if (title != null
                        && title.length() > 0) {
                    raw =
                            "title|"
                                    + normalize(
                                            title.toString()
                                    );
                }
            }
        }

        if (raw.isEmpty()) {
            raw =
                    "private";
        }

        try {
            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] bytes =
                    digest.digest(
                            raw.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            StringBuilder builder =
                    new StringBuilder();

            for (int i = 0;
                 i < 12 && i < bytes.length;
                 i++) {

                builder.append(
                        String.format(
                                Locale.US,
                                "%02x",
                                bytes[i] & 0xff
                        )
                );
            }

            return builder.toString();

        } catch (Exception e) {
            return Integer.toHexString(
                    raw.hashCode()
            );
        }
    }

    private boolean isTestRequest(String incoming) {
        if (incoming == null) return false;

        String value = normalize(incoming);

        return "teste".equals(value)
                || "quero um teste".equals(value)
                || "quero teste".equals(value)
                || "gerar teste".equals(value)
                || "gerar um teste".equals(value);
    }

    private void startMasterflixTest(
            Notification notification,
            String notificationKey,
            String incoming,
            SharedPreferences prefs
    ) {
        String requestKey =
                notificationKey
                        + "|"
                        + incoming;

        boolean accepted =
                TestTaskBridge.begin(
                        notification,
                        requestKey
                );

        if (!accepted) {
            return;
        }

        boolean waitSent =
                WhatsAppReply.send(
                        this,
                        notification,
                        "Gerando seu teste, aguarde..."
                );

        prefs.edit()
                .putString(
                        "last_test_status",
                        waitSent
                                ? "Teste: iniciando em segundo plano"
                                : "Teste: iniciando em segundo plano sem mensagem de espera"
                )
                .apply();

        boolean started =
                MasterflixBackgroundAutomation.start(
                        this,
                        notification,
                        prefs
                );

        if (!started) {
            TestTaskBridge.complete();

            prefs.edit()
                    .putString(
                            "last_test_status",
                            "Teste: outra geração já está em andamento"
                    )
                    .apply();
        }
    }

    private String groupConversationKey(Notification notification) {
        CharSequence conversation = notification.extras.getCharSequence(
                Notification.EXTRA_CONVERSATION_TITLE
        );

        if (conversation != null && conversation.length() > 0) {
            return normalize(conversation.toString());
        }

        // Evita usar EXTRA_TITLE, pois em alguns aparelhos ele muda com o remetente.
        return "grupo";
    }

    private JSONArray categoryResponsesById(
            SharedPreferences prefs,
            String categoryId
    ) {
        try {
            JSONArray categories = new JSONArray(
                    prefs.getString("text_categories", "[]")
            );

            for (int i = 0; i < categories.length(); i++) {
                JSONObject category = categories.optJSONObject(i);
                if (category == null) continue;

                if (!categoryId.equals(category.optString("id"))) continue;

                return cleanResponses(
                        category.optJSONArray("responses")
                );
            }

        } catch (Exception ignored) {
        }

        return new JSONArray();
    }

    private JSONArray categoryResponsesByName(
            SharedPreferences prefs,
            String categoryName
    ) {
        try {
            JSONArray categories = new JSONArray(
                    prefs.getString("text_categories", "[]")
            );

            String wanted = normalize(categoryName);

            for (int i = 0; i < categories.length(); i++) {
                JSONObject category = categories.optJSONObject(i);
                if (category == null) continue;

                String name = normalize(
                        category.optString("name", "")
                );

                if (!wanted.equals(name)) continue;

                return cleanResponses(
                        category.optJSONArray("responses")
                );
            }

        } catch (Exception ignored) {
        }

        return new JSONArray();
    }

    private JSONArray cleanResponses(JSONArray responses) {
        JSONArray result = new JSONArray();

        if (responses == null) return result;

        for (int i = 0; i < responses.length(); i++) {
            JSONObject response = responses.optJSONObject(i);
            if (response == null) continue;

            String text = response.optString("text", "").trim();

            if (!text.isEmpty()) {
                result.put(text);
            }
        }

        return result;
    }

    private void sendSingleWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            String message
    ) {
        String fingerprint =
                notificationKey + "|" + ruleKey + "|" + incoming;

        if (!reserveFingerprint(fingerprint)) return;

        boolean sent = reply(notification, message);

        updateStatus(
                sent
                        ? "Última autoresposta: enviada"
                        : "Última autoresposta: não disponível"
        );
    }

    private void sendSequenceWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            JSONArray messages
    ) {
        String fingerprint =
                notificationKey + "|" + ruleKey + "|" + incoming;

        if (!reserveFingerprint(fingerprint)) return;

        updateStatus(
                "Última sequência: iniciada com " +
                        messages.length() +
                        " respostas"
        );

        int lastIndex = messages.length() - 1;

        for (int i = 0; i < messages.length(); i++) {
            final String message = messages.optString(i, "").trim();
            if (message.isEmpty()) continue;

            final boolean last = i == lastIndex;
            long delay = i * SEQUENCE_DELAY;

            handler.postDelayed(
                    () -> {
                        boolean sent = reply(notification, message);

                        if (!sent) {
                            updateStatus(
                                    "Última sequência: envio interrompido"
                            );
                        } else if (last) {
                            updateStatus(
                                    "Última sequência: concluída"
                            );
                        }
                    },
                    delay
            );
        }
    }

    private boolean reserveFingerprint(String fingerprint) {
        synchronized (SEND_LOCK) {
            long now = System.currentTimeMillis();

            Long memoryTime = RECENT.get(fingerprint);

            if (memoryTime != null && now - memoryTime < 10000L) {
                return false;
            }

            SharedPreferences prefs = getSharedPreferences(
                    "master_responde",
                    MODE_PRIVATE
            );

            String last = prefs.getString(
                    "last_rule_fingerprint",
                    ""
            );

            long lastTime = prefs.getLong(
                    "last_rule_fingerprint_time",
                    0L
            );

            if (fingerprint.equals(last) && now - lastTime < 10000L) {
                RECENT.put(fingerprint, now);
                return false;
            }

            RECENT.put(fingerprint, now);

            prefs.edit()
                    .putString(
                            "last_rule_fingerprint",
                            fingerprint
                    )
                    .putLong(
                            "last_rule_fingerprint_time",
                            now
                    )
                    .commit();

            if (RECENT.size() > 250) {
                RECENT.clear();
                RECENT.put(fingerprint, now);
            }

            return true;
        }
    }

    private void updateStatus(String value) {
        getSharedPreferences(
                "master_responde",
                MODE_PRIVATE
        )
                .edit()
                .putString(
                        "last_test_status",
                        value
                )
                .apply();
    }

    private boolean reply(
            Notification notification,
            String message
    ) {
        Notification.Action[] actions = notification.actions;
        if (actions == null) return false;

        for (Notification.Action action : actions) {
            if (action == null || action.actionIntent == null) continue;

            RemoteInput[] inputs = action.getRemoteInputs();
            if (inputs == null || inputs.length == 0) continue;

            for (RemoteInput input : inputs) {
                if (input == null) continue;
                if (!input.getAllowFreeFormInput()) continue;

                try {
                    Intent intent = new Intent();
                    Bundle results = new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            this,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) return "";

        return Normalizer
                .normalize(
                        value,
                        Normalizer.Form.NFD
                )
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
