package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class WhatsAppMediaReply {

    public static final int RESULT_FAILED =
            0;

    public static final int RESULT_SUPPORTED_ACTION =
            1;

    public static final int RESULT_EXPERIMENTAL_ACTION =
            2;

    private static final String WHATSAPP_BUSINESS =
            "com.whatsapp.w4b";

    public static int sendPhoto(
            Context context,
            Notification notification,
            Uri uri
    ) {
        if (context == null
                || notification == null
                || uri == null) {
            return RESULT_FAILED;
        }

        Notification.Action[] actions =
                notification.actions;

        if (actions == null
                || actions.length == 0) {
            return RESULT_FAILED;
        }

        String mimeType =
                null;

        try {
            mimeType =
                    context.getContentResolver()
                            .getType(
                                    uri
                            );
        } catch (Exception ignored) {
        }

        if (mimeType == null
                || !mimeType.startsWith(
                        "image/"
                )) {
            mimeType =
                    "image/jpeg";
        }

        try {
            context.grantUriPermission(
                    WHATSAPP_BUSINESS,
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        } catch (Exception ignored) {
        }

        Notification.Action preferredAction =
                null;

        RemoteInput preferredInput =
                null;

        Notification.Action fallbackAction =
                null;

        RemoteInput fallbackInput =
                null;

        for (Notification.Action action
                : actions) {

            if (action == null
                    || action.actionIntent == null) {
                continue;
            }

            RemoteInput[] inputs =
                    action.getRemoteInputs();

            if (inputs == null
                    || inputs.length == 0) {
                continue;
            }

            for (RemoteInput input
                    : inputs) {

                if (input == null) {
                    continue;
                }

                boolean explicitlyAllowsImage =
                        allowsImage(
                                input,
                                mimeType
                        );

                if (explicitlyAllowsImage) {
                    preferredAction =
                            action;

                    preferredInput =
                            input;

                    break;
                }

                if (fallbackInput == null
                        && input.getAllowFreeFormInput()) {

                    fallbackAction =
                            action;

                    fallbackInput =
                            input;
                }
            }

            if (preferredInput != null) {
                break;
            }
        }

        Notification.Action selectedAction =
                preferredAction != null
                        ? preferredAction
                        : fallbackAction;

        RemoteInput selectedInput =
                preferredInput != null
                        ? preferredInput
                        : fallbackInput;

        if (selectedAction == null
                || selectedInput == null
                || selectedAction.actionIntent == null) {
            return RESULT_FAILED;
        }

        try {
            Intent fillInIntent =
                    new Intent();

            fillInIntent.addFlags(
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );

            fillInIntent.setClipData(
                    ClipData.newRawUri(
                            "MASTER_RESPONDE_PHOTO",
                            uri
                    )
            );

            Map<String, Uri> dataResults =
                    new HashMap<>();

            dataResults.put(
                    mimeType,
                    uri
            );

            RemoteInput.addDataResultToIntent(
                    selectedInput,
                    fillInIntent,
                    dataResults
            );

            selectedAction.actionIntent.send(
                    context,
                    0,
                    fillInIntent
            );

            return preferredInput != null
                    ? RESULT_SUPPORTED_ACTION
                    : RESULT_EXPERIMENTAL_ACTION;

        } catch (PendingIntent.CanceledException e) {
            return RESULT_FAILED;

        } catch (Exception e) {
            return RESULT_FAILED;
        }
    }

    private static boolean allowsImage(
            RemoteInput input,
            String mimeType
    ) {
        try {
            Set<String> allowed =
                    input.getAllowedDataTypes();

            if (allowed == null
                    || allowed.isEmpty()) {
                return false;
            }

            if (allowed.contains(
                    mimeType
            )) {
                return true;
            }

            if (allowed.contains(
                    "image/*"
            )) {
                return true;
            }

            return allowed.contains(
                    "*/*"
            );

        } catch (Exception e) {
            return false;
        }
    }
}
