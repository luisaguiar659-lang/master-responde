package com.masterresponde.app;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.Normalizer;
import java.util.Locale;

public class MediaAccessibilityService extends AccessibilityService {

    private static final String WHATSAPP_BUSINESS =
            "com.whatsapp.w4b";

    private final Handler handler =
            new Handler(
                    Looper.getMainLooper()
            );

    private final Runnable processRunnable =
            this::processWhatsAppScreen;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();

        status(
                "Foto: Acessibilidade do MASTER RESPONDE ativa."
        );
    }

    @Override
    public void onAccessibilityEvent(
            AccessibilityEvent event
    ) {
        if (!MediaShareTaskBridge.hasPending()) {
            return;
        }

        if (event != null
                && event.getPackageName() != null
                && !WHATSAPP_BUSINESS.contentEquals(
                        event.getPackageName()
                )) {
            return;
        }

        handler.removeCallbacks(
                processRunnable
        );

        handler.postDelayed(
                processRunnable,
                280L
        );
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(
                null
        );

        super.onDestroy();
    }

    private void processWhatsAppScreen() {
        if (MediaShareTaskBridge.isExpired()) {
            status(
                    "Foto: o compartilhamento expirou antes de chegar ao botão Enviar."
            );

            MediaShareTaskBridge.clear();
            return;
        }

        if (!MediaShareTaskBridge.hasPending()) {
            return;
        }

        AccessibilityNodeInfo root =
                getRootInActiveWindow();

        if (root == null) {
            return;
        }

        CharSequence packageName =
                root.getPackageName();

        if (packageName != null
                && !WHATSAPP_BUSINESS.contentEquals(
                        packageName
                )) {
            return;
        }

        int stage =
                MediaShareTaskBridge.getStage();

        String target =
                MediaShareTaskBridge.getTargetTitle();

        if (stage == MediaShareTaskBridge.STAGE_WAIT_SHARE) {
            AccessibilityNodeInfo targetNode =
                    findExactText(
                            root,
                            target
                    );

            if (targetNode != null
                    && clickNodeOrParent(
                            targetNode
                    )) {

                MediaShareTaskBridge.setStage(
                        MediaShareTaskBridge.STAGE_CONTACT_SELECTED
                );

                status(
                        "Foto: conversa localizada. Preparando a tela de envio..."
                );

                scheduleAgain(
                        420L
                );

                return;
            }

            AccessibilityNodeInfo search =
                    findByWords(
                            root,
                            new String[]{
                                    "pesquisar",
                                    "buscar",
                                    "search"
                            }
                    );

            if (search != null
                    && clickNodeOrParent(
                            search
                    )) {

                MediaShareTaskBridge.setStage(
                        MediaShareTaskBridge.STAGE_SEARCH_OPEN
                );

                status(
                        "Foto: pesquisa de conversa aberta."
                );

                scheduleAgain(
                        350L
                );
            }

            return;
        }

        if (stage == MediaShareTaskBridge.STAGE_SEARCH_OPEN) {
            AccessibilityNodeInfo editor =
                    findEditable(
                            root
                    );

            if (editor == null) {
                scheduleAgain(
                        300L
                );
                return;
            }

            Bundle args =
                    new Bundle();

            args.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    target
            );

            boolean typed =
                    editor.performAction(
                            AccessibilityNodeInfo.ACTION_SET_TEXT,
                            args
                    );

            if (typed) {
                MediaShareTaskBridge.setStage(
                        MediaShareTaskBridge.STAGE_SEARCH_TYPED
                );

                status(
                        "Foto: procurando a conversa exata..."
                );

                scheduleAgain(
                        600L
                );
            }

            return;
        }

        if (stage == MediaShareTaskBridge.STAGE_SEARCH_TYPED) {
            AccessibilityNodeInfo targetNode =
                    findExactText(
                            root,
                            target
                    );

            if (targetNode == null) {
                scheduleAgain(
                        450L
                );
                return;
            }

            if (clickNodeOrParent(
                    targetNode
            )) {
                MediaShareTaskBridge.setStage(
                        MediaShareTaskBridge.STAGE_CONTACT_SELECTED
                );

                status(
                        "Foto: conversa selecionada."
                );

                scheduleAgain(
                        500L
                );
            }

            return;
        }

        if (stage == MediaShareTaskBridge.STAGE_CONTACT_SELECTED) {
            if (looksLikeMediaPreview(
                    root
            )) {
                MediaShareTaskBridge.setStage(
                        MediaShareTaskBridge.STAGE_PREVIEW
                );

                scheduleAgain(
                        250L
                );

                return;
            }

            AccessibilityNodeInfo next =
                    findByWords(
                            root,
                            new String[]{
                                    "avançar",
                                    "avancar",
                                    "próximo",
                                    "proximo",
                                    "next",
                                    "continuar"
                            }
                    );

            if (next != null
                    && clickNodeOrParent(
                            next
                    )) {

                MediaShareTaskBridge.setStage(
                        MediaShareTaskBridge.STAGE_PREVIEW
                );

                status(
                        "Foto: abrindo a prévia antes do envio."
                );

                scheduleAgain(
                        550L
                );
            }

            return;
        }

        if (stage == MediaShareTaskBridge.STAGE_PREVIEW) {
            AccessibilityNodeInfo send =
                    findExactAny(
                            root,
                            new String[]{
                                    "enviar",
                                    "send"
                            }
                    );

            if (send == null) {
                scheduleAgain(
                        350L
                );
                return;
            }

            if (!MediaShareTaskBridge.armFinalClick()) {
                return;
            }

            status(
                    "Foto: botão Enviar localizado. Clique único reservado."
            );

            boolean clicked =
                    clickNodeOrParent(
                            send
                    );

            if (clicked) {
                status(
                        "Foto: botão Enviar acionado uma única vez. Confira a conversa."
                );
            } else {
                status(
                        "Foto: reservei o envio, mas não consegui confirmar o clique. Não vou repetir automaticamente."
                );
            }

            handler.postDelayed(
                    MediaShareTaskBridge::clear,
                    2200L
            );
        }
    }

    private void scheduleAgain(
            long delay
    ) {
        handler.removeCallbacks(
                processRunnable
        );

        handler.postDelayed(
                processRunnable,
                delay
        );
    }

    private boolean looksLikeMediaPreview(
            AccessibilityNodeInfo root
    ) {
        AccessibilityNodeInfo caption =
                findByWords(
                        root,
                        new String[]{
                                "adicionar legenda",
                                "adicione uma legenda",
                                "legenda",
                                "add a caption",
                                "caption"
                        }
                );

        if (caption != null) {
            return true;
        }

        AccessibilityNodeInfo send =
                findExactAny(
                        root,
                        new String[]{
                                "enviar",
                                "send"
                        }
                );

        AccessibilityNodeInfo search =
                findByWords(
                        root,
                        new String[]{
                                "pesquisar",
                                "buscar",
                                "search"
                        }
                );

        return send != null
                && search == null;
    }

    private AccessibilityNodeInfo findEditable(
            AccessibilityNodeInfo node
    ) {
        if (node == null) {
            return null;
        }

        CharSequence className =
                node.getClassName();

        if (node.isEditable()
                || (className != null
                && className.toString()
                        .toLowerCase(
                                Locale.ROOT
                        )
                        .contains(
                                "edittext"
                        ))) {
            return node;
        }

        for (int i = 0;
             i < node.getChildCount();
             i++) {

            AccessibilityNodeInfo found =
                    findEditable(
                            node.getChild(
                                    i
                            )
                    );

            if (found != null) {
                return found;
            }
        }

        return null;
    }

    private AccessibilityNodeInfo findExactText(
            AccessibilityNodeInfo node,
            String wanted
    ) {
        if (node == null
                || wanted == null
                || wanted.trim().isEmpty()) {
            return null;
        }

        String normalizedWanted =
                normalize(
                        wanted
                );

        String current =
                nodeLabel(
                        node
                );

        if (!current.isEmpty()
                && current.equals(
                        normalizedWanted
                )) {
            return node;
        }

        for (int i = 0;
             i < node.getChildCount();
             i++) {

            AccessibilityNodeInfo found =
                    findExactText(
                            node.getChild(
                                    i
                            ),
                            wanted
                    );

            if (found != null) {
                return found;
            }
        }

        return null;
    }

    private AccessibilityNodeInfo findExactAny(
            AccessibilityNodeInfo node,
            String[] words
    ) {
        if (node == null
                || words == null) {
            return null;
        }

        String current =
                nodeLabel(
                        node
                );

        for (String word : words) {
            if (current.equals(
                    normalize(
                            word
                    )
            )) {
                return node;
            }
        }

        for (int i = 0;
             i < node.getChildCount();
             i++) {

            AccessibilityNodeInfo found =
                    findExactAny(
                            node.getChild(
                                    i
                            ),
                            words
                    );

            if (found != null) {
                return found;
            }
        }

        return null;
    }

    private AccessibilityNodeInfo findByWords(
            AccessibilityNodeInfo node,
            String[] words
    ) {
        if (node == null
                || words == null) {
            return null;
        }

        String current =
                nodeLabel(
                        node
                );

        if (!current.isEmpty()) {
            for (String word : words) {
                String wanted =
                        normalize(
                                word
                        );

                if (!wanted.isEmpty()
                        && current.contains(
                                wanted
                        )) {
                    return node;
                }
            }
        }

        for (int i = 0;
             i < node.getChildCount();
             i++) {

            AccessibilityNodeInfo found =
                    findByWords(
                            node.getChild(
                                    i
                            ),
                            words
                    );

            if (found != null) {
                return found;
            }
        }

        return null;
    }

    private String nodeLabel(
            AccessibilityNodeInfo node
    ) {
        if (node == null) {
            return "";
        }

        StringBuilder builder =
                new StringBuilder();

        CharSequence text =
                node.getText();

        if (text != null) {
            builder.append(
                    text
            );
        }

        CharSequence description =
                node.getContentDescription();

        if (description != null) {
            if (builder.length() > 0) {
                builder.append(
                        ' '
                );
            }

            builder.append(
                    description
            );
        }

        return normalize(
                builder.toString()
        );
    }

    private boolean clickNodeOrParent(
            AccessibilityNodeInfo node
    ) {
        AccessibilityNodeInfo current =
                node;

        for (int i = 0;
             i < 7 && current != null;
             i++) {

            if (current.isClickable()) {
                return current.performAction(
                        AccessibilityNodeInfo.ACTION_CLICK
                );
            }

            current =
                    current.getParent();
        }

        if (node != null) {
            return node.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK
            );
        }

        return false;
    }

    private void status(
            String value
    ) {
        SharedPreferences prefs =
                getSharedPreferences(
                        "master_responde",
                        MODE_PRIVATE
                );

        prefs.edit()
                .putString(
                        "last_media_status",
                        value
                )
                .apply();
    }

    public static boolean isEnabled(
            Context context
    ) {
        if (context == null) {
            return false;
        }

        String enabled =
                Settings.Secure.getString(
                        context.getContentResolver(),
                        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                );

        if (enabled == null
                || enabled.trim().isEmpty()) {
            return false;
        }

        ComponentName component =
                new ComponentName(
                        context,
                        MediaAccessibilityService.class
                );

        String full =
                component.flattenToString();

        String shortName =
                component.flattenToShortString();

        String[] parts =
                enabled.split(
                        ":"
                );

        for (String part : parts) {
            if (full.equalsIgnoreCase(
                    part
            )
                    || shortName.equalsIgnoreCase(
                    part
            )) {
                return true;
            }
        }

        return false;
    }

    private static String normalize(
            String value
    ) {
        if (value == null) {
            return "";
        }

        return Normalizer
                .normalize(
                        value,
                        Normalizer.Form.NFD
                )
                .replaceAll(
                        "\\p{M}",
                        ""
                )
                .toLowerCase(
                        Locale.ROOT
                )
                .trim();
    }
}
