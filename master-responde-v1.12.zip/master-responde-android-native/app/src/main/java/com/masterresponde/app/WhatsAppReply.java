package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class WhatsAppReply {

    private static final Object LOCK =
            new Object();

    private static final Handler HANDLER =
            new Handler(
                    Looper.getMainLooper()
            );

    private static final Map<String, Long> LAST_SCHEDULED =
            new ConcurrentHashMap<>();

    public static boolean send(
            Context context,
            Notification notification,
            String message
    ) {
        if (context == null
                || notification == null
                || message == null
                || message.trim().isEmpty()) {
            return false;
        }

        if (!hasReplyAction(
                notification
        )) {
            return false;
        }

        Context appContext =
                context.getApplicationContext();

        SharedPreferences prefs =
                appContext.getSharedPreferences(
                        "master_responde",
                        Context.MODE_PRIVATE
                );

        long replyDelay =
                MessageSettings.getMilliseconds(
                        prefs,
                        MessageSettings.KEY_REPLY_DELAY_SECONDS,
                        MessageSettings.DEFAULT_REPLY_DELAY_SECONDS
                );

        long minimumInterval =
                MessageSettings.getMilliseconds(
                        prefs,
                        MessageSettings.KEY_MIN_REPLY_INTERVAL_SECONDS,
                        MessageSettings.DEFAULT_MIN_REPLY_INTERVAL_SECONDS
                );

        String conversationKey =
                conversationKey(
                        notification
                );

        long now =
                System.currentTimeMillis();

        long scheduledAt;

        synchronized (LOCK) {
            Long last =
                    LAST_SCHEDULED.get(
                            conversationKey
                    );

            long earliest =
                    now + replyDelay;

            if (last != null) {
                earliest =
                        Math.max(
                                earliest,
                                last + minimumInterval
                        );
            }

            scheduledAt =
                    earliest;

            LAST_SCHEDULED.put(
                    conversationKey,
                    scheduledAt
            );

            if (LAST_SCHEDULED.size() > 300) {
                LAST_SCHEDULED.clear();

                LAST_SCHEDULED.put(
                        conversationKey,
                        scheduledAt
                );
            }
        }

        long delay =
                Math.max(
                        0L,
                        scheduledAt - now
                );

        HANDLER.postDelayed(
                () -> sendNow(
                        appContext,
                        notification,
                        message
                ),
                delay
        );

        return true;
    }

    private static boolean hasReplyAction(
            Notification notification
    ) {
        if (notification == null
                || notification.actions == null) {
            return false;
        }

        for (Notification.Action action
                : notification.actions) {

            if (action == null
                    || action.actionIntent == null) {
                continue;
            }

            RemoteInput[] inputs =
                    action.getRemoteInputs();

            if (inputs == null) {
                continue;
            }

            for (RemoteInput input
                    : inputs) {

                if (input != null
                        && input.getAllowFreeFormInput()) {
                    return true;
                }
            }
        }

        return false;
    }

    private static boolean sendNow(
            Context context,
            Notification notification,
            String message
    ) {
        Notification.Action[] actions =
                notification.actions;

        if (actions == null) {
            return false;
        }

        for (Notification.Action action : actions) {
            if (action == null
                    || action.actionIntent == null) {
                continue;
            }

            RemoteInput[] inputs =
                    action.getRemoteInputs();

            if (inputs == null
                    || inputs.length == 0) {
                continue;
            }

            for (RemoteInput input : inputs) {
                if (input == null
                        || !input.getAllowFreeFormInput()) {
                    continue;
                }

                try {
                    Intent intent =
                            new Intent();

                    Bundle results =
                            new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            context,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private static String conversationKey(
            Notification notification
    ) {
        if (notification == null) {
            return "unknown";
        }

        String shortcut =
                notification.getShortcutId();

        if (shortcut != null
                && !shortcut.trim().isEmpty()) {
            return "shortcut|"
                    + shortcut.trim();
        }

        if (notification.extras != null) {
            CharSequence conversation =
                    notification.extras
                            .getCharSequence(
                                    Notification.EXTRA_CONVERSATION_TITLE
                            );

            if (conversation != null
                    && conversation.length() > 0) {
                return "conversation|"
                        + conversation.toString();
            }

            CharSequence title =
                    notification.extras
                            .getCharSequence(
                                    Notification.EXTRA_TITLE
                            );

            if (title != null
                    && title.length() > 0) {
                return "title|"
                        + title.toString();
            }
        }

        return "unknown";
    }
}
