package com.masterresponde.app;

public class MediaShareTaskBridge {

    public static final int STAGE_WAIT_SHARE = 0;
    public static final int STAGE_SEARCH_OPEN = 1;
    public static final int STAGE_SEARCH_TYPED = 2;
    public static final int STAGE_CONTACT_SELECTED = 3;
    public static final int STAGE_PREVIEW = 4;

    private static final Object LOCK =
            new Object();

    private static String targetTitle = "";
    private static String uri = "";
    private static String mimeType = "";
    private static long createdAt = 0L;
    private static int stage = STAGE_WAIT_SHARE;
    private static boolean finalClickArmed = false;

    public static void begin(
            String title,
            String sourceUri,
            String mime
    ) {
        synchronized (LOCK) {
            targetTitle =
                    title == null
                            ? ""
                            : title.trim();

            uri =
                    sourceUri == null
                            ? ""
                            : sourceUri.trim();

            mimeType =
                    mime == null
                            ? "image/*"
                            : mime.trim();

            createdAt =
                    System.currentTimeMillis();

            stage =
                    STAGE_WAIT_SHARE;

            finalClickArmed =
                    false;
        }
    }

    public static boolean hasPending() {
        synchronized (LOCK) {
            return !targetTitle.isEmpty()
                    && !uri.isEmpty()
                    && System.currentTimeMillis() - createdAt < 60000L;
        }
    }

    public static boolean isExpired() {
        synchronized (LOCK) {
            return createdAt > 0L
                    && System.currentTimeMillis() - createdAt >= 60000L;
        }
    }

    public static String getTargetTitle() {
        synchronized (LOCK) {
            return targetTitle;
        }
    }

    public static String getUri() {
        synchronized (LOCK) {
            return uri;
        }
    }

    public static String getMimeType() {
        synchronized (LOCK) {
            return mimeType;
        }
    }

    public static int getStage() {
        synchronized (LOCK) {
            return stage;
        }
    }

    public static void setStage(
            int value
    ) {
        synchronized (LOCK) {
            stage =
                    value;
        }
    }

    public static boolean isFinalClickArmed() {
        synchronized (LOCK) {
            return finalClickArmed;
        }
    }

    public static boolean armFinalClick() {
        synchronized (LOCK) {
            if (finalClickArmed) {
                return false;
            }

            finalClickArmed =
                    true;

            return true;
        }
    }

    public static void clear() {
        synchronized (LOCK) {
            targetTitle = "";
            uri = "";
            mimeType = "";
            createdAt = 0L;
            stage = STAGE_WAIT_SHARE;
            finalClickArmed = false;
        }
    }
}
