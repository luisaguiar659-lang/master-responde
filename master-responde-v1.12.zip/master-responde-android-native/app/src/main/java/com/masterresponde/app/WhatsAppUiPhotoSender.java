package com.masterresponde.app;

import android.app.Notification;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;

public class WhatsAppUiPhotoSender {

    public static final int RESULT_STARTED = 1;
    public static final int RESULT_ACCESSIBILITY_DISABLED = 2;
    public static final int RESULT_FAILED = 0;

    private static final String WHATSAPP_BUSINESS =
            "com.whatsapp.w4b";

    public static int start(
            Context context,
            Notification notification,
            Uri uri
    ) {
        if (context == null
                || notification == null
                || uri == null) {
            return RESULT_FAILED;
        }

        SharedPreferences prefs =
                context.getSharedPreferences(
                        "master_responde",
                        Context.MODE_PRIVATE
                );

        if (!MediaAccessibilityService.isEnabled(
                context
        )) {
            prefs.edit()
                    .putString(
                            "last_media_status",
                            "Foto: ative a Acessibilidade do MASTER RESPONDE para usar o envio pela tela real do WhatsApp."
                    )
                    .apply();

            return RESULT_ACCESSIBILITY_DISABLED;
        }

        String targetTitle =
                conversationTitle(
                        notification
                );

        if (targetTitle.isEmpty()) {
            prefs.edit()
                    .putString(
                            "last_media_status",
                            "Foto: não consegui identificar a conversa que enviou o gatilho."
                    )
                    .apply();

            return RESULT_FAILED;
        }

        String mimeType =
                "image/*";

        try {
            String detected =
                    context.getContentResolver()
                            .getType(
                                    uri
                            );

            if (detected != null
                    && detected.startsWith(
                            "image/"
                    )) {
                mimeType =
                        detected;
            }

        } catch (Exception ignored) {
        }

        MediaShareTaskBridge.begin(
                targetTitle,
                uri.toString(),
                mimeType
        );

        try {
            context.grantUriPermission(
                    WHATSAPP_BUSINESS,
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
            );
        } catch (Exception ignored) {
        }

        Intent share =
                new Intent(
                        Intent.ACTION_SEND
                );

        share.setPackage(
                WHATSAPP_BUSINESS
        );

        share.setType(
                mimeType
        );

        share.putExtra(
                Intent.EXTRA_STREAM,
                uri
        );

        share.setClipData(
                ClipData.newRawUri(
                        "MASTER_RESPONDE_PHOTO",
                        uri
                )
        );

        share.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_GRANT_READ_URI_PERMISSION
        );

        try {
            context.startActivity(
                    share
            );

            prefs.edit()
                    .putString(
                            "last_media_status",
                            "Foto: WhatsApp Business aberto. Localizando a conversa pela tela real..."
                    )
                    .apply();

            return RESULT_STARTED;

        } catch (Exception e) {
            MediaShareTaskBridge.clear();

            prefs.edit()
                    .putString(
                            "last_media_status",
                            "Foto: não consegui abrir o compartilhamento do WhatsApp Business."
                    )
                    .apply();

            return RESULT_FAILED;
        }
    }

    private static String conversationTitle(
            Notification notification
    ) {
        if (notification == null
                || notification.extras == null) {
            return "";
        }

        boolean group =
                notification.extras.getBoolean(
                        Notification.EXTRA_IS_GROUP_CONVERSATION,
                        false
                );

        CharSequence conversation =
                notification.extras.getCharSequence(
                        Notification.EXTRA_CONVERSATION_TITLE
                );

        if (group
                && conversation != null
                && conversation.length() > 0) {
            return conversation.toString()
                    .trim();
        }

        CharSequence title =
                notification.extras.getCharSequence(
                        Notification.EXTRA_TITLE
                );

        if (title != null
                && title.length() > 0) {
            return title.toString()
                    .trim();
        }

        if (conversation != null
                && conversation.length() > 0) {
            return conversation.toString()
                    .trim();
        }

        return "";
    }
}
