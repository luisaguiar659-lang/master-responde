MASTER RESPONDE v1.12

BASE ESTÁVEL:
v1.10

RESULTADO DA v1.11:
O WhatsApp Business aceitou a tentativa experimental da notificação,
mas não enviou a foto na conversa.

FUNÇÃO NOVA DA v1.12:
ENVIO DE 1 FOTO PELA TELA REAL DO WHATSAPP BUSINESS.

IMPORTANTE:
Nesta versão somente o método da FOTO mudou.
Os textos continuam usando a resposta de notificação já aprovada.

PREPARAÇÃO:
1. Instale a v1.12.
2. Abra MÍDIAS.
3. Toque em:
   ABRIR ACESSIBILIDADE DO ANDROID
4. Localize:
   MASTER RESPONDE — Fotos
5. Ative o serviço.
6. Volte para MÍDIAS.
7. O status deve mostrar:
   ACESSIBILIDADE PARA FOTOS: ATIVA

FLUXO DA FOTO:
1. O cliente envia o gatilho de uma regra com categoria.
2. O MASTER RESPONDE identifica a mesma conversa da notificação.
3. Abre o compartilhamento original do WhatsApp Business.
4. Procura o contato/grupo pelo título da conversa.
5. Seleciona a conversa.
6. Avança para a prévia da foto.
7. Localiza o botão Enviar.
8. Reserva a operação para evitar duplicidade.
9. Clica no botão Enviar UMA ÚNICA VEZ.
10. Não existe repetição automática depois do clique final.

SEGURANÇA:
- somente a primeira foto da categoria é usada;
- fotos adicionais continuam ignoradas nesta etapa;
- se a conversa exata não for encontrada, a foto não é enviada;
- se a Acessibilidade estiver desativada, o WhatsApp não é aberto para a foto;
- o botão final Enviar nunca é clicado automaticamente duas vezes;
- nenhum CAPTCHA ou verificação é contornado.

STATUS EM MÍDIAS:
A tela registra o andamento, por exemplo:
- Acessibilidade necessária;
- WhatsApp aberto;
- pesquisa de conversa aberta;
- conversa localizada;
- prévia aberta;
- botão Enviar localizado;
- botão Enviar acionado uma única vez.

OBSERVAÇÃO:
O WhatsApp Business muda a interface entre versões/aparelhos.
Por isso esta v1.12 continua sendo uma etapa controlada com uma única foto.

PRESERVADO:
- v1.10: cadastro e visualização de várias fotos;
- v1.9: Mensagens e Tempos;
- textos e regras;
- categorias;
- nova revenda com verificação de e-mail;
- grupo de suporte;
- geração automática de testes;
- @infor;
- MASTERFLIX login/sessão.
