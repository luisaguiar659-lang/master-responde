MASTER RESPONDE v1.5

BASE ESTÁVEL:
- v1.0 dashboard
- v1.1.1 Bot + notificações
- v1.2.1 primeira autoresposta
- v1.3.1 regras configuráveis sem duplicidade
- v1.4 categorias com várias respostas em sequência

ÚNICA FUNÇÃO NOVA DA v1.5:
MENU @infor PARA GRUPOS

COMPORTAMENTO:
- Em grupo o bot fica em silêncio.
- O bot só abre o menu quando alguém envia:
  @infor
- O menu fica ativo por 2 minutos naquele grupo.
- Depois uma opção 1 a 6 envia a categoria correspondente.

MENU:
1 Tutoriais
2 Promoções e Planos
3 Aplicativos Parceiros
4 Banners
5 Avisos
6 Apresentação do Servidor
7 Solicitar 50 Créditos
8 Gerar Teste
0 Falar com Suporte

PARA AS OPÇÕES 1 A 6 FUNCIONAREM:
No módulo MÍDIAS crie categorias com estes nomes exatamente:
- Tutoriais
- Promoções e Planos
- Aplicativos Parceiros
- Banners
- Avisos
- Apresentação do Servidor

Cada categoria pode ter várias respostas de texto,
como já funcionava na v1.4.

OPÇÕES 7 E 8:
Ainda não executam automação nesta versão.

OPÇÃO 0:
Responde apenas:
"Um atendente continuará o suporte."

IMPORTANTE:
As regras privadas da v1.3.1 continuam funcionando no privado.
Em grupos, regras comuns não respondem ao bate-papo;
somente o fluxo explícito @infor é processado.
