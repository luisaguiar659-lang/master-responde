package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.text.Normalizer;
import java.util.Locale;

public class NotificationAccessService extends NotificationListenerService {

    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (!WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        SharedPreferences prefs =
                getSharedPreferences("master_responde", MODE_PRIVATE);

        if (!prefs.getBoolean("bot_enabled", false)) return;

        Notification notification = sbn.getNotification();
        if (notification == null || notification.extras == null) return;

        CharSequence value =
                notification.extras.getCharSequence(Notification.EXTRA_TEXT);

        if (value == null) return;

        String incoming = normalize(value.toString());

        if (!"teste bot".equals(incoming)) return;

        long now = System.currentTimeMillis();
        long lastReply = prefs.getLong("last_reply_time", 0L);

        // evita responder repetidamente à mesma atualização de notificação
        if (now - lastReply < 5000L) return;

        boolean sent = reply(
                notification,
                "✅ MASTER RESPONDE ativo e funcionando."
        );

        prefs.edit()
                .putLong("last_reply_time", now)
                .putString(
                        "last_test_status",
                        sent
                                ? "Último teste: resposta enviada"
                                : "Último teste: resposta não disponível"
                )
                .apply();
    }

    private boolean reply(Notification notification, String message) {
        Notification.Action[] actions = notification.actions;

        if (actions == null) return false;

        for (Notification.Action action : actions) {
            if (action == null || action.actionIntent == null) continue;

            RemoteInput[] inputs = action.getRemoteInputs();

            if (inputs == null || inputs.length == 0) continue;

            for (RemoteInput input : inputs) {
                if (input == null) continue;
                if (!input.getAllowFreeFormInput()) continue;

                try {
                    Intent intent = new Intent();
                    Bundle results = new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            this,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) return "";

        return Normalizer
                .normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
