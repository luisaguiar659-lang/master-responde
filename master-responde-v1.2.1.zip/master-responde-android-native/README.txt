MASTER RESPONDE v1.2.1

Base: v1.1.1 aprovada no aparelho.

Única função nova:
- autoresposta simples de texto no WhatsApp Business.

Implementação simplificada:
- lê apenas Notification.EXTRA_TEXT;
- gatilho fixo: teste bot;
- resposta fixa:
  ✅ MASTER RESPONDE ativo e funcionando.
- responde usando RemoteInput da própria notificação.

Teste:
1. Bot = Ativo
2. WhatsApp Business = Acesso liberado
3. De OUTRO número, envie:
   teste bot
4. Aguarde a resposta automática.

Ainda não existem:
- regras
- grupos
- MASTERFLIX
- revendas
- mídia
