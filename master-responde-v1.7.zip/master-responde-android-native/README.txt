MASTER RESPONDE v1.7

BASE ESTÁVEL:
- dashboard
- Bot + acesso às notificações
- autorespostas privadas
- regras configuráveis
- categorias com várias respostas
- @infor em grupos
- MASTERFLIX login + sessão

ÚNICA FUNÇÃO NOVA:
GERAR TESTE MASTERFLIX TESTE COMPLETO 1H

GATILHOS PRIVADOS:
- teste
- quero um teste
- quero teste
- gerar teste
- gerar um teste

FLUXO:
1. Cliente envia o gatilho em conversa privada.
2. MASTER RESPONDE responde:
   Gerando seu teste, aguarde...
3. Abre o MASTERFLIX.
4. Reutiliza a sessão ativa.
5. Procura:
   MASTERFLIX TESTE COMPLETO 1H
6. Seleciona esse teste.
7. Aguarda Detalhes do Cliente.
8. Clica exatamente no botão COPIAR.
9. Lê o conteúdo copiado pelo painel.
10. Valida URL/M3U + usuário + senha.
11. Envia o bloco completo para o mesmo WhatsApp.

SEGURANÇA:
- não tenta marcar "Verificado";
- não resolve CAPTCHA;
- não contorna proteção antibot;
- se o login/verificação humana aparecer, o painel fica visível para conclusão manual.

TESTE MANUAL:
Também é possível tocar no botão GERAR TESTE do dashboard
ou no botão GERAR TESTE COMPLETO 1H dentro da tela MASTERFLIX.

AINDA NÃO EXISTE:
- nova revenda;
- adicionar 50 créditos;
- opção 7 automática em grupos.

IMPORTANTE:
Nesta primeira versão do fluxo de teste, o Android pode abrir
a tela MASTERFLIX quando chegar um pedido de teste. Isso é intencional
para validar a automação visual antes de tentar tornar o processo menos visível.
