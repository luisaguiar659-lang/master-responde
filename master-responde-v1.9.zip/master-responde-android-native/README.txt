MASTER RESPONDE v1.9

BASE ESTÁVEL:
v1.8.14

FUNÇÃO NOVA:
MENSAGENS E TEMPOS totalmente configuráveis dentro do aplicativo.

NOVO MÓDULO:
MENSAGENS E TEMPOS

1. GATILHOS RECEBIDOS
Podem ser alterados manualmente:
- gatilhos para gerar teste;
- gatilhos para nova revenda;
- comando para cancelar revenda;
- gatilho "teste bot";
- comando principal dos grupos;
- comandos/aliases das opções 0 a 8 do menu de grupos.

Os gatilhos aceitam várias linhas.
Exemplo:
teste
quero um teste
gerar teste

2. TEMPOS EM SEGUNDOS
Podem ser alterados manualmente:
- atraso antes de responder;
- intervalo mínimo entre respostas;
- intervalo entre mensagens de uma sequência/categoria;
- bloqueio de mensagem privada recebida repetida;
- bloqueio da mesma regra repetida;
- bloqueio de repetição em grupos;
- tempo que o menu do grupo permanece aberto.

Os tempos aceitam valores de 0 a 3600 segundos.

PADRÕES DA v1.9:
- atraso antes de responder: 1 segundo;
- intervalo mínimo entre respostas: 1 segundo;
- intervalo em sequências: 1 segundo;
- repetição privada: 12 segundos;
- repetição de regra: 10 segundos;
- repetição em grupos: 120 segundos;
- menu do grupo aberto: 120 segundos.

3. MENSAGENS ENVIADAS
Podem ser editadas manualmente:
- resposta do "teste bot";
- "Gerando seu teste...";
- falha ao gerar teste;
- link/instrução de cadastro de revenda;
- verificando e-mail de revenda;
- revenda confirmada + grupo de suporte;
- revenda não encontrada;
- cancelamento da revenda;
- revenda já vinculada;
- revisão manual;
- e-mail inválido;
- erro ao salvar e-mail;
- verificação ocupada;
- menu @infor;
- categoria de grupo não configurada;
- opção de grupo ainda indisponível;
- falar com suporte;
- opção de grupo não reconhecida.

Cada mensagem automática possui:
- texto editável;
- opção "Enviar esta mensagem" para ativar/desativar.

A mensagem de E-MAIL INVÁLIDO fica DESATIVADA por padrão para
preservar o comportamento estável da v1.8.14. Se desejar, basta ativá-la.

VARIÁVEIS DISPONÍVEIS:
{LINK_CADASTRO}
- insere o link de cadastro salvo em REVENDAS.

{LINK_GRUPO}
- insere o grupo de suporte salvo em REVENDAS.

{MOTIVO}
- insere o motivo da falha ao verificar a revenda.

{COMANDO_MENU}
- insere o comando principal do menu de grupos.

{CATEGORIA}
- insere o nome da categoria que ainda não foi configurada.

REGRAS E MÍDIAS:
- os textos criados manualmente em REGRAS continuam sendo configurados em REGRAS;
- as sequências criadas em MÍDIAS continuam sendo configuradas em MÍDIAS;
- ambos agora obedecem aos tempos definidos em MENSAGENS E TEMPOS.

CONTROLE DE DUPLICAÇÃO:
- o tempo de repetição de mensagens privadas agora é configurável;
- o tempo de repetição das regras agora é configurável;
- o bloqueio de grupos agora usa o tempo configurado de verdade;
- respostas para a mesma conversa passam por uma fila com atraso e
  intervalo mínimo configuráveis.

RESTAURAR PADRÕES:
O módulo possui o botão:
RESTAURAR PADRÕES DA v1.9

Ele remove somente as configurações desta nova tela e volta aos valores padrão.

PRESERVADO DA v1.8.14:
- geração automática de teste;
- teste em segundo plano;
- verificação de nova revenda pelo e-mail;
- envio do grupo de suporte após confirmar a revenda;
- link de cadastro editável;
- link de grupo editável;
- regras;
- categorias;
- menu de grupos;
- MASTERFLIX login/sessão;
- nenhuma ativação automática de créditos no fluxo atual da nova revenda.

OBSERVAÇÃO:
Atrasos muito longos podem fazer a notificação de resposta do WhatsApp
deixar de estar disponível. Para respostas normais, prefira tempos curtos.
