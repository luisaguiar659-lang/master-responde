MASTER RESPONDE v1.5.6

Base: v1.5.5.

CORREÇÃO ÚNICA:
- processar todas as mensagens recentes quando o WhatsApp Business
  agrupa várias mensagens na mesma notificação.

Problema observado:
ao enviar rapidamente:
1
2
3
4
5

o WhatsApp podia entregar uma única notificação contendo todas as mensagens.
O MASTER RESPONDE lia apenas EXTRA_TEXT, que representa normalmente
a última mensagem. Por isso apenas o 5 era executado.

Correção:
- agora o app lê Notification.EXTRA_MESSAGES;
- percorre todas as mensagens recentes do grupo;
- processa cada uma separadamente;
- mantém registro das mensagens já processadas;
- evita repetir mensagens que aparecem novamente em atualizações da notificação.

TESTE:
1. Envie @infor
2. Envie rapidamente:
   1
   2
   3
   4
   5
   6
3. Cada opção deve ser processada uma vez.

As categorias que ainda não foram configuradas em MÍDIAS
continuam mostrando o aviso normal de categoria não configurada.
