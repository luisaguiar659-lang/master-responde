MASTER RESPONDE v1.7.1

Base: v1.7.

CORREÇÕES DA ETAPA GERAR TESTE:

1. ROLAGEM DO PAINEL MASTERFLIX
- O WebView agora aceita a rolagem vertical por toque.
- O ScrollView externo do MASTER RESPONDE não deve mais bloquear
  a rolagem interna do painel.

2. LOCALIZAÇÃO DO TESTE
- A v1.7 procurava o texto de forma exata.
- No painel o nome aparece junto de um marcador/bolinha.
- Agora a busca aceita o nome dentro do texto do elemento:
  MASTERFLIX TESTE COMPLETO 1H

3. ROLAGEM AUTOMÁTICA
- Antes de clicar no teste, o bot usa scrollIntoView().
- Depois de gerar, procura o botão COPIAR em todo o DOM.
- Mesmo que COPIAR esteja no final da página, o bot rola até ele
  automaticamente e tenta clicar.

4. BOTÃO COPIAR
- Procura especificamente o botão cujo texto é COPIAR.
- Não usa COPIAR E FECHAR.
- Depois lê o clipboard e valida usuário/senha/M3U antes de enviar.

TESTE:
1. Mantenha a sessão MASTERFLIX ativa.
2. Envie "Teste" em conversa privada.
3. O bot responde "Gerando seu teste, aguarde..."
4. A tela MASTERFLIX abre.
5. Observe o status azul.
6. O bot deve localizar MASTERFLIX TESTE COMPLETO 1H.
7. Deve abrir Detalhes do Cliente.
8. Deve localizar COPIAR mesmo se estiver abaixo da área visível.
9. Deve enviar o bloco completo ao mesmo WhatsApp.

AINDA NÃO EXISTE:
- nova revenda;
- créditos +50;
- automação da opção 7 de grupos.
