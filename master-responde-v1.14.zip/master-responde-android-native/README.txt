MASTER RESPONDE v1.14 — MOTOR UNIFICADO

BASE ESTÁVEL:
v1.13.1

OBJETIVO:
Fazer tudo que já está implementado usar o mesmo motor com o aplicativo
ABERTO ou EM SEGUNDO PLANO.

REVISÃO REALIZADA:

1. WHATSAPP BUSINESS
- NotificationAccessService continua sendo o ponto único de entrada.
- O app aberto não troca o motor.
- O app em segundo plano usa exatamente o mesmo motor.
- Ao ligar o Bot, o app solicita reconexão do listener.
- Ao abrir o MASTER RESPONDE, o listener é reconectado se necessário.
- Se o Android desconectar o listener, a v1.14 solicita rebind automaticamente.
- Após reiniciar o celular ou atualizar o APK, o app tenta restaurar o listener.

2. MENSAGENS PRIVADAS
- Mensagens individuais continuam usando regras simples.
- Gatilhos configuráveis continuam funcionando.
- O histórico EXTRA_MESSAGES do WhatsApp também é lido para mensagens
  privadas rápidas/batidas, como já era feito nos grupos.
- Cada mensagem recente recebe um identificador próprio antes da deduplicação.
- O bloqueio de repetição continua respeitando os segundos configurados.

3. RESPOSTAS
- Atraso antes da resposta continua configurável.
- Intervalo mínimo continua configurável.
- O horário da fila por conversa agora também fica persistido no aparelho,
  reduzindo respostas coladas depois de uma recriação do processo.

4. @infor NOS GRUPOS
- Continua exclusivo para grupos.
- Categorias MÍDIAS continuam exclusivas do @infor.
- Textos e LINKS continuam sendo enviados na ordem cadastrada.
- Fotos continuam apenas armazenadas localmente.
- O período em que o menu @infor fica aberto agora também é persistido,
  portanto uma recriação do processo não fecha imediatamente o menu.
- Deduplicação de grupos continua ativa.

5. TESTE MASTERFLIX
- Gatilho privado de teste continua configurável.
- A geração usa WebView oculto em segundo plano independentemente de o
  MASTER RESPONDE estar aberto ou fechado.
- A sessão/cookies são os mesmos do painel.
- A tarefa fica marcada como pendente enquanto está executando.
- Se o processo for recriado e a notificação do cliente ainda existir,
  a v1.14 tenta recuperar a geração.
- Tarefas presas expiram e são liberadas.
- CAPTCHA/verificação humana nunca é contornado.
- Sessão MASTERFLIX expirada ainda exige login manual.

6. NOVA REVENDA
Fluxo preservado:
- "Quero ser Revenda";
- envia link de cadastro;
- recebe e-mail;
- verifica o e-mail no MASTERFLIX em WebView oculto;
- se a revenda existir, envia mensagem configurável + link do grupo;
- NÃO adiciona créditos;
- NÃO ativa painel automaticamente.

Melhorias:
- a verificação fica marcada como pendente;
- se o processo for recriado, o motor tenta retomar a verificação;
- se a mesma conversa gerar uma nova notificação, ela também pode servir
  para retomar a tarefa;
- cancelamento agora interrompe também o WebView oculto;
- o e-mail temporário é removido quando a verificação termina;
- tarefa expirada volta para WAITING_EMAIL em vez de ficar presa.

7. MASTERFLIX — TRAVA GLOBAL
Antes:
- geração de teste e verificação de revenda possuíam travas separadas.

Agora:
- existe uma única trava MASTERFLIX para automações em segundo plano;
- teste e verificação de revenda não executam ao mesmo tempo;
- isso evita dois WebViews disputando a mesma sessão/cookies.

8. DASHBOARD
- novo status MOTOR;
- mostra:
  * Bot desligado
  * Sem permissão
  * Reconectando
  * 2º plano ativo
- WhatsApp mostra "Motor conectado" quando o listener realmente conectou.
- removido atalho antigo "Créditos +50", pois não pertence mais ao fluxo atual.
- atalho Mídias / Links abre função real.
- atalho @infor grupos agora abre a tela de Grupos.
- removida a retomada visual antiga de crédito de revenda do MainActivity.

9. REINÍCIO / ATUALIZAÇÃO
Foi adicionado um receiver para:
- BOOT_COMPLETED
- MY_PACKAGE_REPLACED

Se o Bot estiver ligado e a permissão de notificações continuar concedida,
o MASTER RESPONDE solicita reconexão do motor.

LIMITES DO ANDROID:
- "Segundo plano" significa o app fechado/minimizado normalmente.
- Se o usuário usar FORÇAR PARADA, o Android bloqueia o aplicativo até
  ele ser aberto novamente; nenhum app pode ignorar esse bloqueio.
- fabricantes podem aplicar economia de bateria agressiva.
- respostas dependem da ação de resposta da notificação do WhatsApp Business.
- MASTERFLIX depende de uma sessão válida.
- CAPTCHA/verificação manual continua manual.

PRESERVADO:
- Bot liga/desliga;
- WhatsApp Business;
- regras privadas simples;
- Mensagens e Tempos;
- gatilhos editáveis;
- deduplicação;
- categorias exclusivas do @infor;
- textos e links das categorias;
- fotos salvas localmente;
- nova revenda;
- grupo de suporte editável;
- link de cadastro editável;
- teste MASTERFLIX;
- login/sessão MASTERFLIX;
- sem Acessibilidade para fotos.
