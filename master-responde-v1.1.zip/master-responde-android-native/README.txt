MASTER RESPONDE v1.1

Adicionado:
- Bot liga/desliga.
- Estado salvo ao fechar/reabrir.
- Detecta WhatsApp Business instalado.
- Detecta acesso às notificações.
- Abre tela de acesso às notificações.
- NotificationListenerService criado sem autoresposta.

Teste:
1. Instale.
2. Ligue o Bot.
3. Feche e abra: deve continuar ligado.
4. Toque em LIBERAR ACESSO ÀS NOTIFICAÇÕES.
5. Ative MASTER RESPONDE.
6. Volte ao app.
7. O card WhatsApp Business deve mostrar Acesso liberado.

Autoresposta entra na v1.2.
