package com.masterresponde.app;

import android.service.notification.NotificationListenerService;

public class NotificationAccessService extends NotificationListenerService {
}
