MASTER RESPONDE v1.2

Base aprovada:
- v1.0: dashboard
- v1.1.1: Bot liga/desliga + acesso às notificações

ÚNICA função nova desta versão:
- primeira autoresposta de texto no WhatsApp Business.

Como testar:
1. Instale a v1.2.
2. Abra o MASTER RESPONDE.
3. Deixe:
   - Bot = Ativo
   - WhatsApp Business = Acesso liberado
4. Use OUTRO número para mandar ao WhatsApp Business:
   teste bot
5. A resposta esperada é:
   ✅ MASTER RESPONDE ativo e funcionando.

Importante:
- O gatilho desta versão é fixo: "teste bot".
- A resposta desta versão também é fixa.
- Ainda NÃO existem regras, grupos, MASTERFLIX, revendas ou mídia.
- Só depois deste teste funcionar adicionaremos regras configuráveis na próxima etapa.
