package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.text.Normalizer;
import java.util.Locale;

public class NotificationAccessService extends NotificationListenerService {

    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";
    private static final String TRIGGER = "teste bot";
    private static final String REPLY = "✅ MASTER RESPONDE ativo e funcionando.";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (!WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        SharedPreferences prefs = getSharedPreferences("master_responde", MODE_PRIVATE);
        if (!prefs.getBoolean("bot_enabled", false)) return;

        Notification notification = sbn.getNotification();
        if (notification == null) return;

        String incoming = extractLatestText(notification);
        if (incoming == null || incoming.trim().isEmpty()) return;

        if (!TRIGGER.equals(normalize(incoming))) return;

        String fingerprint = sbn.getKey() + "|" + incoming;
        long now = System.currentTimeMillis();

        String lastFingerprint = prefs.getString("last_fingerprint", "");
        long lastTime = prefs.getLong("last_fingerprint_time", 0L);

        if (fingerprint.equals(lastFingerprint) && (now - lastTime) < 10000L) {
            return;
        }

        boolean sent = sendReply(notification, REPLY);

        prefs.edit()
                .putString("last_fingerprint", fingerprint)
                .putLong("last_fingerprint_time", now)
                .putString(
                        "last_test_status",
                        sent ? "Último teste: resposta enviada" : "Último teste: não foi possível responder"
                )
                .apply();
    }

    private String extractLatestText(Notification notification) {
        Bundle extras = notification.extras;
        if (extras == null) return null;

        Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);

        if (messages != null && messages.length > 0) {
            Parcelable last = messages[messages.length - 1];

            if (last instanceof Bundle) {
                Notification.MessagingStyle.Message message =
                        Notification.MessagingStyle.Message.getMessageFromBundle((Bundle) last);

                if (message != null && message.getText() != null) {
                    return message.getText().toString();
                }
            }
        }

        CharSequence text = extras.getCharSequence(Notification.EXTRA_TEXT);
        return text == null ? null : text.toString();
    }

    private boolean sendReply(Notification notification, String text) {
        Notification.Action[] actions = notification.actions;
        if (actions == null) return false;

        for (Notification.Action action : actions) {
            if (action == null || action.actionIntent == null) continue;

            RemoteInput[] remoteInputs = action.getRemoteInputs();
            if (remoteInputs == null || remoteInputs.length == 0) continue;

            for (RemoteInput input : remoteInputs) {
                if (input == null || !input.getAllowFreeFormInput()) continue;

                try {
                    Intent intent = new Intent();
                    Bundle bundle = new Bundle();
                    bundle.putCharSequence(input.getResultKey(), text);

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            bundle
                    );

                    action.actionIntent.send(this, 0, intent);
                    return true;

                } catch (PendingIntent.CanceledException ignored) {
                    return false;
                }
            }
        }

        return false;
    }

    private String normalize(String value) {
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");

        return normalized
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
