MASTER RESPONDE v1.17.4

CORREÇÃO FOCADA NA CAPTURA DO TESTE

Base: v1.17.3.

O vídeo de referência mostrou o fluxo real do painel Sigma:
- o teste é gerado;
- a tela/caixa "Detalhes do Cliente" contém o conteúdo;
- o painel oferece COPIAR ou COPIAR E FECHAR;
- o próprio painel coloca o texto na área de transferência.

A v1.17.4 não altera revenda, @infor, regras, mídias, mensagens, sessão Sigma,
assinatura ou demais fluxos.

ALTERAÇÕES NO TESTE
1. O motor procura tanto COPIAR quanto COPIAR E FECHAR.
2. Antes de clicar, captura o conteúdo do contêiner que envolve o botão.
3. Depois do clique, continua ouvindo a área de transferência pela ponte JavaScript.
4. Se o clipboard não retornar texto, procura diretamente o contêiner
   "Detalhes do Cliente".
5. A leitura do DOM agora aceita diferentes formatos de teste Sigma.
6. A validação não exige mais obrigatoriamente M3U + usuário + senha ao mesmo tempo.
   Ela considera múltiplos sinais: URL, usuário, senha, M3U/get.php, DNS,
   plano, vencimento e conexões.
7. Controles de interface como COPIAR, COPIAR E FECHAR, FECHAR e CANCELAR são
   removidos antes do envio.
8. A leitura de Detalhes do Cliente repete por alguns segundos antes de declarar falha.

ASSINATURA
Mantém a assinatura release permanente já configurada.
Use os mesmos 4 GitHub Repository Secrets.

VERSÃO
1.17.4
versionCode 48
