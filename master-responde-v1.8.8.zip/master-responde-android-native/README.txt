MASTER RESPONDE v1.8.8

Base: v1.8.7.

CORREÇÃO ÚNICA:
A área "Adicionar Créditos" do MASTERFLIX não é tratada mais como
um modal/dialog específico.

AGORA O BOT:
1. encontra o cartão da revenda pelo e-mail exato;
2. clica em "Adicionar Créditos";
3. procura em TODA a página pelo texto:
   "Eu concordo em transferir..."
4. usa esse texto como referência para encontrar:
   - o campo de créditos;
   - a caixa de concordância;
   - o botão final;
5. preenche 50;
6. marca a concordância;
7. clica no botão final UMA ÚNICA VEZ;
8. não lê saldo;
9. considera concluído quando a área/texto de transferência desaparecer;
10. envia a confirmação + link editável do grupo de suporte.

PRESERVADO:
- correção de duplicação da v1.8.7;
- sem pedir CONFIRMAR;
- sem leitura de saldo;
- link do grupo de suporte editável;
- link de cadastro editável;
- proteção contra clique duplicado;
- geração de testes em segundo plano.
