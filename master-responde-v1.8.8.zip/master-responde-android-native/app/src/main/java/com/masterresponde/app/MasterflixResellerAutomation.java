package com.masterresponde.app;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;

public class MasterflixResellerAutomation {

    private static final String RESELLERS_URL =
            "https://masterflix.sigmab.pro/#/resellers";

    private static final int CREDIT_AMOUNT = 50;

    private static final String MODE_FIND =
            "find";

    private static final String MODE_ADD =
            "add";

    private static final Object LOCK =
            new Object();

    private static MasterflixResellerAutomation current;

    private final Context context;
    private final Notification whatsappNotification;
    private final SharedPreferences prefs;
    private final String contactKey;
    private final String email;
    private final String mode;

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private WebView webView;

    private boolean finished = false;
    private boolean pageReady = false;
    private boolean submitAttempted = false;

    private int searchAttempts = 0;
    private int dialogAttempts = 0;
    private int verifyAttempts = 0;
    private int completionAttempts = 0;

    private double beforeCredits = Double.NaN;

    private MasterflixResellerAutomation(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email,
            String mode
    ) {
        this.context =
                context.getApplicationContext();

        this.whatsappNotification =
                notification;

        this.prefs =
                prefs;

        this.contactKey =
                contactKey;

        this.email =
                email == null
                        ? ""
                        : email.trim().toLowerCase(Locale.ROOT);

        this.mode =
                mode;
    }

    public static boolean findReseller(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email
    ) {
        return start(
                context,
                notification,
                prefs,
                contactKey,
                email,
                MODE_FIND
        );
    }

    public static boolean addCredits(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email
    ) {
        return start(
                context,
                notification,
                prefs,
                contactKey,
                email,
                MODE_ADD
        );
    }

    private static boolean start(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email,
            String mode
    ) {
        synchronized (LOCK) {
            if (current != null
                    && !current.finished) {
                return false;
            }

            current =
                    new MasterflixResellerAutomation(
                            context,
                            notification,
                            prefs,
                            contactKey,
                            email,
                            mode
                    );

            current.handler.post(
                    current::createAndStart
            );

            return true;
        }
    }

    private void createAndStart() {
        try {
            updateStatus(
                    MODE_FIND.equals(mode)
                            ? "Revenda: procurando cadastro no MASTERFLIX"
                            : "Revenda: preparando crédito inicial +50"
            );

            webView =
                    new WebView(context);

            WebSettings settings =
                    webView.getSettings();

            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadsImagesAutomatically(true);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);

            CookieManager cookieManager =
                    CookieManager.getInstance();

            cookieManager.setAcceptCookie(true);

            if (android.os.Build.VERSION.SDK_INT >= 21) {
                cookieManager.setAcceptThirdPartyCookies(
                        webView,
                        true
                );
            }

            webView.setWebViewClient(
                    new WebViewClient() {

                        @Override
                        public void onPageFinished(
                                WebView view,
                                String url
                        ) {
                            super.onPageFinished(
                                    view,
                                    url
                            );

                            inspectLocation();
                        }

                        @Override
                        public void doUpdateVisitedHistory(
                                WebView view,
                                String url,
                                boolean isReload
                        ) {
                            super.doUpdateVisitedHistory(
                                    view,
                                    url,
                                    isReload
                            );

                            inspectLocation();
                        }
                    }
            );

            webView.loadUrl(
                    RESELLERS_URL
            );

            handler.postDelayed(
                    () -> {
                        if (!finished
                                && !pageReady) {
                            confirmLoadState();
                        }
                    },
                    12000L
            );

        } catch (Throwable e) {
            failBeforeSubmit(
                    "Não foi possível iniciar o MASTERFLIX em segundo plano."
            );
        }
    }

    private void inspectLocation() {
        if (finished
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (finished) return;

                    if (url.contains("#/resellers")) {
                        if (!pageReady) {
                            pageReady =
                                    true;

                            prefs.edit()
                                    .putBoolean(
                                            "masterflix_session_active",
                                            true
                                    )
                                    .apply();

                            handler.postDelayed(
                                    this::searchExactEmail,
                                    1000L
                            );
                        }

                    } else if (url.contains("#/sign-in")) {
                        prefs.edit()
                                .putBoolean(
                                        "masterflix_session_active",
                                        false
                                )
                                .apply();

                        handler.postDelayed(
                                this::confirmStillOnLogin,
                                1600L
                        );
                    }
                }
        );
    }

    private void confirmLoadState() {
        if (finished
                || pageReady
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (url.contains("#/sign-in")) {
                        failBeforeSubmit(
                                "Sessão MASTERFLIX expirada. Abra o app e renove o login."
                        );
                    } else if (!pageReady) {
                        failBeforeSubmit(
                                "A página de revendas não carregou."
                        );
                    }
                }
        );
    }

    private void confirmStillOnLogin() {
        if (finished
                || pageReady
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (url.contains("#/sign-in")) {
                        failBeforeSubmit(
                                "Sessão MASTERFLIX expirada. Abra o app e renove o login."
                        );
                    }
                }
        );
    }

    private void searchExactEmail() {
        if (finished
                || webView == null) {
            return;
        }

        searchAttempts++;

        String emailJson =
                JSONObject.quote(
                        email
                );

        String script =
                "(function(){" +
                        "var wanted=" + emailJson + ";" +

                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var st=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0" +
                        "&&st.display!=='none'" +
                        "&&st.visibility!=='hidden';" +
                        "}" +

                        "function setValue(el,v){" +
                        "if(!el)return false;" +
                        "try{" +
                        "var proto=el.tagName==='TEXTAREA'" +
                        "?HTMLTextAreaElement.prototype" +
                        ":HTMLInputElement.prototype;" +
                        "var setter=Object.getOwnPropertyDescriptor(proto,'value').set;" +
                        "setter.call(el,v);" +
                        "}catch(e){el.value=v;}" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'a'}));" +
                        "return true;" +
                        "}" +

                        "var inputs=document.querySelectorAll('input,textarea');" +
                        "var search=null;" +

                        "for(var i=0;i<inputs.length;i++){" +
                        "var el=inputs[i];" +
                        "if(!visible(el))continue;" +
                        "var hint=((el.placeholder||'')+' '+(el.getAttribute('aria-label')||'')).toLowerCase();" +
                        "var type=(el.type||'').toLowerCase();" +
                        "if(type==='search'" +
                        "||hint.indexOf('buscar')!==-1" +
                        "||hint.indexOf('pesquisar')!==-1" +
                        "||hint.indexOf('search')!==-1" +
                        "||hint.indexOf('email')!==-1){" +
                        "search=el;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(search){" +
                        "setValue(search,wanted);" +
                        "try{search.focus();}catch(e){}" +
                        "}" +

                        "return search?'search_set':'no_search';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> handler.postDelayed(
                        this::inspectExactEmail,
                        700L
                )
        );
    }

    private void inspectExactEmail() {
        if (finished
                || webView == null) {
            return;
        }

        String emailJson =
                JSONObject.quote(
                        email
                );

        String script =
                "(function(){" +
                        "var wanted=" + emailJson + ".toLowerCase();" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best=null;" +
                        "var bestLen=999999;" +

                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=(el.innerText||el.textContent||'').trim();" +
                        "if(!text)continue;" +
                        "var low=text.toLowerCase();" +

                        "if(low===wanted" +
                        "||low.indexOf(wanted)!==-1){" +
                        "if(text.length<bestLen){" +
                        "best=el;" +
                        "bestLen=text.length;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!best){" +
                        "return JSON.stringify({found:false});" +
                        "}" +

                        "var row=best.closest('tr,[role=row]');" +

                        "if(!row){" +
                        "var p=best;" +
                        "for(var d=0;d<7&&p;d++,p=p.parentElement){" +
                        "var buttons=p.querySelectorAll('button,a,[role=button]');" +
                        "var text=(p.innerText||'');" +
                        "if(buttons.length>0&&text.toLowerCase().indexOf(wanted)!==-1){" +
                        "row=p;" +
                        "break;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!row){row=best.parentElement||best;}" +

                        "var rowText=(row.innerText||row.textContent||'').trim();" +

                        "return JSON.stringify({" +
                        "found:true," +
                        "text:rowText" +
                        "});" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String decoded =
                            decodeJavascriptString(
                                    value
                            );

                    try {
                        JSONObject result =
                                new JSONObject(
                                        decoded
                                );

                        boolean found =
                                result.optBoolean(
                                        "found",
                                        false
                                );

                        if (found) {
                            if (MODE_FIND.equals(mode)) {
                                foundForConfirmation();
                            } else {
                                openAddCreditsForExactEmail();
                            }

                            return;
                        }

                    } catch (Exception ignored) {
                    }

                    if (searchAttempts < 20) {
                        handler.postDelayed(
                                this::searchExactEmail,
                                650L
                        );
                    } else {
                        failBeforeSubmit(
                                "Não encontrei o e-mail exato da revenda no MASTERFLIX."
                        );
                    }
                }
        );
    }

    private void foundForConfirmation() {
        if (finished) return;

        finished =
                true;

        setState(
                "WAITING_CONFIRM"
        );

        updateStatus(
                "Revenda encontrada. Aguardando CONFIRMAR."
        );

        WhatsAppReply.send(
                context,
                whatsappNotification,
                "Encontrei o cadastro " +
                        email +
                        " no MASTERFLIX.\n\n" +
                        "Responda *CONFIRMAR* para adicionar 50 créditos."
        );

        cleanup();
    }

    private void openAddCreditsForExactEmail() {
        if (finished
                || webView == null) {
            return;
        }

        String emailJson =
                JSONObject.quote(
                        email
                );

        String script =
                "(function(){" +
                        "var wanted=" + emailJson + ".toLowerCase();" +

                        "function n(v){" +
                        "return (v||'').replace(/\\s+/g,' ').trim();" +
                        "}" +

                        "function norm(v){" +
                        "return n(v).toLowerCase();" +
                        "}" +

                        // 1. Localiza o elemento mais específico que contém o e-mail.
                        "var all=document.querySelectorAll('body *');" +
                        "var emailEl=null;" +
                        "var bestLen=999999;" +

                        "for(var i=0;i<all.length;i++){" +
                        "var text=n(all[i].innerText||all[i].textContent);" +
                        "if(!text)continue;" +
                        "var low=text.toLowerCase();" +

                        "if(low===wanted||low.indexOf(wanted)!==-1){" +
                        "if(text.length<bestLen){" +
                        "emailEl=all[i];" +
                        "bestLen=text.length;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!emailEl){" +
                        "return JSON.stringify({ok:false,reason:'email'});" +
                        "}" +

                        // 2. Sobe pelos ancestrais até encontrar o CARTÃO da revenda:
                        // deve conter o e-mail e também o texto Adicionar Créditos.
                        "var card=null;" +
                        "var p=emailEl;" +

                        "for(var d=0;d<14&&p;d++,p=p.parentElement){" +
                        "var txt=norm(p.innerText||p.textContent);" +

                        "if(txt.indexOf(wanted)!==-1" +
                        "&&(txt.indexOf('adicionar créditos')!==-1" +
                        "||txt.indexOf('adicionar creditos')!==-1)){" +
                        "card=p;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!card){" +
                        "return JSON.stringify({ok:false,reason:'card'});" +
                        "}" +

                        // 3. Dentro do MESMO cartão, procura exatamente o rótulo.
                        "var descendants=card.querySelectorAll('*');" +
                        "var label=null;" +
                        "var labelLen=999999;" +

                        "for(var j=0;j<descendants.length;j++){" +
                        "var t=n(descendants[j].innerText||descendants[j].textContent);" +
                        "var low=t.toLowerCase();" +

                        "if(low==='adicionar créditos'" +
                        "||low==='adicionar creditos'){" +
                        "if(t.length<labelLen){" +
                        "label=descendants[j];" +
                        "labelLen=t.length;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!label){" +
                        "return JSON.stringify({ok:false,reason:'label'});" +
                        "}" +

                        // 4. O texto pode ficar abaixo do botão roxo.
                        // Primeiro tenta um ancestral clicável do texto.
                        "var clickable=label.closest(" +
                        "'button,a,[role=button],[tabindex],[onclick]'" +
                        ");" +

                        // 5. Se o rótulo for irmão do botão, procura nos pais próximos.
                        "if(!clickable){" +
                        "var q=label.parentElement;" +

                        "for(var x=0;x<6&&q&&!clickable;x++,q=q.parentElement){" +
                        "var candidates=q.querySelectorAll(" +
                        "'button,a,[role=button],[tabindex],[onclick]'" +
                        ");" +

                        "if(candidates.length===1){" +
                        "clickable=candidates[0];" +
                        "break;" +
                        "}" +

                        "for(var c=0;c<candidates.length;c++){" +
                        "var meta=norm(" +
                        "(candidates[c].innerText||candidates[c].textContent||'')+' '+" +
                        "(candidates[c].getAttribute('aria-label')||'')+' '+" +
                        "(candidates[c].getAttribute('title')||'')" +
                        ");" +

                        "if(meta.indexOf('adicionar')!==-1" +
                        "||meta.indexOf('credit')!==-1){" +
                        "clickable=candidates[c];" +
                        "break;" +
                        "}" +
                        "}" +
                        "}" +
                        "}" +

                        // 6. Último fallback: o próprio bloco do rótulo/pai.
                        "if(!clickable){" +
                        "clickable=label.parentElement||label;" +
                        "}" +

                        "try{" +
                        "clickable.scrollIntoView({behavior:'auto',block:'center'});" +
                        "}catch(e){}" +

                        "try{" +
                        "clickable.click();" +
                        "}catch(e){" +
                        "try{" +
                        "clickable.dispatchEvent(new MouseEvent(" +
                        "'click'," +
                        "{bubbles:true,cancelable:true,view:window}" +
                        "));" +
                        "}catch(e2){" +
                        "return JSON.stringify({ok:false,reason:'click'});" +
                        "}" +
                        "}" +

                        "return JSON.stringify({ok:true});" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String decoded =
                            decodeJavascriptString(
                                    value
                            );

                    try {
                        JSONObject result =
                                new JSONObject(
                                        decoded
                                );

                        if (!result.optBoolean(
                                "ok",
                                false
                        )) {
                            String reason =
                                    result.optString(
                                            "reason",
                                            ""
                                    );

                            if ("email".equals(reason)) {
                                failBeforeSubmit(
                                        "Não consegui localizar exatamente a revenda pelo e-mail. Nenhum crédito foi enviado."
                                );

                            } else if ("card".equals(reason)
                                    || "label".equals(reason)) {

                                failBeforeSubmit(
                                        "Encontrei a revenda pelo e-mail, mas não localizei “Adicionar Créditos” dentro do cartão dela. Nenhum crédito foi enviado."
                                );

                            } else {
                                failBeforeSubmit(
                                        "Encontrei o botão de créditos, mas não consegui abri-lo. Nenhum crédito foi enviado."
                                );
                            }

                            return;
                        }

                        dialogAttempts = 0;

                        updateStatus(
                                "Revenda encontrada; abrindo Adicionar Créditos"
                        );

                        handler.postDelayed(
                                this::fillCreditDialog,
                                700L
                        );

                    } catch (Exception e) {
                        failBeforeSubmit(
                                "Não consegui abrir a janela de adicionar créditos. Nenhum crédito foi enviado."
                        );
                    }
                }
        );
    }

    private void fillCreditDialog() {
        if (finished
                || webView == null
                || submitAttempted) {
            return;
        }

        dialogAttempts++;

        String script =
                "(function(){" +

                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var st=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0" +
                        "&&st.display!=='none'" +
                        "&&st.visibility!=='hidden';" +
                        "}" +

                        "function n(v){" +
                        "return (v||'').replace(/\\s+/g,' ').trim().toLowerCase();" +
                        "}" +

                        "function setValue(el,v){" +
                        "if(!el)return false;" +
                        "try{" +
                        "var proto=el.tagName==='TEXTAREA'" +
                        "?HTMLTextAreaElement.prototype" +
                        ":HTMLInputElement.prototype;" +
                        "var setter=Object.getOwnPropertyDescriptor(proto,'value').set;" +
                        "setter.call(el,v);" +
                        "}catch(e){el.value=v;}" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "return true;" +
                        "}" +

                        // Procura o texto de autorização em QUALQUER layout.
                        "var all=document.querySelectorAll('body *');" +
                        "var agreementEl=null;" +
                        "var bestLen=999999;" +

                        "for(var i=0;i<all.length;i++){" +
                        "var txt=n(all[i].innerText||all[i].textContent);" +
                        "if(!txt)continue;" +

                        "if(txt.indexOf('concordo em transferir')!==-1" +
                        "||txt.indexOf('eu concordo')!==-1" +
                        "||txt.indexOf('transferir 50 créditos')!==-1" +
                        "||txt.indexOf('transferir 50 creditos')!==-1){" +
                        "if(txt.length<bestLen){" +
                        "agreementEl=all[i];" +
                        "bestLen=txt.length;" +
                        "}" +
                        "}" +
                        "}" +

                        // Se ainda não apareceu, aguarda.
                        "if(!agreementEl){" +
                        "return JSON.stringify({ok:false,reason:'agreement'});" +
                        "}" +

                        // Sobe até o menor contêiner que tenha:
                        // campo de entrada + checkbox + autorização.
                        "var container=null;" +
                        "var p=agreementEl;" +

                        "for(var d=0;d<10&&p;d++,p=p.parentElement){" +
                        "var text=n(p.innerText||p.textContent);" +
                        "var hasInput=p.querySelector('input:not([type=checkbox]):not([type=radio]),textarea');" +
                        "var hasCheck=p.querySelector('input[type=checkbox],[role=checkbox]');" +

                        "if(text.indexOf('transferir')!==-1" +
                        "&&hasInput" +
                        "&&hasCheck){" +
                        "container=p;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!container){" +
                        "container=document.body;" +
                        "}" +

                        // Campo numérico / créditos.
                        "var inputs=container.querySelectorAll('input,textarea');" +
                        "var creditInput=null;" +

                        "for(var j=0;j<inputs.length;j++){" +
                        "var el=inputs[j];" +
                        "if(!visible(el))continue;" +
                        "var type=(el.type||'').toLowerCase();" +
                        "if(type==='checkbox'||type==='radio'||type==='hidden')continue;" +

                        "var meta=n(" +
                        "(el.placeholder||'')+' '+" +
                        "(el.getAttribute('aria-label')||'')+' '+" +
                        "(el.name||'')" +
                        ");" +

                        "if(type==='number'" +
                        "||meta.indexOf('credit')!==-1" +
                        "||meta.indexOf('quant')!==-1" +
                        "||meta.indexOf('valor')!==-1){" +
                        "creditInput=el;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!creditInput){" +
                        "var candidates=[];" +

                        "for(var k=0;k<inputs.length;k++){" +
                        "var t=(inputs[k].type||'').toLowerCase();" +
                        "if(visible(inputs[k])" +
                        "&&t!=='checkbox'" +
                        "&&t!=='radio'" +
                        "&&t!=='hidden'){" +
                        "candidates.push(inputs[k]);" +
                        "}" +
                        "}" +

                        "if(candidates.length===1){" +
                        "creditInput=candidates[0];" +
                        "}" +
                        "}" +

                        "if(!creditInput){" +
                        "return JSON.stringify({ok:false,reason:'input'});" +
                        "}" +

                        "setValue(creditInput,'50');" +

                        // Checkbox da autorização.
                        "var checkbox=null;" +
                        "var checks=container.querySelectorAll('input[type=checkbox],[role=checkbox]');" +

                        "for(var q=0;q<checks.length;q++){" +
                        "var cb=checks[q];" +
                        "if(!visible(cb))continue;" +

                        "var ctx='';" +
                        "var cp=cb;" +

                        "for(var u=0;u<4&&cp;u++,cp=cp.parentElement){" +
                        "ctx=n(cp.innerText||cp.textContent);" +
                        "if(ctx.indexOf('concordo')!==-1" +
                        "||ctx.indexOf('transferir')!==-1){" +
                        "checkbox=cb;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(checkbox)break;" +
                        "}" +

                        "if(!checkbox&&checks.length===1&&visible(checks[0])){" +
                        "checkbox=checks[0];" +
                        "}" +

                        "if(!checkbox){" +
                        "return JSON.stringify({ok:false,reason:'checkbox'});" +
                        "}" +

                        "try{" +
                        "checkbox.scrollIntoView({behavior:'auto',block:'center'});" +
                        "}catch(e){}" +

                        "var role=(checkbox.getAttribute('role')||'').toLowerCase();" +
                        "var type=(checkbox.type||'').toLowerCase();" +

                        "if(type==='checkbox'){" +
                        "if(!checkbox.checked){" +
                        "try{checkbox.click();}catch(e){" +
                        "checkbox.checked=true;" +
                        "checkbox.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "checkbox.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "}" +
                        "}" +

                        "if(!checkbox.checked){" +
                        "return JSON.stringify({ok:false,reason:'checkbox_failed'});" +
                        "}" +

                        "}else if(role==='checkbox'){" +
                        "if(checkbox.getAttribute('aria-checked')!=='true'){" +
                        "try{checkbox.click();}catch(e){}" +
                        "}" +
                        "}" +

                        "return JSON.stringify({ok:true});" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String decoded =
                            decodeJavascriptString(
                                    value
                            );

                    try {
                        JSONObject result =
                                new JSONObject(
                                        decoded
                                );

                        if (result.optBoolean(
                                "ok",
                                false
                        )) {
                            updateStatus(
                                    "Revenda: 50 preenchido e autorização marcada"
                            );

                            handler.postDelayed(
                                    this::submitCreditsOnce,
                                    500L
                            );

                            return;
                        }

                        String reason =
                                result.optString(
                                        "reason",
                                        ""
                                );

                        if (dialogAttempts < 28) {
                            handler.postDelayed(
                                    this::fillCreditDialog,
                                    450L
                            );

                            return;
                        }

                        if ("agreement".equals(reason)) {
                            failBeforeSubmit(
                                    "Abri Adicionar Créditos, mas não encontrei a confirmação de transferência. Nenhum crédito foi enviado."
                            );

                        } else if ("input".equals(reason)) {
                            failBeforeSubmit(
                                    "Abri Adicionar Créditos, mas não encontrei o campo para informar 50 créditos. Nenhum crédito foi enviado."
                            );

                        } else if ("checkbox".equals(reason)
                                || "checkbox_failed".equals(reason)) {

                            failBeforeSubmit(
                                    "Abri Adicionar Créditos, mas não consegui marcar “Eu concordo em transferir 50 créditos”. Nenhum crédito foi enviado."
                            );

                        } else {
                            failBeforeSubmit(
                                    "A área de adicionar créditos não apareceu corretamente. Nenhum crédito foi enviado."
                            );
                        }

                    } catch (Exception e) {
                        if (dialogAttempts < 28) {
                            handler.postDelayed(
                                    this::fillCreditDialog,
                                    450L
                            );
                        } else {
                            failBeforeSubmit(
                                    "A área de adicionar créditos não apareceu corretamente. Nenhum crédito foi enviado."
                            );
                        }
                    }
                }
        );
    }

    private void submitCreditsOnce() {
        if (finished
                || webView == null
                || submitAttempted) {
            return;
        }

        // Reserva antes do clique final para impedir duplicação.
        submitAttempted =
                true;

        prefs.edit()
                .putBoolean(
                        "reseller_submit_attempted_" + contactKey,
                        true
                )
                .putLong(
                        "reseller_submit_time_" + contactKey,
                        System.currentTimeMillis()
                )
                .putString(
                        "reseller_submit_email_" + contactKey,
                        email
                )
                .commit();

        String script =
                "(function(){" +

                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var st=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0" +
                        "&&st.display!=='none'" +
                        "&&st.visibility!=='hidden';" +
                        "}" +

                        "function n(v){" +
                        "return (v||'').replace(/\\s+/g,' ').trim().toLowerCase();" +
                        "}" +

                        // Localiza novamente a autorização.
                        "var all=document.querySelectorAll('body *');" +
                        "var agreement=null;" +
                        "var bestLen=999999;" +

                        "for(var i=0;i<all.length;i++){" +
                        "var txt=n(all[i].innerText||all[i].textContent);" +

                        "if(txt.indexOf('concordo em transferir')!==-1" +
                        "||txt.indexOf('eu concordo')!==-1){" +
                        "if(txt.length<bestLen){" +
                        "agreement=all[i];" +
                        "bestLen=txt.length;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!agreement){" +
                        "return 'no_agreement';" +
                        "}" +

                        // Sobe até o bloco que contém também o botão final.
                        "var container=null;" +
                        "var p=agreement;" +

                        "for(var d=0;d<10&&p;d++,p=p.parentElement){" +
                        "var buttons=p.querySelectorAll('button,a,[role=button],[tabindex]');" +
                        "var text=n(p.innerText||p.textContent);" +

                        "if(buttons.length>0" +
                        "&&text.indexOf('transferir')!==-1){" +
                        "container=p;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!container)container=document.body;" +

                        "var buttons=container.querySelectorAll('button,a,[role=button],[tabindex]');" +
                        "var submit=null;" +

                        // Preferência por texto exato.
                        "for(var j=0;j<buttons.length;j++){" +
                        "var b=buttons[j];" +
                        "if(!visible(b))continue;" +
                        "var t=n(b.innerText||b.textContent);" +

                        "if(t==='adicionar'" +
                        "||t==='transferir'" +
                        "||t==='confirmar'" +
                        "||t==='salvar'"+
                        "||t==='adicionar créditos'" +
                        "||t==='adicionar creditos'){" +
                        "submit=b;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!submit){" +
                        "return 'no_submit';" +
                        "}" +

                        "try{" +
                        "submit.scrollIntoView({behavior:'auto',block:'center'});" +
                        "}catch(e){}" +

                        "try{" +
                        "submit.click();" +
                        "return 'clicked';" +
                        "}catch(e){" +
                        "try{" +
                        "submit.dispatchEvent(new MouseEvent(" +
                        "'click'," +
                        "{bubbles:true,cancelable:true,view:window}" +
                        "));" +
                        "return 'clicked';" +
                        "}catch(e2){" +
                        "return 'error';" +
                        "}" +
                        "}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if (!"clicked".equals(result)) {
                        uncertainAfterSubmit(
                                "Não consegui confirmar se o botão final de adicionar créditos foi acionado."
                        );

                        return;
                    }

                    updateStatus(
                            "Revenda: +50 enviado uma única vez; aguardando conclusão"
                    );

                    completionAttempts = 0;

                    handler.postDelayed(
                            this::waitForTransferCompletion,
                            700L
                    );
                }
        );
    }

    private void waitForTransferCompletion() {
        if (finished
                || webView == null) {
            return;
        }

        completionAttempts++;

        String script =
                "(function(){" +
                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var st=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0" +
                        "&&st.display!=='none'" +
                        "&&st.visibility!=='hidden';" +
                        "}" +

                        "function n(v){" +
                        "return (v||'').replace(/\\s+/g,' ').trim().toLowerCase();" +
                        "}" +

                        "var all=document.querySelectorAll('body *');" +

                        "for(var i=0;i<all.length;i++){" +
                        "if(!visible(all[i]))continue;" +
                        "var txt=n(all[i].innerText||all[i].textContent);" +

                        "if(txt.indexOf('concordo em transferir')!==-1" +
                        "||txt.indexOf('eu concordo')!==-1){" +
                        "return 'open';" +
                        "}" +
                        "}" +

                        "return 'closed';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("closed".equals(result)) {
                        successWithoutBalanceCheck();
                        return;
                    }

                    if (completionAttempts < 22) {
                        handler.postDelayed(
                                this::waitForTransferCompletion,
                                450L
                        );
                    } else {
                        uncertainAfterSubmit(
                                "O botão foi acionado uma única vez, mas a tela de transferência continuou aberta."
                        );
                    }
                }
        );
    }

    private void successWithoutBalanceCheck() {
        if (finished) return;

        finished =
                true;

        setState(
                "COMPLETE"
        );

        updateStatus(
                "Revenda: 50 créditos adicionados"
        );

        try {
            SecureStore secureStore =
                    new SecureStore(
                            context
                    );

            secureStore.put(
                    "linked_reseller_email_" + contactKey,
                    email
            );

        } catch (Exception ignored) {
        }

        prefs.edit()
                .putBoolean(
                        "reseller_submit_attempted_" + contactKey,
                        false
                )
                .apply();

        String supportGroupLink =
                prefs.getString(
                        "reseller_support_group_link",
                        ResellersActivity.DEFAULT_SUPPORT_GROUP_LINK
                ).trim();

        String successMessage =
                "✅ Painel de revenda ativado com sucesso!\n\n" +
                        "Foram adicionados *50 créditos*.";

        if (!supportGroupLink.isEmpty()) {
            successMessage +=
                    "\n\n📲 *Grupo de suporte:*\n" +
                            supportGroupLink;
        }

        WhatsAppReply.send(
                context,
                whatsappNotification,
                successMessage
        );

        cleanup();
    }

    private void uncertainAfterSubmit(
            String reason
    ) {
        if (finished) return;

        finished =
                true;

        setState(
                "REVIEW_REQUIRED"
        );

        updateStatus(
                "Revenda: revisão necessária após tentativa única de +50"
        );

        WhatsAppReply.send(
                context,
                whatsappNotification,
                "⚠️ Houve uma tentativa única de adicionar os 50 créditos, " +
                        "mas não consegui confirmar o clique final.\n\n" +
                        "Por segurança, *não vou tentar novamente automaticamente*. " +
                        "Confira essa revenda no MASTERFLIX."
        );

        cleanup();
    }

    private void failBeforeSubmit(
            String reason
    ) {
        if (finished) return;

        finished =
                true;

        setState(
                "ERROR"
        );

        updateStatus(
                "Revenda: " + reason
        );

        WhatsAppReply.send(
                context,
                whatsappNotification,
                "Não consegui concluir o cadastro da revenda automaticamente.\n\n" +
                        reason
        );

        cleanup();
    }

    private void setState(
            String state
    ) {
        prefs.edit()
                .putString(
                        "reseller_state_" + contactKey,
                        state
                )
                .apply();
    }

    private void updateStatus(
            String value
    ) {
        prefs.edit()
                .putString(
                        "last_reseller_status",
                        value
                )
                .apply();
    }

    private boolean nearlyEqual(
            double a,
            double b
    ) {
        return Math.abs(a - b) < 0.001d;
    }

    private String formatCredits(
            double value
    ) {
        if (Math.abs(
                value - Math.rint(value)
        ) < 0.001d) {
            return String.valueOf(
                    (long) Math.rint(value)
            );
        }

        return String.format(
                Locale.US,
                "%.2f",
                value
        );
    }

    private String decodeJavascriptString(
            String value
    ) {
        if (value == null
                || "null".equals(value)) {
            return "";
        }

        try {
            Object decoded =
                    new org.json.JSONTokener(
                            value
                    ).nextValue();

            return decoded == null
                    ? ""
                    : decoded.toString();

        } catch (Exception e) {
            return "";
        }
    }

    private void cleanup() {
        handler.post(
                () -> {
                    try {
                        if (webView != null) {
                            webView.stopLoading();
                            webView.loadUrl(
                                    "about:blank"
                            );
                            webView.destroy();
                            webView =
                                    null;
                        }

                    } catch (Throwable ignored) {
                    }

                    synchronized (LOCK) {
                        if (current == this) {
                            current =
                                    null;
                        }
                    }
                }
        );
    }
}
