MASTER RESPONDE v1.1.1

Correção da v1.1:
- Adicionado package visibility para o WhatsApp Business:
  com.whatsapp.w4b
- Corrige o status "Não instalado" em Android 11+.

Teste:
1. Instale a v1.1.1 por cima da v1.1.
2. Abra o app.
3. O card WhatsApp Business deve mostrar:
   - "Acesso liberado" se o acesso às notificações já estiver ativo.
4. Ligue o Bot.
5. Feche e reabra o app para confirmar que ele continua ligado.

Ainda NÃO existe autoresposta nesta versão.
A autoresposta entra somente depois desta etapa ficar 100% validada.
