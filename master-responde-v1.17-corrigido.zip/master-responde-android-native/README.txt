MASTER RESPONDE v1.17 — SIGMA GENÉRICO

BASE
v1.16, preservando os fluxos e automações aprovados.

OBJETIVO
Remover a dependência de um domínio MASTERFLIX fixo e permitir que o mesmo
MASTER RESPONDE trabalhe com qualquer painel Sigma de mesma estrutura.

O QUE NÃO MUDOU
- Bot e motor em segundo plano
- respostas privadas
- regras
- Mensagens e Tempos
- @infor nos grupos
- Mídias / Links
- deduplicação
- nova revenda
- confirmação de revenda por e-mail
- grupo de suporte
- geração automática de teste
- mini painel incorporado
- login salvo e preenchimento automático
- menu lateral
- configurações do aplicativo
- funcionamento aberto e em segundo plano

NOVO: PERFIL DO PAINEL SIGMA
O menu lateral possui a opção PAINEL SIGMA.

Campos:
- Nome do painel
- URL base do painel
- Usuário/e-mail
- Senha
- Texto preferido do teste (opcional)
- Link de cadastro da revenda
- Link do grupo de suporte

ROTAS
As rotas permanecem fixas no motor porque os painéis Sigma usam a mesma
estrutura:

Login:
{URL_BASE}/#/sign-in

Dashboard:
{URL_BASE}/#/dashboard

Revendas:
{URL_BASE}/#/resellers

Exemplo:
URL base = https://painelcliente.sigmab.pro

O MASTER RESPONDE usa automaticamente:
https://painelcliente.sigmab.pro/#/sign-in
https://painelcliente.sigmab.pro/#/dashboard
https://painelcliente.sigmab.pro/#/resellers

MIGRAÇÃO MASTERFLIX
A instalação existente continua funcionando sem configuração adicional.

Perfil padrão:
Nome: MASTERFLIX
URL: https://masterflix.sigmab.pro

Usuário e senha salvos nas versões anteriores são migrados automaticamente
para o armazenamento do perfil Sigma.

Ao salvar outro painel:
- a sessão antiga é marcada como inativa;
- o próximo acesso usa o novo domínio;
- os cookies continuam sendo gerenciados normalmente pelo WebView;
- usuário e senha do perfil ativo são usados no preenchimento automático.

TESTE AUTOMÁTICO GENÉRICO
O motor não procura mais especificamente:
MASTERFLIX TESTE COMPLETO 1H

Agora:
- lê as opções visíveis do Teste Rápido;
- procura elementos que contenham TESTE;
- ignora o título "Teste Rápido" e o campo de pesquisa;
- se o campo "Texto preferido do teste" estiver preenchido, essa opção tem
  prioridade;
- se estiver vazio, prioriza opções contendo "COMPLETO";
- depois prioriza 1H quando existir;
- se não houver essas palavras, usa outra opção de teste disponível.

Isso permite trabalhar com painéis que tenham produtos como:
- P2-ON
- P2-PRO
- P2-PLUS
- MEGA IPTV
- MASTERFLIX
- RYZEEN
- XPLAY
- outros produtos cadastrados no Sigma

REVENDA
A verificação continua igual:
1. Cliente solicita ser revenda.
2. Bot envia o link de cadastro configurado.
3. Cliente envia o e-mail cadastrado.
4. Bot abre a rota Revendas do painel Sigma ativo.
5. Bot pesquisa o e-mail.
6. Se encontrar, confirma a revenda.
7. Bot envia a mensagem configurada e o grupo de suporte.

Não foi reintroduzida adição automática de créditos.

MINI PAINEL
O antigo MasterflixActivity continua internamente para compatibilidade do
projeto, mas a interface e as URLs são alimentadas pelo Perfil Sigma.

Na tela o nome exibido é o nome do painel configurado.

SEGURANÇA
- credenciais continuam criptografadas no aparelho;
- CAPTCHA e verificações humanas não são contornados;
- ao trocar de painel a sessão é invalidada no status interno;
- login automático só usa credenciais salvas pelo usuário.

VERSÃO
1.17
versionCode 44
