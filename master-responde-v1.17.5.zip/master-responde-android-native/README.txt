MASTER RESPONDE v1.17.5

CORREÇÃO DA CAPTURA DO TESTE

Base utilizada: v1.17.3, não v1.17.4.

Motivo:
A v1.17.4 ampliou demais o fallback de DOM e podia capturar praticamente
todo o Dashboard Sigma. Isso foi removido.

FLUXO DA v1.17.5
1. Gera o teste usando o motor estável da v1.16 adaptado ao Sigma genérico.
2. Procura COPIAR ou COPIAR E FECHAR.
3. Intercepta navigator.clipboard.writeText.
4. Intercepta document.execCommand('copy').
5. Escuta o evento copy.
6. Se o painel entregar o texto copiado, envia exatamente esse conteúdo.
7. O fallback de DOM só é aceito dentro de:
   - role=dialog
   - modal
   - modal-content
   - dialog
   - drawer
   - card/modal semelhante
   e somente se esse bloco contém DETALHES DO CLIENTE.
8. Nunca usa body, Dashboard ou ancestrais grandes como conteúdo de teste.
9. Remove apenas textos de interface:
   COPIAR, COPIAR E FECHAR, FECHAR, CANCELAR e DETALHES DO CLIENTE.

PRESERVADO
- Sigma genérico
- sessão e login automático
- revenda
- @infor
- regras
- mídias/links
- mensagens e tempos
- segundo plano
- assinatura release permanente

VERSÃO
1.17.5
versionCode 49
