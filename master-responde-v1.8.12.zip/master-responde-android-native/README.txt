MASTER RESPONDE v1.8.12

Base: v1.8.11.

BUG CORRIGIDO:
O valor 50 estava sendo colocado no campo de pesquisa da página Revendas.

CAUSA:
A página principal possui filtros e campos com a palavra "Créditos".
A automação antiga podia subir demais no DOM e escolher o input de pesquisa.

CORREÇÃO:
- primeiro localiza a tela exclusiva "Adicionar Créditos" usando o aviso
  "Essa função é para ADICIONAR créditos, não REMOVER...";
- dentro dessa tela procura somente o controle:
  − [campo] +
- só aceita o input que estiver dentro desse mesmo controle;
- não existe mais fallback para outro campo da página;
- preenche 50;
- espera a frase atualizar para
  "Eu concordo em transferir 50 créditos";
- marca somente a checkbox dessa frase;
- depois procura o botão final "Adicionar";
- o clique final continua protegido contra duplicidade.

PRESERVADO:
- MASTERFLIX em tela cheia;
- busca da revenda pelo e-mail exato;
- sem pedir CONFIRMAR;
- sem leitura de saldo;
- link do grupo de suporte editável;
- mensagens intermediárias silenciosas;
- geração de teste em segundo plano.
