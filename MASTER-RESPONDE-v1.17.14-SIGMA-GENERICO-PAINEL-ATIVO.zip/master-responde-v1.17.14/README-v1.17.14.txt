MASTER RESPONDE v1.17.14

Correção Sigma genérico:
- mantém o motor de TESTE estável da v1.17.12;
- fixa cada execução ao painel Sigma ativo no início do pedido;
- bloqueia redirecionamento/sessão para outro domínio;
- não reutiliza credenciais antigas do MASTERFLIX em painel genérico;
- ao salvar/trocar painel, limpa TESTE pendente do painel anterior;
- mensagem de falha não referencia MASTERFLIX.

versionName 1.17.14
versionCode 58
