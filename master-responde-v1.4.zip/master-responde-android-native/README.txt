MASTER RESPONDE v1.4

BASE ESTÁVEL:
- v1.0 dashboard
- v1.1.1 Bot + notificações
- v1.2.1 primeira autoresposta
- v1.3.1 regras configuráveis sem duplicidade

ÚNICA FUNÇÃO NOVA DA v1.4:
CATEGORIAS COM VÁRIAS RESPOSTAS DE TEXTO EM SEQUÊNCIA

COMO USAR:
1. Abra MÍDIAS.
2. Toque + ADICIONAR CATEGORIA.
3. Exemplo de nome:
   Planos
4. Dentro da categoria, adicione várias respostas:
   Texto 1
   Texto 2
   Texto 3
5. Volte e abra REGRAS.
6. Toque + REGRA COM CATEGORIA.
7. Exemplo:
   Gatilho: planos
   Categoria: Planos
8. Envie "planos" para o WhatsApp Business.

RESULTADO ESPERADO:
O bot envia Texto 1, depois Texto 2, depois Texto 3,
com aproximadamente 1,2 segundo entre cada resposta.

REGRAS ANTIGAS:
Continuam funcionando normalmente com uma resposta única.

AINDA NÃO EXISTE:
- foto
- vídeo
- áudio
- @infor em grupos
- MASTERFLIX
- revendas
- créditos
