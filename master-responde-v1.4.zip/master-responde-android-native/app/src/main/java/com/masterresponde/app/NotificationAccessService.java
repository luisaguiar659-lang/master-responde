package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NotificationAccessService extends NotificationListenerService {

    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    private static final Map<String, Long> RECENT =
            new ConcurrentHashMap<>();

    private static final Object SEND_LOCK = new Object();

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (!WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        SharedPreferences prefs =
                getSharedPreferences("master_responde", MODE_PRIVATE);

        if (!prefs.getBoolean("bot_enabled", false)) return;

        Notification notification = sbn.getNotification();

        if (notification == null || notification.extras == null) return;

        CharSequence value =
                notification.extras.getCharSequence(Notification.EXTRA_TEXT);

        if (value == null) return;

        String incoming = normalize(value.toString());

        if (incoming.isEmpty()) return;

        String notificationKey = sbn.getKey() == null
                ? "no-key"
                : sbn.getKey();

        if ("teste bot".equals(incoming)) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "fixed_test",
                    incoming,
                    "✅ MASTER RESPONDE ativo e funcionando."
            );
            return;
        }

        try {
            JSONArray rules = new JSONArray(
                    prefs.getString("text_rules", "[]")
            );

            for (int i = 0; i < rules.length(); i++) {
                JSONObject rule = rules.optJSONObject(i);

                if (rule == null) continue;

                String trigger = normalize(
                        rule.optString("trigger", "")
                );

                boolean exact =
                        rule.optBoolean("exact", false);

                if (trigger.isEmpty()) continue;

                boolean match = exact
                        ? incoming.equals(trigger)
                        : incoming.contains(trigger);

                if (!match) continue;

                String ruleId = rule.optString(
                        "id",
                        String.valueOf(i)
                );

                String categoryId =
                        rule.optString("category_id", "");

                if (!categoryId.isEmpty()) {
                    JSONArray responses =
                            categoryResponses(
                                    prefs,
                                    categoryId
                            );

                    if (responses.length() > 0) {
                        sendSequenceWithProtection(
                                notification,
                                notificationKey,
                                "category_rule|" + ruleId,
                                incoming,
                                responses
                        );
                    }

                    return;
                }

                String response =
                        rule.optString("reply", "").trim();

                if (!response.isEmpty()) {
                    sendSingleWithProtection(
                            notification,
                            notificationKey,
                            "rule|" + ruleId,
                            incoming,
                            response
                    );
                }

                return;
            }

        } catch (Exception ignored) {
        }
    }

    private JSONArray categoryResponses(
            SharedPreferences prefs,
            String categoryId
    ) {
        JSONArray result = new JSONArray();

        try {
            JSONArray categories = new JSONArray(
                    prefs.getString(
                            "text_categories",
                            "[]"
                    )
            );

            for (int i = 0; i < categories.length(); i++) {
                JSONObject category =
                        categories.optJSONObject(i);

                if (category == null) continue;

                if (!categoryId.equals(
                        category.optString("id"))) {
                    continue;
                }

                JSONArray responses =
                        category.optJSONArray("responses");

                if (responses == null) return result;

                for (int r = 0; r < responses.length(); r++) {
                    JSONObject response =
                            responses.optJSONObject(r);

                    if (response == null) continue;

                    String text =
                            response.optString("text", "").trim();

                    if (!text.isEmpty()) {
                        result.put(text);
                    }
                }

                return result;
            }

        } catch (Exception ignored) {
        }

        return result;
    }

    private void sendSingleWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            String message
    ) {
        String fingerprint =
                notificationKey
                        + "|"
                        + ruleKey
                        + "|"
                        + incoming;

        if (!reserveFingerprint(fingerprint)) {
            return;
        }

        boolean sent = reply(
                notification,
                message
        );

        updateStatus(
                sent
                        ? "Última autoresposta: enviada"
                        : "Última autoresposta: não disponível"
        );
    }

    private void sendSequenceWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            JSONArray messages
    ) {
        String fingerprint =
                notificationKey
                        + "|"
                        + ruleKey
                        + "|"
                        + incoming;

        if (!reserveFingerprint(fingerprint)) {
            return;
        }

        updateStatus(
                "Última sequência: iniciada com "
                        + messages.length()
                        + " respostas"
        );

        for (int i = 0; i < messages.length(); i++) {
            final String message =
                    messages.optString(i, "").trim();

            if (message.isEmpty()) continue;

            final boolean last =
                    i == messages.length() - 1;

            long delay =
                    i * 1200L;

            handler.postDelayed(() -> {
                boolean sent =
                        reply(notification, message);

                if (!sent) {
                    updateStatus(
                            "Última sequência: envio interrompido"
                    );
                } else if (last) {
                    updateStatus(
                            "Última sequência: concluída"
                    );
                }
            }, delay);
        }
    }

    private boolean reserveFingerprint(
            String fingerprint
    ) {
        synchronized (SEND_LOCK) {

            long now =
                    System.currentTimeMillis();

            Long memoryTime =
                    RECENT.get(fingerprint);

            if (memoryTime != null
                    && now - memoryTime < 10000L) {
                return false;
            }

            SharedPreferences prefs =
                    getSharedPreferences(
                            "master_responde",
                            MODE_PRIVATE
                    );

            String last =
                    prefs.getString(
                            "last_rule_fingerprint",
                            ""
                    );

            long lastTime =
                    prefs.getLong(
                            "last_rule_fingerprint_time",
                            0L
                    );

            if (fingerprint.equals(last)
                    && now - lastTime < 10000L) {
                RECENT.put(
                        fingerprint,
                        now
                );
                return false;
            }

            RECENT.put(
                    fingerprint,
                    now
            );

            prefs.edit()
                    .putString(
                            "last_rule_fingerprint",
                            fingerprint
                    )
                    .putLong(
                            "last_rule_fingerprint_time",
                            now
                    )
                    .commit();

            if (RECENT.size() > 200) {
                RECENT.clear();
                RECENT.put(
                        fingerprint,
                        now
                );
            }

            return true;
        }
    }

    private void updateStatus(String value) {
        getSharedPreferences(
                "master_responde",
                MODE_PRIVATE
        )
                .edit()
                .putString(
                        "last_test_status",
                        value
                )
                .apply();
    }

    private boolean reply(
            Notification notification,
            String message
    ) {
        Notification.Action[] actions =
                notification.actions;

        if (actions == null) return false;

        for (Notification.Action action : actions) {
            if (action == null
                    || action.actionIntent == null) {
                continue;
            }

            RemoteInput[] inputs =
                    action.getRemoteInputs();

            if (inputs == null
                    || inputs.length == 0) {
                continue;
            }

            for (RemoteInput input : inputs) {
                if (input == null) continue;

                if (!input.getAllowFreeFormInput()) {
                    continue;
                }

                try {
                    Intent intent =
                            new Intent();

                    Bundle results =
                            new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            this,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) return "";

        return Normalizer
                .normalize(
                        value,
                        Normalizer.Form.NFD
                )
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
