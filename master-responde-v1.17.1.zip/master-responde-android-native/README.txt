MASTER RESPONDE v1.17.1

CORREÇÃO DO TESTE NO SIGMA GENÉRICO

A v1.17 introduziu o perfil Sigma genérico. Na v1.17.1 foi corrigida a
diferença entre a geração pelo mini painel e a geração em segundo plano.

CAUSA
O mini painel usava um WebView visível, enquanto o motor em segundo plano
usava um WebView oculto. O seletor de teste exigia largura/altura visível,
então podia não localizar nenhum teste no WebView oculto.

CORREÇÃO
Foi criado SigmaTestSelector:
- o botão GERAR TESTE do mini painel usa esse seletor;
- o bot em segundo plano usa o MESMO seletor;
- a seleção não depende mais de getBoundingClientRect/visibilidade;
- o painel pode estar aberto ou oculto;
- a rotina continua lendo os testes disponíveis dinamicamente;
- se houver teste preferido configurado, ele continua tendo prioridade;
- se não houver, o motor prioriza COMPLETO, depois 1H, e depois outras
  opções de teste disponíveis.

O botão do mini painel agora aparece como:
GERAR TESTE

Não existe mais promessa fixa de "COMPLETO 1H", pois cada painel Sigma
pode ter produtos e durações diferentes.

PRESERVADO
- todos os fluxos da v1.17;
- painel Sigma genérico;
- login automático;
- mini painel;
- teste em segundo plano;
- revenda;
- @infor;
- regras;
- mensagens e tempos;
- menu lateral;
- configurações;
- trava contra teste duplicado.

VERSÃO
1.17.1
versionCode 45
