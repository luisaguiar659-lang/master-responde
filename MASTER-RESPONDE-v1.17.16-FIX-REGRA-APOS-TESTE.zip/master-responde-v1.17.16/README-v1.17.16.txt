MASTER RESPONDE v1.17.16

Correção de compilação da v1.17.14 + manutenção do isolamento multi-contatos.

Correções:
- corrigida incompatibilidade de assinatura em handlePrivate(...);
- removido argumento senderKey indevido nas duas chamadas privadas;
- mantida deduplicação privada isolada por contato;
- mantido anti-eco por conversa;
- mantida concorrência entre leads diferentes;
- versionCode 60 / versionName 1.17.16.

Base: v1.17.14.
