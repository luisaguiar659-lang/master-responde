MASTER RESPONDE v1.5.5

Base: v1.5.4.

CORREÇÃO ÚNICA:
- bloqueio atômico contra respostas duplicadas em grupos.

Problema identificado:
duas callbacks do WhatsApp Business podem chegar praticamente
ao mesmo tempo. Na versão anterior, as duas podiam consultar
o bloqueio antes de a primeira terminar de registrá-lo.

Correção:
- checagem + registro agora acontecem na MESMA trava;
- a mensagem fica reservada ANTES de enviar qualquer resposta;
- o bloqueio também fica salvo em SharedPreferences;
- usa uma identificação estável da conversa quando disponível;
- a mesma mensagem do mesmo grupo fica bloqueada por 5 segundos.

TESTE:
1. Envie @infor
2. Envie 1
3. Deve existir apenas UMA resposta
4. Envie 2
5. Deve existir apenas UMA resposta
6. Repita com 3, 4, 5 e 6

As demais funções da v1.5.4 foram mantidas.
