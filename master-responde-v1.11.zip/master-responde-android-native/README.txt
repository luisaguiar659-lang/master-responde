MASTER RESPONDE v1.11

BASE ESTÁVEL:
v1.10

FUNÇÃO NOVA:
TESTE DE ENVIO DE 1 FOTO PELO WHATSAPP BUSINESS

OBJETIVO DESTA VERSÃO:
Validar se o WhatsApp Business do aparelho aceita uma imagem através
da ação de resposta da própria notificação.

COMO FUNCIONA:
1. Cadastre uma categoria em MÍDIAS.
2. Adicione uma foto.
3. Crie uma REGRA apontando para essa categoria.
4. Quando o cliente enviar o gatilho da regra:
   - os textos continuam sendo enviados normalmente;
   - o MASTER RESPONDE tenta enviar SOMENTE A PRIMEIRA FOTO da categoria;
   - fotos adicionais são ignoradas nesta versão.

CATEGORIA SOMENTE COM FOTO:
A partir da v1.11, uma categoria que tenha somente foto também pode
ser selecionada em uma regra.

GRUPOS:
As categorias usadas pelo @infor também passam pelo mesmo teste:
textos continuam funcionando e somente a primeira foto é tentada.

MÉTODO DE ENVIO:
- usa a ação de resposta da notificação do WhatsApp Business;
- usa RemoteInput com resultado de dados/MIME quando o WhatsApp informar suporte;
- se o WhatsApp não anunciar suporte explícito, faz uma tentativa experimental
  usando a mesma ação de resposta;
- concede leitura temporária da URI da foto ao WhatsApp Business.

IMPORTANTE:
O Android permite respostas de TEXTO por notificação de forma confiável.
Envio de mídia depende de o WhatsApp Business aceitar dados MIME nessa ação.

Por isso esta versão é um TESTE CONTROLADO.
Não há automação por acessibilidade nem clique automático na interface do WhatsApp.

STATUS DO TESTE:
Abra MÍDIAS depois de testar.
A tela mostra um dos estados:
- Foto: WhatsApp informou suporte de mídia e a tentativa foi enviada
- Foto: tentativa experimental enviada ao WhatsApp Business
- Foto: WhatsApp Business não disponibilizou envio pela notificação

Mesmo que a tentativa seja aceita pela PendingIntent, a confirmação final
é visual: verifique se a foto realmente apareceu na conversa.

SEGURANÇA DA BASE:
Se a foto não for aceita, os textos continuam funcionando normalmente.

PRESERVADO DA v1.10:
- cadastro de várias fotos;
- pré-visualização das fotos;
- textos;
- regras;
- Mensagens e Tempos;
- nova revenda;
- verificação de e-mail da revenda;
- grupo de suporte;
- geração automática de testes;
- @infor;
- MASTERFLIX login/sessão.
