MASTER RESPONDE v1.15

BASE:
v1.14 — motor unificado funcionando com o aplicativo aberto e em segundo plano.

CORREÇÕES E AJUSTES DA v1.15

1. TESTE DUPLICADO
Foi adicionada uma trava específica por conversa para solicitação de teste.
Depois que uma conversa solicita teste, o mesmo gatilho não pode iniciar outra
geração durante 90 segundos.

Também foi corrigida a ordem de encerramento da tarefa:
- a pendência de teste é limpa ANTES de enviar o teste final;
- a própria atualização da notificação causada pela resposta não pode reabrir
  uma tarefa antiga;
- a mensagem "Gerando seu teste, aguarde..." não deve iniciar uma segunda geração.

2. MASTERFLIX — LOGIN SALVO
O painel MASTERFLIX continua com:
- usuário/e-mail;
- senha;
- SALVAR CREDENCIAIS;
- PREENCHER LOGIN SALVO;
- ENCERRAR SESSÃO.

As credenciais continuam criptografadas no aparelho.

NOVIDADE:
Quando uma solicitação de TESTE ou verificação de REVENDA encontrar a sessão
MASTERFLIX expirada, o WebView oculto tenta:
- ler usuário e senha salvos;
- preencher os campos do login;
- entrar automaticamente se a página não exigir verificação humana.

Se houver CAPTCHA, "Verificado" ou outra proteção manual:
- os campos podem ser preenchidos;
- o bot NÃO contorna a verificação;
- a conclusão continua manual.

Ao abrir o painel MASTERFLIX manualmente e cair na tela de login, o app também
tenta preencher as credenciais salvas automaticamente.

3. CRÉDITOS
O fluxo atual de nova revenda NÃO usa mais adição automática de créditos.
A verificação de revenda continua apenas:
- receber e-mail;
- localizar o cadastro no MASTERFLIX;
- confirmar que existe;
- enviar mensagem configurável e link do grupo de suporte.

4. NOVO DASHBOARD
O dashboard foi simplificado.

Na tela principal ficam:
- MASTER RESPONDE + versão;
- liga/desliga do Bot;
- Status do Bot;
- Status do WhatsApp Business;
- Status da sessão MASTERFLIX;
- Status do Motor em segundo plano;
- botão de acesso às notificações;
- status das credenciais MASTERFLIX;
- último status de teste.

ATALHOS e MÓDULOS foram retirados da tela principal.

5. MENU LATERAL
Foi adicionado o botão ☰ no canto superior direito.

Ao tocar:
- abre um menu lateral pelo lado esquerdo;
- tocar fora fecha o menu;
- botão voltar também fecha o menu.

ATALHOS:
- Gerar Teste
- Nova Revenda
- Mídias / Links
- @infor Grupos

MÓDULOS:
- Regras
- Mídias
- Revendas
- Grupos
- Mensagens e Tempos
- Histórico
- Configurações / MASTERFLIX

6. PRESERVADO
- respostas privadas;
- regras simples;
- Mensagens e Tempos;
- deduplicação;
- @infor somente em grupos;
- categorias de Mídias exclusivas do @infor;
- links nas categorias;
- fotos locais;
- nova revenda;
- grupo de suporte;
- teste MASTERFLIX;
- motor em segundo plano;
- recuperação do listener;
- sessão/cookies MASTERFLIX;
- sem Acessibilidade para fotos.

VERSÃO:
1.15
versionCode 42
