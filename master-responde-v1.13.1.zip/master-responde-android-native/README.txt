MASTER RESPONDE v1.13.1

BASE:
v1.13

CORREÇÃO DE ARQUITETURA:
As categorias de MÍDIAS são EXCLUSIVAS do menu @infor nos GRUPOS.

MÍDIAS:
- Tutoriais
- Promoções e Planos
- Aplicativos Parceiros
- Banners
- Avisos
- Apresentação do Servidor
- e outras categorias futuras

podem conter:
- textos;
- links;
- fotos salvas localmente.

USO:
Essas categorias só são lidas quando o usuário interage com o menu @infor
em um grupo.

Exemplos:
@infor 1 -> categoria Tutoriais
@infor 2 -> categoria Promoções e Planos
@infor 4 -> categoria Banners

Os links cadastrados são enviados como mensagens normais do WhatsApp.

REGRAS PRIVADAS:
- continuam existindo apenas para respostas simples;
- o botão "REGRA COM CATEGORIA" foi removido;
- regras antigas que já apontavam para uma categoria ficam DESATIVADAS;
- essas regras antigas não enviam categoria em conversa privada;
- continuam visíveis para poderem ser excluídas manualmente.

ACESSIBILIDADE:
Não existe serviço de Acessibilidade nesta versão.

PRESERVADO:
- links nas categorias;
- edição e exclusão de links;
- textos;
- fotos salvas localmente;
- Mensagens e Tempos;
- nova revenda;
- verificação de e-mail;
- grupo de suporte;
- geração automática de testes;
- @infor;
- MASTERFLIX login/sessão.
