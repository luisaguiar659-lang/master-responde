MASTER RESPONDE v1.5.3

Base: v1.5.2.

CORREÇÃO ÚNICA:
- elimina respostas duplicadas no menu de grupos.

O WhatsApp Business pode gerar duas callbacks da mesma mensagem
com IDs de notificação diferentes. A proteção anterior não identificava
essas duas callbacks como a mesma mensagem.

Agora o MASTER RESPONDE usa, para grupos:
- grupo
- comando recebido
- janela de 3 segundos

Assim, a mesma opção do mesmo grupo só é processada uma vez.

TESTE:
1. Envie @infor
2. Envie 3
3. Deve aparecer somente UMA resposta
4. Depois teste 4, 5 e 6
5. Cada opção deve gerar somente UMA resposta

A correção da primeira opção da v1.5.2 foi mantida.
