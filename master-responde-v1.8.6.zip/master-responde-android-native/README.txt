MASTER RESPONDE v1.8.6

Base: v1.8.5.

CORREÇÃO ÚNICA IDENTIFICADA NO VÍDEO:
O MASTERFLIX exige marcar a autorização
"Eu concordo em transferir 50 créditos"
antes de permitir o botão Adicionar.

NOVO FLUXO:
1. Localiza a revenda pelo e-mail exato.
2. Abre Adicionar Créditos.
3. Preenche 50.
4. Localiza a caixa "Eu concordo em transferir 50 créditos".
5. Marca a caixa automaticamente.
6. Aguarda o botão Adicionar ficar disponível.
7. Marca a operação como tentada ANTES do clique final.
8. Clica em Adicionar UMA ÚNICA VEZ.
9. Não lê saldo.
10. Aguarda a janela de transferência fechar.
11. Somente depois envia:
    - painel ativado com sucesso;
    - 50 créditos adicionados;
    - link editável do grupo de suporte.

PROTEÇÃO:
- se a caixa de autorização não puder ser marcada, nenhum crédito é enviado;
- se o clique final for feito mas a janela não fechar, não existe segunda tentativa automática;
- nesse caso pede conferência manual.

PRESERVADO:
- sem pedir CONFIRMAR ao cliente;
- sem leitura de saldo;
- correção de loop;
- link de cadastro editável;
- link do grupo de suporte editável;
- geração de testes em segundo plano.
