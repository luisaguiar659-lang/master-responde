package com.masterresponde.app;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;

public class MasterflixResellerAutomation {

    private static final String RESELLERS_URL =
            "https://masterflix.sigmab.pro/#/resellers";

    private static final int CREDIT_AMOUNT = 50;

    private static final String MODE_FIND =
            "find";

    private static final String MODE_ADD =
            "add";

    private static final Object LOCK =
            new Object();

    private static MasterflixResellerAutomation current;

    private final Context context;
    private final Notification whatsappNotification;
    private final SharedPreferences prefs;
    private final String contactKey;
    private final String email;
    private final String mode;

    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private WebView webView;

    private boolean finished = false;
    private boolean pageReady = false;
    private boolean submitAttempted = false;

    private int searchAttempts = 0;
    private int dialogAttempts = 0;
    private int verifyAttempts = 0;
    private int completionAttempts = 0;

    private double beforeCredits = Double.NaN;

    private MasterflixResellerAutomation(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email,
            String mode
    ) {
        this.context =
                context.getApplicationContext();

        this.whatsappNotification =
                notification;

        this.prefs =
                prefs;

        this.contactKey =
                contactKey;

        this.email =
                email == null
                        ? ""
                        : email.trim().toLowerCase(Locale.ROOT);

        this.mode =
                mode;
    }

    public static boolean findReseller(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email
    ) {
        return start(
                context,
                notification,
                prefs,
                contactKey,
                email,
                MODE_FIND
        );
    }

    public static boolean addCredits(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email
    ) {
        return start(
                context,
                notification,
                prefs,
                contactKey,
                email,
                MODE_ADD
        );
    }

    private static boolean start(
            Context context,
            Notification notification,
            SharedPreferences prefs,
            String contactKey,
            String email,
            String mode
    ) {
        synchronized (LOCK) {
            if (current != null
                    && !current.finished) {
                return false;
            }

            current =
                    new MasterflixResellerAutomation(
                            context,
                            notification,
                            prefs,
                            contactKey,
                            email,
                            mode
                    );

            current.handler.post(
                    current::createAndStart
            );

            return true;
        }
    }

    private void createAndStart() {
        try {
            updateStatus(
                    MODE_FIND.equals(mode)
                            ? "Revenda: procurando cadastro no MASTERFLIX"
                            : "Revenda: preparando crédito inicial +50"
            );

            webView =
                    new WebView(context);

            WebSettings settings =
                    webView.getSettings();

            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadsImagesAutomatically(true);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);

            CookieManager cookieManager =
                    CookieManager.getInstance();

            cookieManager.setAcceptCookie(true);

            if (android.os.Build.VERSION.SDK_INT >= 21) {
                cookieManager.setAcceptThirdPartyCookies(
                        webView,
                        true
                );
            }

            webView.setWebViewClient(
                    new WebViewClient() {

                        @Override
                        public void onPageFinished(
                                WebView view,
                                String url
                        ) {
                            super.onPageFinished(
                                    view,
                                    url
                            );

                            inspectLocation();
                        }

                        @Override
                        public void doUpdateVisitedHistory(
                                WebView view,
                                String url,
                                boolean isReload
                        ) {
                            super.doUpdateVisitedHistory(
                                    view,
                                    url,
                                    isReload
                            );

                            inspectLocation();
                        }
                    }
            );

            webView.loadUrl(
                    RESELLERS_URL
            );

            handler.postDelayed(
                    () -> {
                        if (!finished
                                && !pageReady) {
                            confirmLoadState();
                        }
                    },
                    12000L
            );

        } catch (Throwable e) {
            failBeforeSubmit(
                    "Não foi possível iniciar o MASTERFLIX em segundo plano."
            );
        }
    }

    private void inspectLocation() {
        if (finished
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (finished) return;

                    if (url.contains("#/resellers")) {
                        if (!pageReady) {
                            pageReady =
                                    true;

                            prefs.edit()
                                    .putBoolean(
                                            "masterflix_session_active",
                                            true
                                    )
                                    .apply();

                            handler.postDelayed(
                                    this::searchExactEmail,
                                    1000L
                            );
                        }

                    } else if (url.contains("#/sign-in")) {
                        prefs.edit()
                                .putBoolean(
                                        "masterflix_session_active",
                                        false
                                )
                                .apply();

                        handler.postDelayed(
                                this::confirmStillOnLogin,
                                1600L
                        );
                    }
                }
        );
    }

    private void confirmLoadState() {
        if (finished
                || pageReady
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (url.contains("#/sign-in")) {
                        failBeforeSubmit(
                                "Sessão MASTERFLIX expirada. Abra o app e renove o login."
                        );
                    } else if (!pageReady) {
                        failBeforeSubmit(
                                "A página de revendas não carregou."
                        );
                    }
                }
        );
    }

    private void confirmStillOnLogin() {
        if (finished
                || pageReady
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (url.contains("#/sign-in")) {
                        failBeforeSubmit(
                                "Sessão MASTERFLIX expirada. Abra o app e renove o login."
                        );
                    }
                }
        );
    }

    private void searchExactEmail() {
        if (finished
                || webView == null) {
            return;
        }

        searchAttempts++;

        String emailJson =
                JSONObject.quote(
                        email
                );

        String script =
                "(function(){" +
                        "var wanted=" + emailJson + ";" +

                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var st=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0" +
                        "&&st.display!=='none'" +
                        "&&st.visibility!=='hidden';" +
                        "}" +

                        "function setValue(el,v){" +
                        "if(!el)return false;" +
                        "try{" +
                        "var proto=el.tagName==='TEXTAREA'" +
                        "?HTMLTextAreaElement.prototype" +
                        ":HTMLInputElement.prototype;" +
                        "var setter=Object.getOwnPropertyDescriptor(proto,'value').set;" +
                        "setter.call(el,v);" +
                        "}catch(e){el.value=v;}" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "el.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true,key:'a'}));" +
                        "return true;" +
                        "}" +

                        "var inputs=document.querySelectorAll('input,textarea');" +
                        "var search=null;" +

                        "for(var i=0;i<inputs.length;i++){" +
                        "var el=inputs[i];" +
                        "if(!visible(el))continue;" +
                        "var hint=((el.placeholder||'')+' '+(el.getAttribute('aria-label')||'')).toLowerCase();" +
                        "var type=(el.type||'').toLowerCase();" +
                        "if(type==='search'" +
                        "||hint.indexOf('buscar')!==-1" +
                        "||hint.indexOf('pesquisar')!==-1" +
                        "||hint.indexOf('search')!==-1" +
                        "||hint.indexOf('email')!==-1){" +
                        "search=el;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(search){" +
                        "setValue(search,wanted);" +
                        "try{search.focus();}catch(e){}" +
                        "}" +

                        "return search?'search_set':'no_search';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> handler.postDelayed(
                        this::inspectExactEmail,
                        700L
                )
        );
    }

    private void inspectExactEmail() {
        if (finished
                || webView == null) {
            return;
        }

        String emailJson =
                JSONObject.quote(
                        email
                );

        String script =
                "(function(){" +
                        "var wanted=" + emailJson + ".toLowerCase();" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best=null;" +
                        "var bestLen=999999;" +

                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=(el.innerText||el.textContent||'').trim();" +
                        "if(!text)continue;" +
                        "var low=text.toLowerCase();" +

                        "if(low===wanted" +
                        "||low.indexOf(wanted)!==-1){" +
                        "if(text.length<bestLen){" +
                        "best=el;" +
                        "bestLen=text.length;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!best){" +
                        "return JSON.stringify({found:false});" +
                        "}" +

                        "var row=best.closest('tr,[role=row]');" +

                        "if(!row){" +
                        "var p=best;" +
                        "for(var d=0;d<7&&p;d++,p=p.parentElement){" +
                        "var buttons=p.querySelectorAll('button,a,[role=button]');" +
                        "var text=(p.innerText||'');" +
                        "if(buttons.length>0&&text.toLowerCase().indexOf(wanted)!==-1){" +
                        "row=p;" +
                        "break;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!row){row=best.parentElement||best;}" +

                        "var rowText=(row.innerText||row.textContent||'').trim();" +

                        "return JSON.stringify({" +
                        "found:true," +
                        "text:rowText" +
                        "});" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String decoded =
                            decodeJavascriptString(
                                    value
                            );

                    try {
                        JSONObject result =
                                new JSONObject(
                                        decoded
                                );

                        boolean found =
                                result.optBoolean(
                                        "found",
                                        false
                                );

                        if (found) {
                            if (MODE_FIND.equals(mode)) {
                                foundForConfirmation();
                            } else {
                                openAddCreditsForExactEmail();
                            }

                            return;
                        }

                    } catch (Exception ignored) {
                    }

                    if (searchAttempts < 20) {
                        handler.postDelayed(
                                this::searchExactEmail,
                                650L
                        );
                    } else {
                        failBeforeSubmit(
                                "Não encontrei o e-mail exato da revenda no MASTERFLIX."
                        );
                    }
                }
        );
    }

    private void foundForConfirmation() {
        if (finished) return;

        finished =
                true;

        setState(
                "WAITING_CONFIRM"
        );

        updateStatus(
                "Revenda encontrada. Aguardando CONFIRMAR."
        );

        WhatsAppReply.send(
                context,
                whatsappNotification,
                "Encontrei o cadastro " +
                        email +
                        " no MASTERFLIX.\n\n" +
                        "Responda *CONFIRMAR* para adicionar 50 créditos."
        );

        cleanup();
    }

    private void openAddCreditsForExactEmail() {
        if (finished
                || webView == null) {
            return;
        }

        String emailJson =
                JSONObject.quote(
                        email
                );

        String script =
                "(function(){" +
                        "var wanted=" + emailJson + ".toLowerCase();" +

                        "function n(v){" +
                        "return (v||'').replace(/\\s+/g,' ').trim();" +
                        "}" +

                        "var all=document.querySelectorAll('body *');" +
                        "var best=null;" +
                        "var bestLen=999999;" +

                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=n(el.innerText||el.textContent);" +
                        "if(!text)continue;" +
                        "var low=text.toLowerCase();" +

                        "if(low===wanted||low.indexOf(wanted)!==-1){" +
                        "if(text.length<bestLen){" +
                        "best=el;" +
                        "bestLen=text.length;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!best){" +
                        "return JSON.stringify({ok:false,reason:'email'});" +
                        "}" +

                        "var row=best.closest('tr,[role=row]');" +

                        "if(!row){" +
                        "var p=best;" +

                        "for(var d=0;d<8&&p;d++,p=p.parentElement){" +
                        "var txt=n(p.innerText||p.textContent).toLowerCase();" +
                        "var buttons=p.querySelectorAll('button,a,[role=button]');" +

                        "if(txt.indexOf(wanted)!==-1&&buttons.length>0){" +
                        "row=p;" +
                        "break;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!row){" +
                        "row=best.parentElement||best;" +
                        "}" +

                        "var buttons=row.querySelectorAll('button,a,[role=button]');" +
                        "var add=null;" +

                        "for(var j=0;j<buttons.length;j++){" +
                        "var b=buttons[j];" +
                        "var bt=n(b.innerText||b.textContent).toLowerCase();" +
                        "var meta=(" +
                        "(b.getAttribute('aria-label')||'')+' '+" +
                        "(b.getAttribute('title')||'')+' '+" +
                        "(b.getAttribute('data-original-title')||'')" +
                        ").toLowerCase();" +

                        "if(bt==='+'" +
                        "||bt==='adicionar'" +
                        "||bt==='adicionar créditos'" +
                        "||bt==='adicionar creditos'" +
                        "||meta.indexOf('adicionar')!==-1" +
                        "||meta.indexOf('credit')!==-1" +
                        "||meta.indexOf('crédito')!==-1" +
                        "||meta.indexOf('credito')!==-1){" +
                        "add=b;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!add){" +
                        "return JSON.stringify({ok:false,reason:'plus'});" +
                        "}" +

                        "try{" +
                        "add.scrollIntoView({behavior:'auto',block:'center'});" +
                        "}catch(e){}" +

                        "try{" +
                        "add.click();" +
                        "}catch(e){" +
                        "try{" +
                        "add.dispatchEvent(new MouseEvent(" +
                        "'click'," +
                        "{bubbles:true,cancelable:true,view:window}" +
                        "));" +
                        "}catch(e2){" +
                        "return JSON.stringify({ok:false,reason:'click'});" +
                        "}" +
                        "}" +

                        "return JSON.stringify({ok:true});" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String decoded =
                            decodeJavascriptString(
                                    value
                            );

                    try {
                        JSONObject result =
                                new JSONObject(
                                        decoded
                                );

                        if (!result.optBoolean(
                                "ok",
                                false
                        )) {
                            String reason =
                                    result.optString(
                                            "reason",
                                            ""
                                    );

                            if ("plus".equals(reason)) {
                                failBeforeSubmit(
                                        "Encontrei a revenda pelo e-mail, mas não encontrei o botão de adicionar créditos. Nenhum crédito foi enviado."
                                );
                            } else if ("email".equals(reason)) {
                                failBeforeSubmit(
                                        "Não consegui localizar exatamente a revenda pelo e-mail. Nenhum crédito foi enviado."
                                );
                            } else {
                                failBeforeSubmit(
                                        "Não consegui abrir a janela de adicionar créditos. Nenhum crédito foi enviado."
                                );
                            }

                            return;
                        }

                        dialogAttempts = 0;

                        updateStatus(
                                "Revenda encontrada; abrindo crédito inicial +50"
                        );

                        handler.postDelayed(
                                this::fillCreditDialog,
                                650L
                        );

                    } catch (Exception e) {
                        failBeforeSubmit(
                                "Não consegui abrir a janela de adicionar créditos. Nenhum crédito foi enviado."
                        );
                    }
                }
        );
    }

    private void fillCreditDialog() {
        if (finished
                || webView == null
                || submitAttempted) {
            return;
        }

        dialogAttempts++;

        String script =
                "(function(){" +
                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var s=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';" +
                        "}" +

                        "function setValue(el,v){" +
                        "try{" +
                        "var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
                        "setter.call(el,v);" +
                        "}catch(e){el.value=v;}" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "}" +

                        "function n(v){" +
                        "return (v||'').replace(/\\s+/g,' ').trim().toLowerCase();" +
                        "}" +

                        "var dialogs=document.querySelectorAll('[role=dialog],.modal,.dialog,[class*=modal],[class*=dialog]');" +
                        "var dialog=null;" +

                        "for(var i=0;i<dialogs.length;i++){" +
                        "if(!visible(dialogs[i]))continue;" +
                        "var txt=n(dialogs[i].innerText||dialogs[i].textContent);" +
                        "if(txt.indexOf('adicionar créditos')!==-1" +
                        "||txt.indexOf('adicionar creditos')!==-1" +
                        "||txt.indexOf('transferir')!==-1){" +
                        "dialog=dialogs[i];" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!dialog){" +
                        "var bodyTxt=n(document.body.innerText||document.body.textContent);" +
                        "if(bodyTxt.indexOf('adicionar créditos')===-1" +
                        "&&bodyTxt.indexOf('adicionar creditos')===-1" +
                        "&&bodyTxt.indexOf('add credits')===-1){" +
                        "return 'no_dialog';" +
                        "}" +
                        "dialog=document.body;" +
                        "}" +

                        // Campo de créditos.
                        "var inputs=dialog.querySelectorAll('input');" +
                        "var creditInput=null;" +

                        "for(var j=0;j<inputs.length;j++){" +
                        "if(!visible(inputs[j]))continue;" +
                        "var type=(inputs[j].type||'').toLowerCase();" +
                        "if(type==='checkbox'||type==='radio')continue;" +
                        "var hint=n((inputs[j].placeholder||'')+' '+(inputs[j].getAttribute('aria-label')||''));" +

                        "if(type==='number'" +
                        "||hint.indexOf('credit')!==-1" +
                        "||hint.indexOf('quant')!==-1" +
                        "||hint.indexOf('valor')!==-1){" +
                        "creditInput=inputs[j];" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!creditInput){" +
                        "var nonChecks=[];" +
                        "for(var q=0;q<inputs.length;q++){" +
                        "var qt=(inputs[q].type||'').toLowerCase();" +
                        "if(visible(inputs[q])&&qt!=='checkbox'&&qt!=='radio'){" +
                        "nonChecks.push(inputs[q]);" +
                        "}" +
                        "}" +
                        "if(nonChecks.length===1)creditInput=nonChecks[0];" +
                        "}" +

                        "if(!creditInput)return 'no_input';" +

                        "setValue(creditInput,'50');" +

                        // Caixa obrigatória mostrada pelo MASTERFLIX:
                        // "Eu concordo em transferir 50 créditos".
                        "var checkbox=null;" +
                        "var checks=dialog.querySelectorAll('input[type=checkbox]');" +

                        "for(var k=0;k<checks.length;k++){" +
                        "var cb=checks[k];" +
                        "if(!visible(cb))continue;" +
                        "var id=cb.id||'';" +
                        "var labelText='';" +

                        "if(id){" +
                        "try{" +
                        "var lb=dialog.querySelector('label[for=\"'+CSS.escape(id)+'\"]');" +
                        "if(lb)labelText=n(lb.innerText||lb.textContent);" +
                        "}catch(e){}" +
                        "}" +

                        "if(!labelText){" +
                        "var parent=cb.parentElement;" +
                        "for(var d=0;d<4&&parent;d++,parent=parent.parentElement){" +
                        "var pt=n(parent.innerText||parent.textContent);" +
                        "if(pt.indexOf('concordo')!==-1||pt.indexOf('transferir')!==-1){" +
                        "labelText=pt;" +
                        "break;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(labelText.indexOf('concordo')!==-1" +
                        "||labelText.indexOf('transferir')!==-1){" +
                        "checkbox=cb;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!checkbox&&checks.length===1&&visible(checks[0])){" +
                        "checkbox=checks[0];" +
                        "}" +

                        "if(!checkbox){" +
                        // Fallback para checkbox customizado.
                        "var roles=dialog.querySelectorAll('[role=checkbox]');" +
                        "for(var r=0;r<roles.length;r++){" +
                        "var rt=n(roles[r].innerText||roles[r].textContent);" +
                        "var par=roles[r].parentElement;" +
                        "var pct=par?n(par.innerText||par.textContent):'';" +
                        "if(rt.indexOf('concordo')!==-1" +
                        "||rt.indexOf('transferir')!==-1" +
                        "||pct.indexOf('concordo')!==-1" +
                        "||pct.indexOf('transferir')!==-1){" +
                        "checkbox=roles[r];" +
                        "break;" +
                        "}" +
                        "}" +
                        "}" +

                        "if(!checkbox)return 'no_checkbox';" +

                        "if((checkbox.type||'').toLowerCase()==='checkbox'){" +
                        "if(!checkbox.checked){" +
                        "try{checkbox.click();}catch(e){" +
                        "checkbox.checked=true;" +
                        "checkbox.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "checkbox.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "}" +
                        "}" +
                        "if(!checkbox.checked)return 'checkbox_failed';" +
                        "}else{" +
                        "var checked=checkbox.getAttribute('aria-checked');" +
                        "if(checked!=='true'){" +
                        "try{checkbox.click();}catch(e){}" +
                        "}" +
                        "}" +

                        "return 'ready';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("ready".equals(result)) {
                        updateStatus(
                                "Revenda: 50 preenchido e autorização marcada"
                        );

                        handler.postDelayed(
                                this::submitCreditsOnce,
                                500L
                        );

                        return;
                    }

                    if (dialogAttempts < 24) {
                        handler.postDelayed(
                                this::fillCreditDialog,
                                450L
                        );
                    } else {
                        String message;

                        if ("no_checkbox".equals(result)
                                || "checkbox_failed".equals(result)) {

                            message =
                                    "Encontrei a janela de créditos, mas não consegui marcar “Eu concordo em transferir 50 créditos”. Nenhum crédito foi enviado.";

                        } else {
                            message =
                                    "A janela de adicionar créditos não apareceu corretamente. Nenhum crédito foi enviado.";
                        }

                        failBeforeSubmit(
                                message
                        );
                    }
                }
        );
    }

    private void submitCreditsOnce() {
        if (finished
                || webView == null
                || submitAttempted) {
            return;
        }

        // Marca ANTES do clique. A partir daqui, nunca há segundo envio automático.
        submitAttempted =
                true;

        prefs.edit()
                .putBoolean(
                        "reseller_submit_attempted_" + contactKey,
                        true
                )
                .putLong(
                        "reseller_submit_time_" + contactKey,
                        System.currentTimeMillis()
                )
                .putString(
                        "reseller_submit_email_" + contactKey,
                        email
                )
                .commit();

        String script =
                "(function(){" +
                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var s=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';" +
                        "}" +

                        "function n(v){return (v||'').replace(/\\s+/g,' ').trim().toLowerCase();}" +

                        "var dialogs=document.querySelectorAll('[role=dialog],.modal,.dialog,[class*=modal],[class*=dialog]');" +
                        "var root=document.body;" +

                        "for(var i=0;i<dialogs.length;i++){" +
                        "if(!visible(dialogs[i]))continue;" +
                        "var dt=n(dialogs[i].innerText);" +
                        "if(dt.indexOf('credit')!==-1||dt.indexOf('crédito')!==-1||dt.indexOf('credito')!==-1){" +
                        "root=dialogs[i];" +
                        "break;" +
                        "}" +
                        "}" +

                        "var buttons=root.querySelectorAll('button,[role=button],a');" +
                        "var submit=null;" +

                        "for(var j=0;j<buttons.length;j++){" +
                        "var b=buttons[j];" +
                        "if(!visible(b))continue;" +
                        "var t=n(b.innerText||b.textContent);" +

                        "if(t==='adicionar'" +
                        "||t==='confirmar'" +
                        "||t==='salvar'" +
                        "||t==='add'" +
                        "||t==='adicionar créditos'" +
                        "||t==='adicionar creditos'" +
                        "||t==='add credits'){" +
                        "submit=b;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!submit)return 'no_submit';" +

                        "try{submit.click();return 'clicked';}catch(e){" +
                        "try{submit.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));return 'clicked';}" +
                        "catch(e2){return 'error';}" +
                        "}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if (!"clicked".equals(result)) {
                        // O estado é incerto porque o envio já foi marcado como tentado.
                        uncertainAfterSubmit(
                                "Não consegui confirmar se o botão final foi acionado."
                        );

                        return;
                    }

                    updateStatus(
                            "Revenda: +50 enviado uma única vez; aguardando conclusão"
                    );

                    completionAttempts = 0;

                    handler.postDelayed(
                            this::waitForTransferCompletion,
                            700L
                    );
                }
        );
    }

    private void waitForTransferCompletion() {
        if (finished
                || webView == null) {
            return;
        }

        completionAttempts++;

        String script =
                "(function(){" +
                        "function visible(el){" +
                        "if(!el)return false;" +
                        "var r=el.getBoundingClientRect();" +
                        "var s=getComputedStyle(el);" +
                        "return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden';" +
                        "}" +
                        "function n(v){return (v||'').replace(/\\s+/g,' ').trim().toLowerCase();}" +

                        "var dialogs=document.querySelectorAll('[role=dialog],.modal,.dialog,[class*=modal],[class*=dialog]');" +
                        "var transferDialog=false;" +

                        "for(var i=0;i<dialogs.length;i++){" +
                        "if(!visible(dialogs[i]))continue;" +
                        "var txt=n(dialogs[i].innerText||dialogs[i].textContent);" +
                        "if(txt.indexOf('adicionar créditos')!==-1" +
                        "||txt.indexOf('adicionar creditos')!==-1" +
                        "||txt.indexOf('concordo em transferir')!==-1){" +
                        "transferDialog=true;" +
                        "break;" +
                        "}" +
                        "}" +

                        "if(!transferDialog){" +
                        "var bodyTxt=n(document.body.innerText||document.body.textContent);" +
                        "if(bodyTxt.indexOf('concordo em transferir 50 créditos')!==-1" +
                        "||bodyTxt.indexOf('concordo em transferir 50 creditos')!==-1){" +
                        "transferDialog=true;" +
                        "}" +
                        "}" +

                        "return transferDialog?'open':'closed';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("closed".equals(result)) {
                        successWithoutBalanceCheck();
                        return;
                    }

                    if (completionAttempts < 20) {
                        handler.postDelayed(
                                this::waitForTransferCompletion,
                                450L
                        );
                    } else {
                        uncertainAfterSubmit(
                                "O botão foi acionado uma única vez, mas a janela de transferência não fechou."
                        );
                    }
                }
        );
    }

    private void successWithoutBalanceCheck() {
        if (finished) return;

        finished =
                true;

        setState(
                "COMPLETE"
        );

        updateStatus(
                "Revenda: 50 créditos adicionados"
        );

        try {
            SecureStore secureStore =
                    new SecureStore(
                            context
                    );

            secureStore.put(
                    "linked_reseller_email_" + contactKey,
                    email
            );

        } catch (Exception ignored) {
        }

        prefs.edit()
                .putBoolean(
                        "reseller_submit_attempted_" + contactKey,
                        false
                )
                .apply();

        String supportGroupLink =
                prefs.getString(
                        "reseller_support_group_link",
                        ResellersActivity.DEFAULT_SUPPORT_GROUP_LINK
                ).trim();

        String successMessage =
                "✅ Painel de revenda ativado com sucesso!\n\n" +
                        "Foram adicionados *50 créditos*.";

        if (!supportGroupLink.isEmpty()) {
            successMessage +=
                    "\n\n📲 *Grupo de suporte:*\n" +
                            supportGroupLink;
        }

        WhatsAppReply.send(
                context,
                whatsappNotification,
                successMessage
        );

        cleanup();
    }

    private void uncertainAfterSubmit(
            String reason
    ) {
        if (finished) return;

        finished =
                true;

        setState(
                "REVIEW_REQUIRED"
        );

        updateStatus(
                "Revenda: revisão necessária após tentativa única de +50"
        );

        WhatsAppReply.send(
                context,
                whatsappNotification,
                "⚠️ Houve uma tentativa única de adicionar os 50 créditos, " +
                        "mas não consegui confirmar o clique final.\n\n" +
                        "Por segurança, *não vou tentar novamente automaticamente*. " +
                        "Confira essa revenda no MASTERFLIX."
        );

        cleanup();
    }

    private void failBeforeSubmit(
            String reason
    ) {
        if (finished) return;

        finished =
                true;

        setState(
                "ERROR"
        );

        updateStatus(
                "Revenda: " + reason
        );

        WhatsAppReply.send(
                context,
                whatsappNotification,
                "Não consegui concluir o cadastro da revenda automaticamente.\n\n" +
                        reason
        );

        cleanup();
    }

    private void setState(
            String state
    ) {
        prefs.edit()
                .putString(
                        "reseller_state_" + contactKey,
                        state
                )
                .apply();
    }

    private void updateStatus(
            String value
    ) {
        prefs.edit()
                .putString(
                        "last_reseller_status",
                        value
                )
                .apply();
    }

    private boolean nearlyEqual(
            double a,
            double b
    ) {
        return Math.abs(a - b) < 0.001d;
    }

    private String formatCredits(
            double value
    ) {
        if (Math.abs(
                value - Math.rint(value)
        ) < 0.001d) {
            return String.valueOf(
                    (long) Math.rint(value)
            );
        }

        return String.format(
                Locale.US,
                "%.2f",
                value
        );
    }

    private String decodeJavascriptString(
            String value
    ) {
        if (value == null
                || "null".equals(value)) {
            return "";
        }

        try {
            Object decoded =
                    new org.json.JSONTokener(
                            value
                    ).nextValue();

            return decoded == null
                    ? ""
                    : decoded.toString();

        } catch (Exception e) {
            return "";
        }
    }

    private void cleanup() {
        handler.post(
                () -> {
                    try {
                        if (webView != null) {
                            webView.stopLoading();
                            webView.loadUrl(
                                    "about:blank"
                            );
                            webView.destroy();
                            webView =
                                    null;
                        }

                    } catch (Throwable ignored) {
                    }

                    synchronized (LOCK) {
                        if (current == this) {
                            current =
                                    null;
                        }
                    }
                }
        );
    }
}
