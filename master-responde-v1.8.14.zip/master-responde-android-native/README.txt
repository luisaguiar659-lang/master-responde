MASTER RESPONDE v1.8.14

Base: v1.8.13.

MUDANÇA DO FLUXO DE NOVA REVENDA:

1. Cliente envia:
   Quero ser Revenda

2. Bot envia:
   - link de cadastro;
   - aviso para concluir o cadastro;
   - pedido para enviar o mesmo e-mail cadastrado.

3. Cliente envia o e-mail.

4. MASTER RESPONDE:
   - valida o formato;
   - abre a página de Revendas em segundo plano;
   - pesquisa o e-mail exato;
   - confirma se realmente existe como revenda no MASTERFLIX.

5. Se o e-mail estiver cadastrado:
   - NÃO adiciona créditos;
   - NÃO pede CONFIRMAR;
   - NÃO tenta ativar o painel;
   - envia a mensagem:
     "Cadastro de revenda confirmado!"
     "Entre no nosso grupo de suporte e solicite a ativação do seu painel."
   - envia o link configurado do grupo de suporte.

6. O cliente entra no grupo e solicita a ativação manualmente.

LINK DO GRUPO:
- continua editável dentro do módulo REVENDAS;
- não precisa gerar outro APK para trocar o link.

MENSAGEM APÓS CONFIRMAÇÃO:
- nesta versão existe um texto padrão;
- na etapa de MENSAGENS E TEMPOS ele passará a ser configurável manualmente dentro do aplicativo.

REMOVIDO DESTE FLUXO:
- +50 automático;
- leitura de saldo;
- tela Adicionar Créditos;
- checkbox de transferência;
- clique em Adicionar;
- ativação automática do painel.

PRESERVADO:
- geração automática de testes;
- MASTERFLIX login e sessão;
- regras;
- categorias;
- @infor;
- proteção contra mensagens duplicadas;
- link de cadastro editável;
- link do grupo de suporte editável.
