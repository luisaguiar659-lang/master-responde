MASTER RESPONDE v1.17.3

CORREÇÃO FOCADA NO TESTE AUTOMÁTICO

A v1.17.3 restaura o motor de teste em segundo plano comprovado da v1.16,
que já havia gerado e enviado testes corretamente com o aplicativo em
segundo plano.

ALTERAÇÃO
- removida a espera experimental por viewport/Teste Rápido introduzida depois;
- restaurados os mesmos tempos, carregamento e pipeline da v1.16;
- mantido o Painel Sigma genérico da v1.17;
- a URL do dashboard vem do Perfil Sigma ativo;
- a seleção do teste é dinâmica;
- se houver "Teste preferido", ele tem prioridade;
- se estiver vazio, prioriza COMPLETO, depois 1H, e aceita outra opção com TESTE;
- após acionar o teste, a rotina comprovada continua procurando COPIAR;
- se o clipboard não entregar o texto, usa a leitura de Detalhes do Cliente;
- trava de uma automação de teste por vez permanece ativa.

NÃO ALTERADO
- fluxo de revenda;
- confirmação por e-mail;
- grupo de suporte;
- @infor;
- regras;
- mídias/links;
- mensagens e tempos;
- configurações;
- assinatura release permanente.

ASSINATURA
Continua usando os mesmos quatro GitHub Repository Secrets.
Não altere a keystore nem as senhas.

VERSÃO
1.17.3
versionCode 47
