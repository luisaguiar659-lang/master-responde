package com.masterresponde.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MasterflixActivity extends Activity {

    private static final String LOGIN_URL =
            "https://masterflix.sigmab.pro/#/sign-in";

    private static final String DASHBOARD_URL =
            "https://masterflix.sigmab.pro/#/dashboard";

    private SharedPreferences prefs;
    private SecureStore secureStore;

    private EditText userField;
    private EditText passField;
    private TextView sessionStatus;
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(
                "master_responde",
                MODE_PRIVATE
        );

        secureStore = new SecureStore(this);

        buildScreen();
        loadSavedCredentials();
        updateSessionStatus();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("MasterRespondeBridge");
            webView.stopLoading();
            webView.destroy();
        }

        super.onDestroy();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button back = new Button(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(24);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        header.addView(
                back,
                new LinearLayout.LayoutParams(
                        dp(58),
                        dp(54)
                )
        );

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.addView(
                text(
                        "MASTERFLIX",
                        21,
                        Color.WHITE,
                        true
                )
        );
        titleBox.addView(
                text(
                        "Login e sessão do painel",
                        12,
                        Color.rgb(150, 160, 170),
                        false
                )
        );

        header.addView(
                titleBox,
                new LinearLayout.LayoutParams(
                        0,
                        dp(58),
                        1f
                )
        );

        root.addView(header);

        View line = new View(this);
        line.setBackgroundResource(
                getResources().getIdentifier(
                        "line",
                        "drawable",
                        getPackageName()
                )
        );

        root.addView(
                line,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(3)
                )
        );

        ScrollView scroll = new ScrollView(this);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(30)
        );

        LinearLayout statusCard = card();

        statusCard.addView(
                text(
                        "SESSÃO",
                        11,
                        Color.rgb(255, 150, 0),
                        true
                )
        );

        sessionStatus = text(
                "● Login necessário",
                16,
                Color.rgb(255, 145, 0),
                true
        );

        sessionStatus.setPadding(
                0,
                dp(8),
                0,
                0
        );

        statusCard.addView(sessionStatus);
        content.addView(statusCard);

        gap(content, 12);

        LinearLayout loginCard = card();

        loginCard.addView(
                text(
                        "CREDENCIAIS",
                        11,
                        Color.rgb(255, 150, 0),
                        true
                )
        );

        userField = field(
                "Usuário ou E-mail"
        );

        loginCard.addView(userField);

        passField = field(
                "Senha"
        );

        passField.setInputType(
                android.text.InputType.TYPE_CLASS_TEXT
                        | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        loginCard.addView(passField);

        Button save = actionButton(
                "SALVAR CREDENCIAIS",
                true
        );

        save.setOnClickListener(
                v -> saveCredentials()
        );

        loginCard.addView(save);

        Button fill = actionButton(
                "PREENCHER LOGIN SALVO",
                false
        );

        fill.setOnClickListener(
                v -> fillSavedLogin()
        );

        loginCard.addView(fill);

        Button clearSession = actionButton(
                "ENCERRAR SESSÃO",
                false
        );

        clearSession.setOnClickListener(
                v -> confirmClearSession()
        );

        loginCard.addView(clearSession);

        content.addView(loginCard);

        gap(content, 12);

        TextView notice = text(
                "A v1.6 salva usuário e senha criptografados no aparelho. " +
                "O MASTER RESPONDE pode preencher os campos do login, mas NÃO marca " +
                "“Verificado”, não resolve CAPTCHA e não tenta contornar proteções do painel. " +
                "Quando essa verificação aparecer, conclua manualmente e toque em Continuar.",
                12,
                Color.rgb(150, 160, 170),
                false
        );

        content.addView(notice);

        gap(content, 12);

        LinearLayout browserCard = card();

        LinearLayout browserHeader = new LinearLayout(this);
        browserHeader.setOrientation(LinearLayout.HORIZONTAL);
        browserHeader.setGravity(Gravity.CENTER_VERTICAL);

        browserHeader.addView(
                text(
                        "PAINEL MASTERFLIX",
                        12,
                        Color.WHITE,
                        true
                ),
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        Button loginButton = smallButton("LOGIN");
        loginButton.setOnClickListener(
                v -> openLogin()
        );

        browserHeader.addView(loginButton);

        Button dashboardButton = smallButton("PAINEL");
        dashboardButton.setOnClickListener(
                v -> openDashboard()
        );

        browserHeader.addView(dashboardButton);

        browserCard.addView(browserHeader);

        webView = new WebView(this);

        LinearLayout.LayoutParams webLp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(500)
                );

        webLp.setMargins(
                0,
                dp(10),
                0,
                0
        );

        webView.setLayoutParams(webLp);
        configureWebView();

        browserCard.addView(webView);

        content.addView(browserCard);

        scroll.addView(content);

        root.addView(
                scroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        setContentView(root);

        openDashboard();
    }

    private void configureWebView() {
        WebSettings settings =
                webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        CookieManager cookieManager =
                CookieManager.getInstance();

        cookieManager.setAcceptCookie(true);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            cookieManager.setAcceptThirdPartyCookies(
                    webView,
                    true
            );
        }

        webView.addJavascriptInterface(
                new MasterRespondeBridge(),
                "MasterRespondeBridge"
        );

        webView.setWebViewClient(
                new WebViewClient() {

                    @Override
                    public void onPageFinished(
                            WebView view,
                            String url
                    ) {
                        super.onPageFinished(
                                view,
                                url
                        );

                        inspectCurrentLocation();
                    }

                    @Override
                    public void doUpdateVisitedHistory(
                            WebView view,
                            String url,
                            boolean isReload
                    ) {
                        super.doUpdateVisitedHistory(
                                view,
                                url,
                                isReload
                        );

                        inspectCurrentLocation();
                    }
                }
        );
    }

    private void inspectCurrentLocation() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(function(){try{" +
                        "return JSON.stringify({" +
                        "href:location.href," +
                        "path:location.hash||''" +
                        "});" +
                        "}catch(e){return ''}})();",
                value -> {
                    if (value == null) return;

                    String decoded = decodeJavascriptString(
                            value
                    );

                    if (decoded.isEmpty()) return;

                    try {
                        JSONObject object =
                                new JSONObject(decoded);

                        String href =
                                object.optString(
                                        "href",
                                        ""
                                );

                        updateSessionFromUrl(
                                href
                        );

                    } catch (Exception ignored) {
                    }
                }
        );
    }

    private void updateSessionFromUrl(
            String url
    ) {
        if (url == null) return;

        if (url.contains("#/dashboard")) {
            prefs.edit()
                    .putBoolean(
                            "masterflix_session_active",
                            true
                    )
                    .apply();

            runOnUiThread(
                    this::updateSessionStatus
            );

        } else if (url.contains("#/sign-in")) {
            prefs.edit()
                    .putBoolean(
                            "masterflix_session_active",
                            false
                    )
                    .apply();

            runOnUiThread(
                    this::updateSessionStatus
            );
        }
    }

    private void openLogin() {
        webView.loadUrl(LOGIN_URL);
    }

    private void openDashboard() {
        webView.loadUrl(DASHBOARD_URL);
    }

    private void saveCredentials() {
        String user =
                userField.getText()
                        .toString()
                        .trim();

        String pass =
                passField.getText()
                        .toString();

        if (user.isEmpty()) {
            userField.setError(
                    "Informe o usuário ou e-mail."
            );
            return;
        }

        if (pass.isEmpty()) {
            passField.setError(
                    "Informe a senha."
            );
            return;
        }

        try {
            secureStore.put(
                    "masterflix_user",
                    user
            );

            secureStore.put(
                    "masterflix_pass",
                    pass
            );

            prefs.edit()
                    .putBoolean(
                            "masterflix_credentials_saved",
                            true
                    )
                    .apply();

            hideKeyboard();

            Toast.makeText(
                    this,
                    "Credenciais salvas com criptografia.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Não foi possível salvar as credenciais.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void loadSavedCredentials() {
        String user =
                secureStore.get(
                        "masterflix_user"
                );

        String pass =
                secureStore.get(
                        "masterflix_pass"
                );

        userField.setText(user);
        passField.setText(pass);
    }

    private void fillSavedLogin() {
        final String user =
                secureStore.get(
                        "masterflix_user"
                );

        final String pass =
                secureStore.get(
                        "masterflix_pass"
                );

        if (user.isEmpty()
                || pass.isEmpty()) {

            Toast.makeText(
                    this,
                    "Salve primeiro o usuário e a senha.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (webView.getUrl() == null
                || !webView.getUrl()
                .contains("masterflix.sigmab.pro")) {

            openLogin();
        }

        final String userJson =
                JSONObject.quote(user);

        final String passJson =
                JSONObject.quote(pass);

        String script =
                "(function(){" +
                        "var inputs=document.querySelectorAll('input');" +
                        "var user=null,pass=null;" +
                        "for(var i=0;i<inputs.length;i++){" +
                        "var t=(inputs[i].type||'').toLowerCase();" +
                        "if(t==='password'&&!pass){pass=inputs[i];}" +
                        "else if((t==='text'||t==='email'||!t)&&!user){user=inputs[i];}" +
                        "}" +
                        "function set(el,v){" +
                        "if(!el)return false;" +
                        "var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
                        "setter.call(el,v);" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "return true;" +
                        "}" +
                        "return set(user," + userJson + ")&&set(pass," + passJson + ");" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> Toast.makeText(
                        this,
                        "Campos preenchidos. Conclua “Verificado” e toque em Continuar.",
                        Toast.LENGTH_LONG
                ).show()
        );
    }

    private void confirmClearSession() {
        new AlertDialog.Builder(this)
                .setTitle("Encerrar sessão MASTERFLIX?")
                .setMessage(
                        "Os cookies da sessão serão apagados. " +
                        "As credenciais criptografadas continuarão salvas."
                )
                .setNegativeButton(
                        "CANCELAR",
                        null
                )
                .setPositiveButton(
                        "ENCERRAR",
                        (dialog, which) ->
                                clearSession()
                )
                .show();
    }

    private void clearSession() {
        CookieManager.getInstance()
                .removeAllCookies(
                        value -> {
                            CookieManager.getInstance()
                                    .flush();

                            prefs.edit()
                                    .putBoolean(
                                            "masterflix_session_active",
                                            false
                                    )
                                    .apply();

                            updateSessionStatus();
                            openLogin();

                            Toast.makeText(
                                    this,
                                    "Sessão encerrada.",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                );
    }

    private void updateSessionStatus() {
        boolean active =
                prefs.getBoolean(
                        "masterflix_session_active",
                        false
                );

        if (active) {
            sessionStatus.setText(
                    "● Sessão ativa"
            );

            sessionStatus.setTextColor(
                    Color.rgb(
                            0,
                            184,
                            255
                    )
            );

        } else {
            sessionStatus.setText(
                    "● Login necessário"
            );

            sessionStatus.setTextColor(
                    Color.rgb(
                            255,
                            145,
                            0
                    )
            );
        }
    }

    private String decodeJavascriptString(
            String value
    ) {
        if (value == null
                || "null".equals(value)) {
            return "";
        }

        try {
            return new org.json.JSONTokener(
                    value
            ).nextValue().toString();

        } catch (Exception e) {
            return "";
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager manager =
                    (InputMethodManager) getSystemService(
                            Context.INPUT_METHOD_SERVICE
                    );

            View current =
                    getCurrentFocus();

            if (manager != null
                    && current != null) {
                manager.hideSoftInputFromWindow(
                        current.getWindowToken(),
                        0
                );
            }

        } catch (Exception ignored) {
        }
    }

    private LinearLayout card() {
        LinearLayout c =
                new LinearLayout(this);

        c.setOrientation(
                LinearLayout.VERTICAL
        );

        c.setPadding(
                dp(15),
                dp(15),
                dp(15),
                dp(15)
        );

        c.setBackgroundResource(
                getResources().getIdentifier(
                        "card",
                        "drawable",
                        getPackageName()
                )
        );

        return c;
    }

    private EditText field(
            String hint
    ) {
        EditText e =
                new EditText(this);

        e.setHint(hint);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(
                Color.rgb(
                        130,
                        140,
                        150
                )
        );

        e.setTextSize(14);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        lp.setMargins(
                0,
                dp(5),
                0,
                dp(8)
        );

        e.setLayoutParams(lp);

        return e;
    }

    private Button actionButton(
            String label,
            boolean orange
    ) {
        Button b =
                new Button(this);

        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setTypeface(null, 1);

        b.setBackgroundResource(
                getResources().getIdentifier(
                        orange
                                ? "button_orange"
                                : "button_dark",
                        "drawable",
                        getPackageName()
                )
        );

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52)
                );

        lp.setMargins(
                0,
                dp(4),
                0,
                dp(4)
        );

        b.setLayoutParams(lp);

        return b;
    }

    private Button smallButton(
            String label
    ) {
        Button b =
                new Button(this);

        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(10);
        b.setTypeface(null, 1);

        b.setBackgroundResource(
                getResources().getIdentifier(
                        "button_dark",
                        "drawable",
                        getPackageName()
                )
        );

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        dp(82),
                        dp(46)
                );

        lp.setMargins(
                dp(4),
                0,
                0,
                0
        );

        b.setLayoutParams(lp);

        return b;
    }

    private TextView text(
            String value,
            int size,
            int color,
            boolean bold
    ) {
        TextView t =
                new TextView(this);

        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);

        if (bold) {
            t.setTypeface(null, 1);
        }

        return t;
    }

    private void gap(
            LinearLayout parent,
            int height
    ) {
        View v =
                new View(this);

        parent.addView(
                v,
                new LinearLayout.LayoutParams(
                        1,
                        dp(height)
                )
        );
    }

    private int dp(
            int value
    ) {
        return Math.round(
                value
                        * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    public class MasterRespondeBridge {
        @JavascriptInterface
        public void sessionUrl(
                String url
        ) {
            updateSessionFromUrl(
                    url
            );
        }
    }
}
