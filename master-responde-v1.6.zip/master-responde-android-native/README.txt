MASTER RESPONDE v1.6

BASE ESTÁVEL:
- dashboard
- Bot + acesso às notificações
- autorespostas privadas
- regras configuráveis
- categorias com várias respostas
- @infor em grupos
- processamento de mensagens agrupadas

ÚNICA FUNÇÃO NOVA DA v1.6:
MASTERFLIX LOGIN + SESSÃO

URLS:
Login:
https://masterflix.sigmab.pro/#/sign-in

Dashboard:
https://masterflix.sigmab.pro/#/dashboard

O QUE A v1.6 FAZ:
- abre o MASTERFLIX dentro de WebView;
- salva usuário/e-mail e senha criptografados com Android Keystore;
- botão PREENCHER LOGIN SALVO;
- mantém cookies da sessão;
- detecta Dashboard como "Sessão ativa";
- detecta Sign-in como "Login necessário";
- botão ENCERRAR SESSÃO apaga cookies;
- dashboard principal mostra o estado da sessão.

SEGURANÇA:
- senha não é salva em texto puro;
- o app não marca "Verificado";
- o app não resolve CAPTCHA;
- o app não contorna proteção antibot;
- se houver verificação, o usuário conclui manualmente e toca Continuar.

AINDA NÃO EXISTE:
- gerar teste no MASTERFLIX;
- revendas;
- adicionar 50 créditos;
- automação das opções 7 e 8 do @infor.

TESTE DA ETAPA:
1. Abra MASTER RESPONDE.
2. Toque no card MASTERFLIX.
3. Preencha usuário/e-mail e senha.
4. Toque SALVAR CREDENCIAIS.
5. Toque LOGIN.
6. Toque PREENCHER LOGIN SALVO.
7. Faça manualmente a verificação se aparecer.
8. Toque Continuar no painel.
9. Quando abrir o dashboard, o status deve mudar para "Sessão ativa".
10. Feche a tela MASTERFLIX e abra novamente.
11. O painel deve reaproveitar a sessão enquanto os cookies continuarem válidos.
