MASTER RESPONDE v1.7.2

Base: v1.7.1.

CORREÇÃO PRINCIPAL:
Após gerar o teste, o bot agora DESCE automaticamente pelo painel
até localizar o botão COPIAR.

O QUE MUDOU:
- varre todos os contêineres roláveis internos do MASTERFLIX;
- faz rolagem em etapas;
- repete até encontrar exatamente o botão COPIAR;
- usa scrollIntoView quando o botão aparece;
- clica somente em COPIAR, não em COPIAR E FECHAR.

CAPTURA DO TESTE:
- instala um interceptador no próprio WebView;
- quando o painel chama navigator.clipboard.writeText,
  o MASTER RESPONDE recebe o mesmo texto diretamente;
- o clipboard do Android continua como segunda opção;
- se ambos falharem, lê o bloco completo de Detalhes do Cliente
  e só aceita se validar usuário, senha e M3U.

TESTE:
1. Mantenha MASTERFLIX com sessão ativa.
2. Envie "Teste" em conversa privada.
3. Aguarde "Gerando seu teste, aguarde..."
4. Observe a tela MASTERFLIX.
5. Depois da geração, o painel deve rolar para baixo sozinho.
6. O status deve passar por:
   "Descendo no teste para localizar COPIAR..."
   "Botão COPIAR localizado. Rolando até ele..."
   "COPIAR acionado. Capturando o teste..."
7. O conteúdo completo deve voltar ao mesmo WhatsApp.

Ainda não inclui revenda ou créditos +50.
