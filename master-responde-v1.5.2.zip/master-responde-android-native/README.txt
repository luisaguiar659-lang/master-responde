MASTER RESPONDE v1.5.2

Base: v1.5.1.

CORREÇÃO ÚNICA:
- Corrige o caso em que a primeira opção do menu em grupo era ignorada
  e somente a segunda mensagem funcionava.

CAUSA:
- Em alguns aparelhos/versões do WhatsApp Business,
  a primeira notificação do grupo não marca imediatamente
  EXTRA_IS_GROUP_CONVERSATION como true.

CORREÇÃO:
- Agora o MASTER RESPONDE considera grupo quando:
  1) o indicador oficial de grupo estiver ativo; OU
  2) houver título de conversa de grupo na notificação.

TESTE:
1. Envie @infor
2. Aguarde o menu
3. Envie somente 1
4. A opção 1 deve executar imediatamente, sem precisar mandar 2 depois.

Também teste direto:
@infor 1

A resposta deve acontecer na primeira tentativa.
