MASTER RESPONDE v1.17.17
Base: v1.17.16

Novo módulo: ATENDIMENTO PRIVADO
- Funil com contexto por conversa privada.
- Gatilho padrão do anúncio: "Olá! Posso ter mais informações sobre isso?"
- Menu inicial: MASTERFLIX / MASTER IBO / MASTER XCLOUD / pacote completo.
- Dentro do MASTERFLIX, os números passam a ter outro significado sem conflito com o menu inicial.
- Opção 1 chama o motor de teste existente.
- Opção 2 chama o fluxo de nova revenda existente.
- Opções 3 e 4 exibem textos editáveis.
- 9 volta ao menu principal; 0 encerra o menu e transfere para suporte.
- Contexto expira por tempo configurável (padrão 900 segundos).
- Textos e gatilho editáveis pelo próprio app no novo menu ATENDIMENTO PRIVADO.

O motor MASTERFLIX existente não foi alterado nesta mudança, exceto pelo roteamento para chamá-lo a partir do novo menu.
