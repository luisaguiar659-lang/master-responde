MASTER RESPONDE v1.17.20

Base: v1.17.18 menu numerico.
Correcao: mensagens enviadas pelo proprio bot sao registradas e ignoradas quando reaparecem na notificacao do WhatsApp Business. Isso evita que o menu ou respostas do bot sejam interpretados como nova entrada do cliente e disparem "Opcao invalida" automaticamente.

Motor MASTERFLIX e fluxos existentes preservados.
