package com.masterresponde.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class PrivateServiceActivity extends Activity {
    private SharedPreferences prefs;
    private LinearLayout content;
    private CheckBox enabled;
    private EditText trigger, ttl, main, masterflix, postpaid, apps, ibo, xcloud, pack, support, invalid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("master_responde", MODE_PRIVATE);
        buildScreen();
        load();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(14), dp(10));

        Button back = new Button(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(24);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("ATENDIMENTO PRIVADO", 21, Color.WHITE, true));
        titles.addView(text("Funil dos anúncios e menus por contexto", 12, Color.rgb(150,160,170), false));
        header.addView(titles, new LinearLayout.LayoutParams(0, dp(58), 1f));
        root.addView(header);

        View line = new View(this);
        line.setBackgroundResource(getResources().getIdentifier("line", "drawable", getPackageName()));
        root.addView(line, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(40));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        enabled = new CheckBox(this);
        enabled.setText("Ativar atendimento privado com contexto");
        enabled.setTextColor(Color.WHITE);
        enabled.setTextSize(16);
        content.addView(enabled);
        hint("Quando ativo, o número 1, 2, 3... muda de função conforme o menu em que o cliente está.");

        trigger = field("Mensagem exata que inicia o atendimento");
        section("GATILHO DO ANÚNCIO");
        content.addView(trigger);

        ttl = field("Tempo do menu aberto (segundos)");
        content.addView(ttl);
        hint("Depois desse tempo sem interação, os números deixam de ser interpretados como opções do menu.");

        section("MENU INICIAL");
        main = multi("Mensagem do menu inicial"); content.addView(main);

        section("MASTERFLIX");
        masterflix = multi("Apresentação e opções do MASTERFLIX"); content.addView(masterflix);
        postpaid = multi("Explicação do pós-pago"); content.addView(postpaid);
        apps = multi("Aplicativos e recursos"); content.addView(apps);

        section("OUTROS PRODUTOS");
        ibo = multi("MASTER IBO"); content.addView(ibo);
        xcloud = multi("MASTER XCLOUD"); content.addView(xcloud);
        pack = multi("Pacote completo"); content.addView(pack);

        section("MENSAGENS DE CONTROLE");
        support = multi("Falar com suporte"); content.addView(support);
        invalid = multi("Opção inválida no menu inicial"); content.addView(invalid);

        Button save = button("SALVAR ATENDIMENTO PRIVADO", true);
        save.setOnClickListener(v -> save());
        content.addView(save);

        Button defaults = button("RESTAURAR TEXTOS PADRÃO", false);
        defaults.setOnClickListener(v -> restoreDefaults());
        content.addView(defaults);
    }

    private void load() {
        enabled.setChecked(prefs.getBoolean("private_service_enabled", true));
        trigger.setText(prefs.getString("private_service_trigger", "Olá! Posso ter mais informações sobre isso?"));
        ttl.setText(String.valueOf(prefs.getLong("private_service_ttl_seconds", 900L)));
        main.setText(prefs.getString("private_service_main_message", defaultMain()));
        masterflix.setText(prefs.getString("private_service_masterflix_message", defaultMasterflix()));
        postpaid.setText(prefs.getString("private_service_masterflix_postpaid", defaultPostpaid()));
        apps.setText(prefs.getString("private_service_masterflix_apps", defaultApps()));
        ibo.setText(prefs.getString("private_service_ibo_message", defaultIbo()));
        xcloud.setText(prefs.getString("private_service_xcloud_message", defaultXcloud()));
        pack.setText(prefs.getString("private_service_package_message", defaultPack()));
        support.setText(prefs.getString("private_service_support_message", "👤 Um atendente continuará o suporte por aqui."));
        invalid.setText(prefs.getString("private_service_invalid_message", "⚠️ Opção não reconhecida. Digite 1, 2, 3 ou 4.\nDigite 0 para falar com o suporte."));
    }

    private void save() {
        long seconds = 900L;
        try { seconds = Long.parseLong(ttl.getText().toString().trim()); } catch (Exception ignored) {}
        seconds = Math.max(60L, seconds);
        prefs.edit()
                .putBoolean("private_service_enabled", enabled.isChecked())
                .putString("private_service_trigger", trigger.getText().toString().trim())
                .putLong("private_service_ttl_seconds", seconds)
                .putString("private_service_main_message", main.getText().toString().trim())
                .putString("private_service_masterflix_message", masterflix.getText().toString().trim())
                .putString("private_service_masterflix_postpaid", postpaid.getText().toString().trim())
                .putString("private_service_masterflix_apps", apps.getText().toString().trim())
                .putString("private_service_ibo_message", ibo.getText().toString().trim())
                .putString("private_service_xcloud_message", xcloud.getText().toString().trim())
                .putString("private_service_package_message", pack.getText().toString().trim())
                .putString("private_service_support_message", support.getText().toString().trim())
                .putString("private_service_invalid_message", invalid.getText().toString().trim())
                .apply();
        Toast.makeText(this, "Atendimento privado salvo.", Toast.LENGTH_SHORT).show();
    }

    private void restoreDefaults() {
        enabled.setChecked(true);
        trigger.setText("Olá! Posso ter mais informações sobre isso?");
        ttl.setText("900");
        main.setText(defaultMain()); masterflix.setText(defaultMasterflix()); postpaid.setText(defaultPostpaid());
        apps.setText(defaultApps()); ibo.setText(defaultIbo()); xcloud.setText(defaultXcloud()); pack.setText(defaultPack());
        support.setText("👤 Um atendente continuará o suporte por aqui.");
        invalid.setText("⚠️ Opção não reconhecida. Digite 1, 2, 3 ou 4.\nDigite 0 para falar com o suporte.");
    }

    private String defaultMain() { return "👋 Olá! Seja bem-vindo(a) à MASTER.\n\nTrabalhamos com soluções para quem deseja iniciar ou ampliar sua operação como revendedor.\n\n📺 1 — Quero conhecer a revenda MASTERFLIX\n📱 2 — Quero conhecer o MASTER IBO\n☁️ 3 — Quero conhecer o MASTER XCLOUD\n🚀 4 — Quero conhecer o pacote completo\n\nDigite o número da opção desejada para continuar."; }
    private String defaultMasterflix() { return "📺 REVENDA MASTERFLIX\n\nTrabalhe com um painel de revenda completo, com geração e gerenciamento dos seus próprios clientes.\n\n✅ Sistema no modelo pós-pago\n✅ Você paga conforme os ativos\n✅ Testes gerados pelo próprio sistema\n✅ Painel para gerenciamento dos clientes\n✅ Aplicativos e recursos para auxiliar sua operação\n✅ Suporte para revendedores\n\n💰 Valor: R$ 5,00 por ativo\n📅 Acerto todo dia 8\n\nPara continuar, escolha:\n\n1 — Quero fazer um teste\n2 — Quero me cadastrar como revendedor\n3 — Quero saber como funciona o pós-pago\n4 — Quero conhecer os aplicativos disponíveis\n9 — Voltar ao menu inicial\n0 — Falar com atendimento"; }
    private String defaultPostpaid() { return "💳 COMO FUNCIONA O PÓS-PAGO\n\nNo MASTERFLIX você trabalha conforme os clientes ativos. O valor é de R$ 5,00 por ativo e o acerto é realizado todo dia 8.\n\nDigite 9 para voltar ou 0 para falar com o suporte."; }
    private String defaultApps() { return "📱 APLICATIVOS E RECURSOS\n\nO revendedor conta com aplicativos e ferramentas para facilitar a operação. Os links e orientações ficam disponíveis no suporte e também no menu @infor dos grupos.\n\nDigite 9 para voltar ou 0 para falar com o suporte."; }
    private String defaultIbo() { return "📱 MASTER IBO\n\nSolução personalizável para sua operação de revenda.\n\nDigite 9 para voltar ao menu ou 0 para falar com o suporte e receber valores e detalhes."; }
    private String defaultXcloud() { return "☁️ MASTER XCLOUD\n\nSolução personalizável para complementar sua operação de revenda.\n\nDigite 9 para voltar ao menu ou 0 para falar com o suporte e receber valores e detalhes."; }
    private String defaultPack() { return "🚀 PACOTE COMPLETO MASTER\n\nConheça uma operação integrada com MASTERFLIX, MASTER IBO e MASTER XCLOUD.\n\nDigite 9 para voltar ao menu ou 0 para falar com o suporte e montar sua opção."; }

    private void section(String t) { TextView v=text(t,13,Color.rgb(0,188,235),true); v.setPadding(0,dp(18),0,dp(8)); content.addView(v); }
    private void hint(String t) { TextView v=text(t,12,Color.rgb(145,155,165),false); v.setPadding(dp(4),dp(4),dp(4),dp(8)); content.addView(v); }
    private EditText field(String h) { EditText e=new EditText(this); e.setHint(h); e.setHintTextColor(Color.rgb(120,130,140)); e.setTextColor(Color.WHITE); e.setTextSize(15); e.setPadding(dp(12),dp(10),dp(12),dp(10)); return e; }
    private EditText multi(String h) { EditText e=field(h); e.setMinLines(4); e.setGravity(Gravity.TOP); return e; }
    private Button button(String label, boolean primary) { Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setTextSize(14); b.setAllCaps(false); b.setBackgroundResource(getResources().getIdentifier(primary?"button_orange":"button_dark","drawable",getPackageName())); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(58)); lp.setMargins(0,dp(14),0,0); b.setLayoutParams(lp); return b; }
    private TextView text(String s,int sp,int color,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(sp); v.setTextColor(color); if(bold) v.setTypeface(null,android.graphics.Typeface.BOLD); return v; }
    private int dp(int n){ return Math.round(n*getResources().getDisplayMetrics().density); }
}
