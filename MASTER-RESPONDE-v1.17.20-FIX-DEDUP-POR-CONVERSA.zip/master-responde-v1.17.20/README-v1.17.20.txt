MASTER RESPONDE v1.17.20

Base: v1.17.19

Correção: deduplicação e proteção contra auto-resposta por conversa/contato.
- Leads diferentes podem enviar a mesma mensagem do anúncio ao mesmo tempo.
- O bloqueio de eco do próprio bot só é aplicado quando existe identidade confiável da conversa (shortcut/título).
- Sem identidade confiável, não é aplicado bloqueio global por conteúdo, evitando suprimir contatos diferentes.
- Mantidos menu numérico, motor MASTERFLIX, teste e fluxo de revenda.

versionName 1.17.20
versionCode 64
