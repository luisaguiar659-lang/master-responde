MASTER RESPONDE v1.17.16

Base: v1.17.15 (derivada da v1.17.12 estável)

Alteração exclusiva desta versão:
- mantém o motor de teste estável da v1.17.12;
- ao detectar #/sign-in durante um teste, tenta login automático usando as credenciais salvas;
- só prossegue para gerar o teste depois que o dashboard autenticado voltar;
- não limpa cookies nem sessão ao encerrar o teste;
- se houver captcha/verificação manual ou o login automático falhar, encerra o pedido sem entrar em loop.

Versionamento:
- versionName 1.17.16
- versionCode 60
