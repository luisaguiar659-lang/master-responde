MASTER RESPONDE v1.17.20

Atendimento privado guiado exclusivamente por numeros.
Menu inicial: 1 MASTERFLIX, 2 MASTER IBO, 3 MASTER XCLOUD, 4 Pacote completo, 0 suporte.
Submenu MASTERFLIX: 1 teste, 2 nova revenda, 3 pos-pago, 4 aplicativos, 9 voltar, 0 suporte.
Entradas por palavras foram removidas do menu para evitar erros e conflitos.
Motor de teste MASTERFLIX preservado.
