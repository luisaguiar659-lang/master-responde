MASTER RESPONDE v1.5.4

Base: v1.5.3.

CORREÇÃO ÚNICA:
- reforço definitivo contra respostas duplicadas no menu de grupos.

O que mudou:
- o bloqueio de duplicidade NÃO depende mais do ID da notificação;
- também NÃO depende do nome/identificação do grupo;
- o mesmo comando recebido em grupo fica bloqueado por 2,5 segundos.

Exemplo:
se o WhatsApp entregar duas vezes a mensagem "3",
o MASTER RESPONDE processa somente a primeira.

TESTE:
1. Envie @infor
2. Envie 1
3. Deve aparecer somente UMA resposta
4. Envie 2
5. Deve aparecer somente UMA resposta
6. Repita com 3, 4, 5 e 6

IMPORTANTE:
As mensagens avisando que uma categoria "ainda não foi configurada"
são normais enquanto essa categoria não tiver respostas cadastradas em MÍDIAS.

Nenhuma função nova foi adicionada.
