MASTER RESPONDE v1.8.11

Base: v1.8.10.

MUDANÇA VISUAL:
O MASTERFLIX não fica mais preso em um mini painel depois que a sessão
chega ao Dashboard.

Ao entrar no Dashboard:
- o WebView é retirado do card do MASTER RESPONDE;
- ocupa 100% da Activity;
- o usuário vê o layout original do MASTERFLIX em tela cheia;
- navegação, rolagem, Revendas e Adicionar Créditos ficam com o tamanho
  natural do painel.

LOGIN:
- se a sessão estiver expirada, a tela de login/configuração continua
  disponível;
- ao concluir o login e entrar no Dashboard, o painel passa automaticamente
  para tela cheia;
- verificação/CAPTCHA continua manual, sem contorno.

CORREÇÃO TÉCNICA DA REVENDA:
O WebView usado em segundo plano pode não ter dimensões visuais.
Por isso a caixa:
"Eu concordo em transferir 50 créditos"
agora é localizada pelo DOM e pelo texto exato, sem depender de
getBoundingClientRect() ou de o elemento estar visível na tela.

A caixa "Use casas decimais" continua sendo ignorada.

PRESERVADO:
- campo Créditos = 50;
- sem pedir CONFIRMAR;
- sem leitura de saldo;
- clique final único;
- link de suporte editável;
- correção contra mensagens duplicadas;
- testes em segundo plano.
