MASTER RESPONDE v1.3

BASE APROVADA:
- v1.0: dashboard
- v1.1.1: Bot liga/desliga + acesso às notificações
- v1.2.1: autoresposta fixa "teste bot"

ÚNICA função nova da v1.3:
- REGRAS CONFIGURÁVEIS DE TEXTO

O que é possível:
- abrir o módulo REGRAS;
- adicionar várias regras;
- cada regra possui:
  - palavra ou frase;
  - resposta automática;
  - correspondência CONTÉM ou EXATA;
- excluir regra;
- regras ficam salvas no celular.

Exemplo:
Gatilho:
bom dia

Resposta:
Olá! Como posso ajudar?

Se "exata" estiver desmarcado:
"bom dia amigo" também ativa.

Se "exata" estiver marcado:
somente "bom dia" ativa.

A regra fixa:
teste bot
continua funcionando.

AINDA NÃO EXISTE:
- regras de grupo
- @infor
- mídia
- MASTERFLIX
- revendas
- créditos
