# MASTER RESPONDE v1.0

Projeto Android nativo para autoresposta no **WhatsApp Business** com integração ao painel MASTERFLIX.

## O que já existe nesta v1.0

### Dashboard
- visual MASTER em preto/grafite, laranja e azul;
- status do Bot;
- status do WhatsApp Business / acesso às notificações;
- status/configuração do MASTERFLIX;
- atalhos;
- Regras, Mídias, Revendas, Grupos, Histórico e Configurações.

### WhatsApp Business
O app usa `NotificationListenerService` e `RemoteInput` do Android para responder mensagens de texto do pacote:

`com.whatsapp.w4b`

O usuário precisa liberar **Acesso às notificações** para o MASTER RESPONDE.

### Regras manuais
É possível cadastrar várias regras:
- palavra/frase;
- correspondência por “contém” ou exata;
- privado, grupo ou ambos;
- categoria que será enviada.

### Textos e mídias
Cada categoria aceita **várias respostas**, com ordem:

- Tutoriais
- Promoções e Planos
- Aplicativos Parceiros
- Banners
- Avisos
- Apresentação do Servidor

Cada resposta pode ser:
- Texto
- Foto
- Vídeo
- Áudio

Os arquivos são escolhidos manualmente pelo seletor de arquivos do Android.

**Importante sobre mídia:** o app tenta enviar anexos por `RemoteInput` somente quando a própria ação de resposta da notificação do WhatsApp Business anuncia suporte ao MIME correspondente. Texto é o caminho confiável. Se a notificação não aceitar mídia, a tentativa é registrada como não enviada no Histórico; não há automação de toques no WhatsApp nesta v1.0.

### Menu do grupo
Comando padrão:

`@infor`

Menu padrão:
1. Tutoriais
2. Promoções e Planos
3. Aplicativos Parceiros
4. Banners
5. Avisos
6. Apresentação do Servidor
7. Solicitar 50 Créditos
8. Gerar Teste
0. Suporte

Os textos são editáveis em **Configurações**.

### Teste automático
Teste padrão:

`MASTERFLIX TESTE COMPLETO 1H`

Fluxo:
1. recebe pedido de teste;
2. responde “Gerando seu teste...”;
3. inicia o conector MASTERFLIX;
4. reloga automaticamente pelo login normal se a sessão tiver expirado;
5. procura o teste padrão no dashboard;
6. abre “Detalhes do Cliente”;
7. usa o fluxo do botão **Copiar**;
8. captura/valida o conteúdo com Usuário, Senha e M3U;
9. devolve o conteúdo completo para o mesmo cliente.

Limite padrão: **1 teste a cada 24h por conversa/contato**, configurável.

### Nova revenda
Link padrão:
`https://masterflix.sigmab.pro/#/rs/en12xeNDPE/ryJDz2KDge`

Fluxo:
1. cliente envia “Quero ser Revenda”;
2. bot envia o link e pede o e-mail;
3. cliente envia o e-mail;
4. MASTER RESPONDE abre `#/resellers`;
5. pesquisa exatamente o e-mail;
6. lê saldo;
7. abre o botão de adicionar créditos;
8. adiciona **50 créditos**;
9. confirma o e-mail da conta;
10. depois da operação, verifica se o saldo aumentou exatamente 50;
11. vincula o contato ao e-mail da revenda.

### Solicitação de créditos
- valor fixo: **50 créditos**;
- painel pós-pago;
- sem etapa de pagamento;
- se a revenda já estiver vinculada, o bot pede `CONFIRMAR`;
- não repete automaticamente uma transferência cujo saldo final não pôde ser confirmado.

### MASTERFLIX
Painel:
`https://masterflix.sigmab.pro`

Login:
`#/sign-in`

Dashboard:
`#/dashboard`

Revendas:
`#/resellers`

O login do painel fica criptografado com `EncryptedSharedPreferences`.

O projeto **não tenta contornar CAPTCHA, desafio anti-bot ou verificação humana**. A reconexão automática utiliza somente o login normal da página.

## Limitações importantes da v1.0

1. O WhatsApp não fornece uma API pública local para autoresponder completo. Este projeto usa a resposta rápida das notificações Android.
2. A identificação de participantes de grupo vem dos metadados da notificação (nome/conversa), não do número telefônico em todos os aparelhos.
3. Mídia automática depende do suporte da ação `RemoteInput` oferecida pela versão do WhatsApp Business instalada.
4. O MASTERFLIX é um site externo. Alterações no HTML podem exigir ajustes nos seletores JavaScript.
5. A automação do painel usa um WebView em serviço foreground apenas enquanto existe tarefa na fila.

## Build no GitHub

O ZIP do projeto inclui `.github/workflows/build-apk.yml`.

Após enviar o projeto para o GitHub:
- Actions
- `Build MASTER RESPONDE APK`
- Run workflow
- baixar o artifact `MASTER-RESPONDE-APK`

O APK gerado será `MASTER-RESPONDE.apk`.
