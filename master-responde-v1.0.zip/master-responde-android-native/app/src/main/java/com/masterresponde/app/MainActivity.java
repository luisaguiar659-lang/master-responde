package com.masterresponde.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.app.NotificationManagerCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout content;
    private TextView botStatus;
    private TextView waStatus;
    private TextView panelStatus;
    private TextView queueStatus;
    private Switch botSwitch;

    private String pendingCategory;
    private String pendingType;
    private String pendingTitle;
    private int pendingOrder;

    private static final int PICK_MEDIA = 6001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ConfigStore.ensureDefaults(this);
        requestNotificationPermissionIfNeeded();
        buildShell();
        showDashboard();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(16), dp(12), dp(10), dp(10));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier(
                "logo_master_responde", "drawable", getPackageName()));
        top.addView(logo, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(10), 0, 0, 0);

        TextView title = text("MASTER RESPONDE", 20, Color.WHITE, true);
        TextView sub = text("WhatsApp Business • Automação", 11, Color.rgb(150, 160, 170), false);
        titleBox.addView(title);
        titleBox.addView(sub);
        top.addView(titleBox, new LinearLayout.LayoutParams(0, dp(58), 1f));

        Button home = smallButton("INÍCIO");
        home.setOnClickListener(v -> showDashboard());
        top.addView(home);

        root.addView(top);

        View glow = new View(this);
        glow.setBackgroundResource(getResources().getIdentifier(
                "bg_glow_line", "drawable", getPackageName()));
        root.addView(glow, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(38));
        scroll.addView(content);

        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void showDashboard() {
        content.removeAllViews();

        LinearLayout brand = card();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier(
                "logo_master_responde", "drawable", getPackageName()));
        row.addView(logo, new LinearLayout.LayoutParams(dp(74), dp(74)));

        LinearLayout btxt = new LinearLayout(this);
        btxt.setOrientation(LinearLayout.VERTICAL);
        btxt.setPadding(dp(12), 0, 0, 0);
        btxt.addView(text("MASTER RESPONDE", 22, Color.WHITE, true));
        btxt.addView(text("Central inteligente de atendimento", 13, Color.rgb(160,170,180), false));
        row.addView(btxt, new LinearLayout.LayoutParams(0, dp(80), 1f));

        botSwitch = new Switch(this);
        botSwitch.setChecked(ConfigStore.isBotEnabled(this));
        botSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            ConfigStore.setBotEnabled(this, isChecked);
            refreshStatus();
        });
        row.addView(botSwitch);

        brand.addView(row);
        content.addView(brand);

        gap(14);

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);

        botStatus = statusCard(grid, "Bot", "● Desativado", false, () -> {
            botSwitch.setChecked(!botSwitch.isChecked());
        });

        waStatus = statusCard(grid, "WhatsApp Business", "● Verificando", true, () -> {
            startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));
        });

        panelStatus = statusCard(grid, "MASTERFLIX", "● Não configurado", false, this::showSettings);
        queueStatus = statusCard(grid, "Fila", "0 aguardando", true, null);

        content.addView(grid);
        gap(18);

        section("ATALHOS");

        GridLayout quick = new GridLayout(this);
        quick.setColumnCount(2);
        quickButton(quick, "Gerar teste", true, this::manualTest);
        quickButton(quick, "Nova revenda", false, this::showResellers);
        quickButton(quick, "Créditos +50", true, this::manualCredit);
        quickButton(quick, "@infor grupos", false, this::previewGroupMenu);
        content.addView(quick);

        gap(18);
        section("MÓDULOS");

        GridLayout modules = new GridLayout(this);
        modules.setColumnCount(2);
        moduleButton(modules, "Regras", this::showRules);
        moduleButton(modules, "Mídias", this::showMedia);
        moduleButton(modules, "Revendas", this::showResellers);
        moduleButton(modules, "Grupos", this::showGroups);
        moduleButton(modules, "Histórico", this::showHistory);
        moduleButton(modules, "Configurações", this::showSettings);
        content.addView(modules);

        gap(18);
        TextView note = text(
                "Teste padrão: MASTERFLIX TESTE COMPLETO 1H\nCrédito automático: 50 créditos",
                12, Color.rgb(145,155,165), false);
        content.addView(note);

        refreshStatus();
    }

    private void refreshStatus() {
        if (botStatus != null) {
            boolean on = ConfigStore.isBotEnabled(this);
            botStatus.setText(on ? "● Ativo" : "● Desativado");
            botStatus.setTextColor(on ? Color.rgb(0,184,255) : Color.rgb(150,160,170));
        }

        if (waStatus != null) {
            boolean access = NotificationManagerCompat.getEnabledListenerPackages(this)
                    .contains(getPackageName());
            boolean installed = isPackageInstalled("com.whatsapp.w4b");
            String s = !installed ? "● Não instalado" : access ? "● Ativo" : "● Permissão necessária";
            waStatus.setText(s);
            waStatus.setTextColor(access && installed
                    ? Color.rgb(0,184,255)
                    : Color.rgb(255,150,0));
        }

        if (panelStatus != null) {
            boolean has = ConfigStore.hasPanelCredentials(this);
            boolean connected = ConfigStore.panelConnected(this);
            String s = connected ? "● Conectado" : has ? "● Configurado" : "● Não configurado";
            panelStatus.setText(s);
            panelStatus.setTextColor(connected
                    ? Color.rgb(255,150,0)
                    : has ? Color.rgb(0,184,255) : Color.rgb(150,160,170));
        }

        if (queueStatus != null) {
            queueStatus.setText("0 aguardando");
        }
    }

    private boolean isPackageInstalled(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void showRules() {
        content.removeAllViews();
        section("REGRAS");

        Button add = actionButton("+ ADICIONAR REGRA", true);
        add.setOnClickListener(v -> addRuleDialog());
        content.addView(add);
        gap(14);

        List<BotRule> rules = ConfigStore.rules(this);

        if (rules.isEmpty()) {
            content.addView(text(
                    "Nenhuma regra manual cadastrada.\n\nExemplo: palavra “planos” → categoria “Promoções e Planos”.",
                    14, Color.rgb(170,180,190), false));
            return;
        }

        for (BotRule r : rules) {
            LinearLayout c = card();
            c.addView(text(r.trigger, 17, Color.WHITE, true));
            c.addView(text(
                    r.category + " • " + r.target + (r.exact ? " • exata" : " • contém"),
                    12, Color.rgb(150,160,170), false));

            Button del = smallButton("EXCLUIR");
            del.setOnClickListener(v -> {
                ConfigStore.deleteRule(this, r.id);
                showRules();
            });
            c.addView(del);
            content.addView(c);
            gap(10);
        }
    }

    private void addRuleDialog() {
        LinearLayout box = dialogBox();

        EditText trigger = field("Palavra ou frase");
        box.addView(trigger);

        Spinner category = spinner(ConfigStore.CATEGORIES);
        box.addView(category);

        Spinner target = spinner(new String[]{"Ambos", "Privado", "Grupo"});
        box.addView(target);

        CheckBox exact = new CheckBox(this);
        exact.setText("Correspondência exata");
        exact.setTextColor(Color.WHITE);
        box.addView(exact);

        new AlertDialog.Builder(this)
                .setTitle("Nova regra")
                .setView(box)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("SALVAR", (d, w) -> {
                    String t = trigger.getText().toString().trim();
                    if (t.isEmpty()) return;

                    BotRule r = new BotRule();
                    r.trigger = t;
                    r.category = String.valueOf(category.getSelectedItem());
                    r.exact = exact.isChecked();

                    int pos = target.getSelectedItemPosition();
                    r.target = pos == 1
                            ? BotRule.TARGET_PRIVATE
                            : pos == 2 ? BotRule.TARGET_GROUP : BotRule.TARGET_BOTH;

                    ConfigStore.saveRule(this, r);
                    showRules();
                })
                .show();
    }

    private void showMedia() {
        content.removeAllViews();
        section("TEXTOS E MÍDIAS");

        TextView info = text(
                "Cada categoria aceita várias respostas. Você pode misturar texto, foto, vídeo e áudio.",
                13, Color.rgb(160,170,180), false);
        content.addView(info);
        gap(12);

        Button add = actionButton("+ ADICIONAR RESPOSTA", true);
        add.setOnClickListener(v -> addResponseDialog());
        content.addView(add);
        gap(16);

        List<ResponseItem> items = ConfigStore.responseItems(this);

        for (String cat : ConfigStore.CATEGORIES) {
            section(cat.toUpperCase(Locale.ROOT));
            boolean any = false;

            for (ResponseItem item : items) {
                if (!cat.equals(item.category)) continue;
                any = true;

                LinearLayout c = card();
                c.addView(text(item.title, 16, Color.WHITE, true));
                c.addView(text(
                        item.type + " • ordem " + item.order,
                        12, Color.rgb(150,160,170), false));

                if (ResponseItem.TYPE_TEXT.equals(item.type)) {
                    TextView body = text(item.value, 13, Color.rgb(205,210,215), false);
                    body.setMaxLines(4);
                    c.addView(body);
                }

                Button del = smallButton("EXCLUIR");
                del.setOnClickListener(v -> {
                    ConfigStore.deleteResponseItem(this, item.id);
                    showMedia();
                });
                c.addView(del);

                content.addView(c);
                gap(8);
            }

            if (!any) {
                content.addView(text(
                        "Nenhuma resposta cadastrada.",
                        12, Color.rgb(120,130,140), false));
            }
            gap(14);
        }
    }

    private void addResponseDialog() {
        LinearLayout box = dialogBox();

        EditText title = field("Nome da resposta");
        box.addView(title);

        Spinner category = spinner(ConfigStore.CATEGORIES);
        box.addView(category);

        Spinner type = spinner(new String[]{"Texto", "Foto", "Vídeo", "Áudio"});
        box.addView(type);

        EditText order = field("Ordem (ex.: 1)");
        order.setInputType(InputType.TYPE_CLASS_NUMBER);
        box.addView(order);

        EditText textValue = field("Texto da resposta");
        textValue.setMinLines(3);
        box.addView(textValue);

        type.setOnItemSelectedListener(new SimpleItemSelectedListener(pos -> {
            textValue.setVisibility(pos == 0 ? View.VISIBLE : View.GONE);
        }));

        new AlertDialog.Builder(this)
                .setTitle("Adicionar resposta")
                .setView(box)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("CONTINUAR", (d, w) -> {
                    String ttl = title.getText().toString().trim();
                    if (ttl.isEmpty()) ttl = "Resposta";

                    pendingCategory = String.valueOf(category.getSelectedItem());
                    pendingTitle = ttl;
                    try {
                        pendingOrder = Integer.parseInt(order.getText().toString().trim());
                    } catch (Exception e) {
                        pendingOrder = ConfigStore.responseItems(this).size() + 1;
                    }

                    int pos = type.getSelectedItemPosition();

                    if (pos == 0) {
                        ResponseItem i = new ResponseItem();
                        i.category = pendingCategory;
                        i.title = pendingTitle;
                        i.type = ResponseItem.TYPE_TEXT;
                        i.value = textValue.getText().toString();
                        i.order = pendingOrder;
                        i.enabled = true;
                        ConfigStore.saveResponseItem(this, i);
                        showMedia();
                        return;
                    }

                    pendingType = pos == 1
                            ? ResponseItem.TYPE_IMAGE
                            : pos == 2 ? ResponseItem.TYPE_VIDEO : ResponseItem.TYPE_AUDIO;

                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType(pos == 1 ? "image/*" : pos == 2 ? "video/*" : "audio/*");
                    startActivityForResult(pick, PICK_MEDIA);
                })
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_MEDIA
                && resultCode == RESULT_OK
                && data != null
                && data.getData() != null) {

            Uri uri = data.getData();

            try {
                getContentResolver().takePersistableUriPermission(
                        uri,
                        data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (Exception ignored) {}

            ResponseItem i = new ResponseItem();
            i.category = pendingCategory;
            i.type = pendingType;
            i.title = pendingTitle;
            i.value = uri.toString();
            i.order = pendingOrder;
            i.enabled = true;
            ConfigStore.saveResponseItem(this, i);
            showMedia();
        }
    }

    private void showResellers() {
        content.removeAllViews();
        section("REVENDAS");

        content.addView(text(
                "Fluxo automático:\n\n" +
                "• “Quero ser Revenda” → envia o link de cadastro.\n" +
                "• Aguarda o e-mail do cliente.\n" +
                "• Pesquisa a revenda no MASTERFLIX.\n" +
                "• Adiciona 50 créditos.\n" +
                "• Confere o saldo e vincula o contato ao e-mail.\n\n" +
                "Revendas já vinculadas podem solicitar +50 créditos pelo @infor.",
                14, Color.rgb(205,210,215), false));

        gap(16);
        Button manual = actionButton("ADICIONAR 50 CRÉDITOS MANUALMENTE", true);
        manual.setOnClickListener(v -> manualCredit());
        content.addView(manual);
    }

    private void showGroups() {
        content.removeAllViews();
        section("GRUPOS");

        content.addView(text(
                "Comando principal: " + ConfigStore.get(this, "group_command", "@infor"),
                15, Color.WHITE, true));
        gap(10);

        LinearLayout c = card();
        c.addView(text(
                ConfigStore.get(this, "txt_group_menu", ""),
                14, Color.rgb(220,225,230), false));
        content.addView(c);

        gap(12);
        content.addView(text(
                "O bot só abre o menu do grupo quando recebe o comando configurado. " +
                "As opções 1 a 6 enviam todas as respostas ativas da categoria na ordem cadastrada.",
                12, Color.rgb(150,160,170), false));
    }

    private void showHistory() {
        content.removeAllViews();
        section("HISTÓRICO");

        Button clear = smallButton("LIMPAR");
        clear.setOnClickListener(v -> {
            ConfigStore.clearHistory(this);
            showHistory();
        });
        content.addView(clear);
        gap(10);

        JSONArray h = ConfigStore.history(this);

        if (h.length() == 0) {
            content.addView(text("Nenhuma atividade registrada.", 14, Color.rgb(150,160,170), false));
            return;
        }

        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM HH:mm", Locale.getDefault());

        for (int i = h.length() - 1; i >= 0 && i >= h.length() - 60; i--) {
            JSONObject o = h.optJSONObject(i);
            if (o == null) continue;

            LinearLayout c = card();
            boolean ok = o.optBoolean("ok");
            c.addView(text(
                    (ok ? "✓ " : "! ") + o.optString("type"),
                    15, ok ? Color.rgb(0,184,255) : Color.rgb(255,100,100), true));

            c.addView(text(
                    fmt.format(new Date(o.optLong("ts"))) +
                            " • " + o.optString("contact") +
                            "\n" + o.optString("detail"),
                    12, Color.rgb(170,180,190), false));

            content.addView(c);
            gap(8);
        }
    }

    private void showSettings() {
        content.removeAllViews();
        section("CONFIGURAÇÕES");

        LinearLayout panelCard = card();
        panelCard.addView(text("MASTERFLIX", 17, Color.WHITE, true));

        EditText user = field("Usuário ou e-mail do painel");
        user.setText(ConfigStore.panelUser(this));
        panelCard.addView(user);

        EditText pass = field("Senha do painel");
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setText(ConfigStore.panelPassword(this));
        panelCard.addView(pass);

        Button savePanel = actionButton("SALVAR LOGIN MASTERFLIX", true);
        savePanel.setOnClickListener(v -> {
            ConfigStore.setPanelCredentials(
                    this,
                    user.getText().toString(),
                    pass.getText().toString()
            );
            toast("Login do MASTERFLIX salvo.");
            refreshStatus();
        });
        panelCard.addView(savePanel);

        content.addView(panelCard);
        gap(12);

        settingsText("Comando dos grupos", "group_command", "@infor");
        settingsText("Palavras para gerar teste", "test_triggers",
                "teste,quero um teste,teste grátis");
        settingsText("Palavras para nova revenda", "reseller_triggers",
                "quero ser revenda");

        settingsNumber("Limite de teste por número (horas)", "test_limit_hours", 24);

        settingsTextArea("Mensagem: gerando teste", "txt_test_wait");
        settingsTextArea("Mensagem: limite de teste", "txt_test_limit");
        settingsTextArea("Mensagem: nova revenda + link", "txt_reseller_invite");
        settingsTextArea("Mensagem: pedir e-mail", "txt_ask_email");
        settingsTextArea("Mensagem: confirmar 50 créditos", "txt_credit_confirm");
        settingsTextArea("Mensagem: créditos adicionados", "txt_credit_success");
        settingsTextArea("Mensagem: revenda ativada", "txt_reseller_success");
        settingsTextArea("Mensagem: erro do painel", "txt_panel_error");
        settingsTextArea("Mensagem: suporte", "txt_support");
        settingsTextArea("Menu @infor", "txt_group_menu");

        gap(12);

        Button notif = actionButton("LIBERAR ACESSO ÀS NOTIFICAÇÕES", false);
        notif.setOnClickListener(v ->
                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")));
        content.addView(notif);

        gap(10);

        TextView security = text(
                "O MASTER RESPONDE não tenta contornar CAPTCHA ou verificação anti-bot. " +
                "O relogin automático usa somente os campos normais do painel.",
                12, Color.rgb(145,155,165), false);
        content.addView(security);
    }

    private void settingsText(String label, String key, String def) {
        LinearLayout c = card();
        c.addView(text(label, 13, Color.rgb(255,155,0), true));
        EditText e = field(label);
        e.setText(ConfigStore.get(this, key, def));
        c.addView(e);
        Button save = smallButton("SALVAR");
        save.setOnClickListener(v -> {
            ConfigStore.put(this, key, e.getText().toString());
            toast("Salvo.");
        });
        c.addView(save);
        content.addView(c);
        gap(8);
    }

    private void settingsTextArea(String label, String key) {
        LinearLayout c = card();
        c.addView(text(label, 13, Color.rgb(255,155,0), true));
        EditText e = field(label);
        e.setMinLines(3);
        e.setGravity(Gravity.TOP);
        e.setText(ConfigStore.get(this, key, ""));
        c.addView(e);
        Button save = smallButton("SALVAR");
        save.setOnClickListener(v -> {
            ConfigStore.put(this, key, e.getText().toString());
            toast("Salvo.");
        });
        c.addView(save);
        content.addView(c);
        gap(8);
    }

    private void settingsNumber(String label, String key, int def) {
        LinearLayout c = card();
        c.addView(text(label, 13, Color.rgb(255,155,0), true));
        EditText e = field(label);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(String.valueOf(ConfigStore.getInt(this, key, def)));
        c.addView(e);
        Button save = smallButton("SALVAR");
        save.setOnClickListener(v -> {
            try {
                ConfigStore.putInt(this, key,
                        Integer.parseInt(e.getText().toString().trim()));
                toast("Salvo.");
            } catch (Exception ex) {
                toast("Informe um número válido.");
            }
        });
        c.addView(save);
        content.addView(c);
        gap(8);
    }

    private void manualTest() {
        if (!ConfigStore.hasPanelCredentials(this)) {
            toast("Configure o login do MASTERFLIX primeiro.");
            showSettings();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("Teste do MASTERFLIX")
                .setMessage("Gerar um MASTERFLIX TESTE COMPLETO 1H para diagnóstico?\n\n" +
                        "O resultado será registrado no Histórico e não será enviado ao WhatsApp.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("GERAR", (d, w) -> {
                    BotRuntime.startPanelTask(
                            this, "TEST", "manual", "manual",
                            "", null, false);
                    toast("Teste colocado na fila.");
                })
                .show();
    }

    private void manualCredit() {
        if (!ConfigStore.hasPanelCredentials(this)) {
            toast("Configure o login do MASTERFLIX primeiro.");
            showSettings();
            return;
        }

        EditText email = field("E-mail exato da revenda");

        new AlertDialog.Builder(this)
                .setTitle("Adicionar 50 créditos")
                .setMessage("O valor é fixo em 50 créditos.")
                .setView(email)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("CONTINUAR", (d, w) -> {
                    String e = email.getText().toString().trim();
                    if (e.isEmpty()) return;

                    BotRuntime.startPanelTask(
                            this, "CREDIT", "manual|" + e, e,
                            e, null, false);
                    toast("Operação colocada na fila.");
                })
                .show();
    }

    private void previewGroupMenu() {
        new AlertDialog.Builder(this)
                .setTitle("@infor")
                .setMessage(ConfigStore.get(this, "txt_group_menu", ""))
                .setPositiveButton("FECHAR", null)
                .show();
    }

    private TextView statusCard(
            GridLayout parent,
            String title,
            String value,
            boolean blue,
            Runnable click
    ) {
        LinearLayout c = card();
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(100);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(4), dp(4), dp(4), dp(4));
        c.setLayoutParams(gp);

        c.addView(text(title, 12, Color.rgb(150,160,170), false));
        TextView status = text(
                value, 17,
                blue ? Color.rgb(0,184,255) : Color.rgb(255,150,0),
                true);
        status.setPadding(0, dp(10), 0, 0);
        c.addView(status);

        if (click != null) c.setOnClickListener(v -> click.run());

        parent.addView(c);
        return status;
    }

    private void quickButton(GridLayout parent, String label, boolean orange, Runnable action) {
        Button b = actionButton(label, orange);
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(58);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(gp);
        b.setOnClickListener(v -> action.run());
        parent.addView(b);
    }

    private void moduleButton(GridLayout parent, String label, Runnable action) {
        Button b = actionButton(label, false);
        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = dp(56);
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(gp);
        b.setOnClickListener(v -> action.run());
        parent.addView(b);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(14), dp(14), dp(14), dp(14));
        c.setBackgroundResource(getResources().getIdentifier(
                "bg_card", "drawable", getPackageName()));
        return c;
    }

    private LinearLayout dialogBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(8));
        return box;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Color.rgb(120,130,140));
        e.setTextColor(Color.WHITE);
        e.setTextSize(14);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackgroundResource(getResources().getIdentifier(
                "bg_input", "drawable", getPackageName()));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(5), 0, dp(8));
        e.setLayoutParams(lp);
        return e;
    }

    private Spinner spinner(String[] values) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                values);
        s.setAdapter(a);
        s.setBackgroundResource(getResources().getIdentifier(
                "bg_input", "drawable", getPackageName()));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.setMargins(0, dp(5), 0, dp(8));
        s.setLayoutParams(lp);
        return s;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private void section(String title) {
        TextView t = text(title, 12, Color.rgb(255,155,0), true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, 0, 0, dp(8));
        content.addView(t);
    }

    private Button actionButton(String label, boolean orange) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(null, 1);
        b.setBackgroundResource(getResources().getIdentifier(
                orange ? "bg_button_orange" : "bg_button_dark",
                "drawable",
                getPackageName()));
        return b;
    }

    private Button smallButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(10);
        b.setTextColor(Color.WHITE);
        b.setBackgroundResource(getResources().getIdentifier(
                "bg_button_dark", "drawable", getPackageName()));
        return b;
    }

    private void gap(int dp) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(1, dp(dp)));
        content.addView(v);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    71
            );
        }
    }

    private interface PositionListener {
        void onPosition(int position);
    }

    private static class SimpleItemSelectedListener
            implements android.widget.AdapterView.OnItemSelectedListener {

        private final PositionListener listener;

        SimpleItemSelectedListener(PositionListener listener) {
            this.listener = listener;
        }

        @Override
        public void onItemSelected(
                android.widget.AdapterView<?> parent,
                View view,
                int position,
                long id
        ) {
            listener.onPosition(position);
        }

        @Override
        public void onNothingSelected(android.widget.AdapterView<?> parent) {}
    }
}
