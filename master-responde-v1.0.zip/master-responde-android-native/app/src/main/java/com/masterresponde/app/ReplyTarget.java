package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ReplyTarget {
    public final Notification.Action action;
    public final RemoteInput remoteInput;

    public ReplyTarget(Notification.Action action, RemoteInput remoteInput) {
        this.action = action;
        this.remoteInput = remoteInput;
    }

    public boolean sendText(Context context, String text) {
        try {
            Intent intent = new Intent();
            Bundle bundle = new Bundle();
            bundle.putCharSequence(remoteInput.getResultKey(), text);
            RemoteInput.addResultsToIntent(new RemoteInput[]{remoteInput}, intent, bundle);
            action.actionIntent.send(context, 0, intent);
            return true;
        } catch (PendingIntent.CanceledException e) {
            return false;
        }
    }

    public boolean sendMedia(Context context, Uri uri, String mime) {
        if (android.os.Build.VERSION.SDK_INT < 26) return false;
        try {
            Set<String> allowed = remoteInput.getAllowedDataTypes();
            if (allowed == null || allowed.isEmpty()) return false;

            boolean accepts = allowed.contains(mime)
                    || (mime != null && mime.startsWith("image/") && allowed.contains("image/*"))
                    || (mime != null && mime.startsWith("video/") && allowed.contains("video/*"))
                    || (mime != null && mime.startsWith("audio/") && allowed.contains("audio/*"));

            if (!accepts) return false;

            Intent intent = new Intent();
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            Map<String, Uri> data = new HashMap<>();
            data.put(mime, uri);
            RemoteInput.addDataResultToIntent(remoteInput, intent, data);
            action.actionIntent.send(context, 0, intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
