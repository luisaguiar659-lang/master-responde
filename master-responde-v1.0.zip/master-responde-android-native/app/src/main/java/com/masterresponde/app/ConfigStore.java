package com.masterresponde.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class ConfigStore {
    public static final String CAT_TUTORIALS = "Tutoriais";
    public static final String CAT_PLANS = "Promoções e Planos";
    public static final String CAT_PARTNERS = "Aplicativos Parceiros";
    public static final String CAT_BANNERS = "Banners";
    public static final String CAT_ALERTS = "Avisos";
    public static final String CAT_PRESENTATION = "Apresentação do Servidor";

    public static final String[] CATEGORIES = new String[]{
            CAT_TUTORIALS,
            CAT_PLANS,
            CAT_PARTNERS,
            CAT_BANNERS,
            CAT_ALERTS,
            CAT_PRESENTATION
    };

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("master_responde", Context.MODE_PRIVATE);
    }

    private static SharedPreferences secure(Context c) {
        try {
            MasterKey key = new MasterKey.Builder(c)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            return EncryptedSharedPreferences.create(
                    c,
                    "master_responde_secure",
                    key,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        } catch (Exception e) {
            return c.getSharedPreferences("master_responde_secure_fallback", Context.MODE_PRIVATE);
        }
    }

    public static void ensureDefaults(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getBoolean("defaults_created", false)) return;

        p.edit()
                .putBoolean("defaults_created", true)
                .putBoolean("bot_enabled", false)
                .putString("group_command", "@infor")
                .putString("test_triggers", "teste,quero um teste,teste grátis,me libera um teste")
                .putString("reseller_triggers", "quero ser revenda,quero ser uma revenda")
                .putInt("test_limit_hours", 24)
                .putString("txt_test_wait", "Gerando seu teste, aguarde...")
                .putString("txt_test_limit", "Você já recebeu um teste recentemente. Tente novamente mais tarde.")
                .putString("txt_reseller_invite",
                        "Faça seu cadastro de revenda neste link:\n" +
                        "https://masterflix.sigmab.pro/#/rs/en12xeNDPE/ryJDz2KDge\n\n" +
                        "Após concluir, envie aqui o mesmo e-mail utilizado no cadastro.")
                .putString("txt_ask_email", "Envie o e-mail cadastrado na sua revenda.")
                .putString("txt_credit_confirm",
                        "Serão adicionados 50 créditos à sua revenda. Digite CONFIRMAR para continuar.")
                .putString("txt_credit_success", "✅ Foram adicionados 50 créditos à sua revenda.")
                .putString("txt_reseller_success",
                        "✅ Cadastro localizado. Sua revenda recebeu os 50 créditos iniciais.")
                .putString("txt_panel_error",
                        "Não consegui concluir a operação agora. A solicitação ficou registrada para conferência.")
                .putString("txt_support", "Um atendente continuará seu atendimento.")
                .putString("txt_group_menu",
                        "🤖 *MASTER RESPONDE — CENTRAL DE SUPORTE*\n\n" +
                        "1️⃣ Tutoriais\n" +
                        "2️⃣ Promoções e Planos\n" +
                        "3️⃣ Aplicativos Parceiros\n" +
                        "4️⃣ Banners\n" +
                        "5️⃣ Avisos\n" +
                        "6️⃣ Apresentação do Servidor\n" +
                        "7️⃣ Solicitar 50 Créditos\n" +
                        "8️⃣ Gerar Teste\n" +
                        "0️⃣ Suporte")
                .apply();
    }

    public static boolean isBotEnabled(Context c) {
        return prefs(c).getBoolean("bot_enabled", false);
    }

    public static void setBotEnabled(Context c, boolean enabled) {
        prefs(c).edit().putBoolean("bot_enabled", enabled).apply();
    }

    public static String get(Context c, String key, String def) {
        return prefs(c).getString(key, def);
    }

    public static void put(Context c, String key, String value) {
        prefs(c).edit().putString(key, value).apply();
    }

    public static int getInt(Context c, String key, int def) {
        return prefs(c).getInt(key, def);
    }

    public static void putInt(Context c, String key, int value) {
        prefs(c).edit().putInt(key, value).apply();
    }

    public static void setPanelCredentials(Context c, String user, String password) {
        secure(c).edit()
                .putString("panel_user", user == null ? "" : user.trim())
                .putString("panel_password", password == null ? "" : password)
                .apply();
        prefs(c).edit().putBoolean("panel_connected", false).apply();
    }

    public static String panelUser(Context c) {
        return secure(c).getString("panel_user", "");
    }

    public static String panelPassword(Context c) {
        return secure(c).getString("panel_password", "");
    }

    public static boolean hasPanelCredentials(Context c) {
        return !panelUser(c).isEmpty() && !panelPassword(c).isEmpty();
    }

    public static void setPanelConnected(Context c, boolean value) {
        prefs(c).edit()
                .putBoolean("panel_connected", value)
                .putLong("panel_last_ok", value ? System.currentTimeMillis() : 0L)
                .apply();
    }

    public static boolean panelConnected(Context c) {
        return prefs(c).getBoolean("panel_connected", false);
    }

    public static List<ResponseItem> responseItems(Context c) {
        List<ResponseItem> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("response_items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) out.add(ResponseItem.fromJson(o));
            }
        } catch (Exception ignored) {}
        Collections.sort(out, Comparator.comparingInt(i -> i.order));
        return out;
    }

    public static List<ResponseItem> responseItems(Context c, String category) {
        List<ResponseItem> out = new ArrayList<>();
        for (ResponseItem i : responseItems(c)) {
            if (i.enabled && category.equals(i.category)) out.add(i);
        }
        return out;
    }

    public static void saveResponseItem(Context c, ResponseItem item) {
        List<ResponseItem> items = responseItems(c);
        if (item.id == null || item.id.isEmpty()) item.id = UUID.randomUUID().toString();

        boolean replaced = false;
        for (int i = 0; i < items.size(); i++) {
            if (item.id.equals(items.get(i).id)) {
                items.set(i, item);
                replaced = true;
                break;
            }
        }
        if (!replaced) items.add(item);

        JSONArray a = new JSONArray();
        for (ResponseItem i : items) a.put(i.toJson());
        prefs(c).edit().putString("response_items", a.toString()).apply();
    }

    public static void deleteResponseItem(Context c, String id) {
        JSONArray a = new JSONArray();
        for (ResponseItem i : responseItems(c)) {
            if (!id.equals(i.id)) a.put(i.toJson());
        }
        prefs(c).edit().putString("response_items", a.toString()).apply();
    }

    public static List<BotRule> rules(Context c) {
        List<BotRule> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("rules", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.optJSONObject(i);
                if (o != null) out.add(BotRule.fromJson(o));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void saveRule(Context c, BotRule rule) {
        List<BotRule> rules = rules(c);
        if (rule.id == null || rule.id.isEmpty()) rule.id = UUID.randomUUID().toString();

        boolean replaced = false;
        for (int i = 0; i < rules.size(); i++) {
            if (rule.id.equals(rules.get(i).id)) {
                rules.set(i, rule);
                replaced = true;
                break;
            }
        }
        if (!replaced) rules.add(rule);

        JSONArray a = new JSONArray();
        for (BotRule r : rules) a.put(r.toJson());
        prefs(c).edit().putString("rules", a.toString()).apply();
    }

    public static void deleteRule(Context c, String id) {
        JSONArray a = new JSONArray();
        for (BotRule r : rules(c)) {
            if (!id.equals(r.id)) a.put(r.toJson());
        }
        prefs(c).edit().putString("rules", a.toString()).apply();
    }

    public static void addHistory(Context c, String type, String contact, String detail, boolean ok) {
        try {
            JSONArray current = new JSONArray(prefs(c).getString("history", "[]"));
            JSONObject o = new JSONObject();
            o.put("ts", System.currentTimeMillis());
            o.put("type", type);
            o.put("contact", contact == null ? "" : contact);
            o.put("detail", detail == null ? "" : detail);
            o.put("ok", ok);
            current.put(o);

            JSONArray trim = new JSONArray();
            int start = Math.max(0, current.length() - 200);
            for (int i = start; i < current.length(); i++) trim.put(current.get(i));
            prefs(c).edit().putString("history", trim.toString()).apply();
        } catch (Exception ignored) {}
    }

    public static JSONArray history(Context c) {
        try {
            return new JSONArray(prefs(c).getString("history", "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static void clearHistory(Context c) {
        prefs(c).edit().remove("history").apply();
    }

    public static void setState(Context c, String contactKey, String state) {
        prefs(c).edit().putString("state_" + safeKey(contactKey), state).apply();
    }

    public static String state(Context c, String contactKey) {
        return prefs(c).getString("state_" + safeKey(contactKey), "");
    }

    public static void clearState(Context c, String contactKey) {
        prefs(c).edit().remove("state_" + safeKey(contactKey)).apply();
    }

    public static void linkReseller(Context c, String contactKey, String email) {
        prefs(c).edit().putString("reseller_" + safeKey(contactKey), email.toLowerCase(Locale.ROOT)).apply();
    }

    public static String linkedReseller(Context c, String contactKey) {
        return prefs(c).getString("reseller_" + safeKey(contactKey), "");
    }

    public static void setLastTest(Context c, String contactKey, long ts) {
        prefs(c).edit().putLong("last_test_" + safeKey(contactKey), ts).apply();
    }

    public static long lastTest(Context c, String contactKey) {
        return prefs(c).getLong("last_test_" + safeKey(contactKey), 0L);
    }

    private static String safeKey(String value) {
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] b = d.digest((value == null ? "" : value).getBytes(StandardCharsets.UTF_8));
            return Base64.encodeToString(b, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        } catch (Exception e) {
            return Integer.toHexString((value == null ? "" : value).hashCode());
        }
    }
}
