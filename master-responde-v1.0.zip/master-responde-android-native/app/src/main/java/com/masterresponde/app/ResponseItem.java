package com.masterresponde.app;

import org.json.JSONObject;

public class ResponseItem {
    public static final String TYPE_TEXT = "TEXT";
    public static final String TYPE_IMAGE = "IMAGE";
    public static final String TYPE_VIDEO = "VIDEO";
    public static final String TYPE_AUDIO = "AUDIO";

    public String id;
    public String category;
    public String type;
    public String title;
    public String value;
    public boolean enabled;
    public int order;

    public ResponseItem() {}

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("category", category);
            o.put("type", type);
            o.put("title", title);
            o.put("value", value);
            o.put("enabled", enabled);
            o.put("order", order);
        } catch (Exception ignored) {}
        return o;
    }

    public static ResponseItem fromJson(JSONObject o) {
        ResponseItem i = new ResponseItem();
        i.id = o.optString("id");
        i.category = o.optString("category");
        i.type = o.optString("type", TYPE_TEXT);
        i.title = o.optString("title");
        i.value = o.optString("value");
        i.enabled = o.optBoolean("enabled", true);
        i.order = o.optInt("order", 0);
        return i;
    }
}
