package com.masterresponde.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;
import java.util.Map;

public class NotificationReplyService extends NotificationListenerService {
    private static final String WA_BUSINESS = "com.whatsapp.w4b";
    private final Map<String, Long> seen = new HashMap<>();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !WA_BUSINESS.equals(sbn.getPackageName())) return;

        Notification n = sbn.getNotification();
        if (n == null) return;

        ReplyTarget target = findReplyTarget(n);
        if (target == null) return;

        MessageData data = extractMessage(n);
        if (data == null || data.text == null || data.text.trim().isEmpty()) return;

        String dedupe = sbn.getKey() + "|" + data.sender + "|" + data.text;
        long now = System.currentTimeMillis();
        Long old = seen.get(dedupe);
        if (old != null && now - old < 5000L) return;
        seen.put(dedupe, now);

        if (seen.size() > 300) seen.clear();

        BotEngine.Incoming in = new BotEngine.Incoming();
        in.text = data.text;
        in.group = data.group;
        in.contactLabel = data.group
                ? data.conversation + " • " + data.sender
                : data.conversation;
        in.contactKey = data.group
                ? "G|" + data.conversation + "|" + data.sender
                : "P|" + data.conversation;
        in.replyTarget = target;

        BotEngine.handle(getApplicationContext(), in);
    }

    private ReplyTarget findReplyTarget(Notification n) {
        if (n.actions == null) return null;

        for (Notification.Action action : n.actions) {
            if (action == null) continue;
            RemoteInput[] inputs = action.getRemoteInputs();
            if (inputs == null || inputs.length == 0) continue;

            for (RemoteInput input : inputs) {
                if (input.getAllowFreeFormInput()) {
                    return new ReplyTarget(action, input);
                }
            }
        }

        return null;
    }

    private MessageData extractMessage(Notification n) {
        Bundle e = n.extras;
        if (e == null) return null;

        MessageData d = new MessageData();
        d.group = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false);

        CharSequence conv = e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
        CharSequence title = e.getCharSequence(Notification.EXTRA_TITLE);
        d.conversation = conv != null ? conv.toString() : (title != null ? title.toString() : "WhatsApp");

        android.os.Parcelable[] bundles = e.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (bundles != null && bundles.length > 0) {
            try {
                Bundle last = (Bundle) bundles[bundles.length - 1];
                Notification.MessagingStyle.Message m =
                        Notification.MessagingStyle.Message.getMessageFromBundle(last);

                if (m != null) {
                    CharSequence text = m.getText();
                    d.text = text == null ? "" : text.toString();

                    if (android.os.Build.VERSION.SDK_INT >= 28 && m.getSenderPerson() != null) {
                        CharSequence name = m.getSenderPerson().getName();
                        d.sender = name == null ? d.conversation : name.toString();
                    } else {
                        CharSequence sender = m.getSender();
                        d.sender = sender == null ? d.conversation : sender.toString();
                    }

                    return d;
                }
            } catch (Exception ignored) {}
        }

        CharSequence text = e.getCharSequence(Notification.EXTRA_TEXT);
        d.text = text == null ? "" : text.toString();
        d.sender = d.group && title != null ? title.toString() : d.conversation;
        return d;
    }

    private static class MessageData {
        String text;
        String sender;
        String conversation;
        boolean group;
    }
}
