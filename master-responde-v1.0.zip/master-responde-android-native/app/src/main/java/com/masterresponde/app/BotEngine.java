package com.masterresponde.app;

import android.content.Context;

import java.util.List;
import java.util.Locale;

public final class BotEngine {
    public static class Incoming {
        public String text;
        public String contactKey;
        public String contactLabel;
        public boolean group;
        public ReplyTarget replyTarget;
    }

    private static final String STATE_GROUP_MENU = "GROUP_MENU";
    private static final String STATE_WAIT_RESELLER_EMAIL = "WAIT_RESELLER_EMAIL";
    private static final String STATE_WAIT_CREDIT_EMAIL = "WAIT_CREDIT_EMAIL";
    private static final String STATE_WAIT_CREDIT_CONFIRM = "WAIT_CREDIT_CONFIRM";

    public static void handle(Context c, Incoming in) {
        if (in == null || in.text == null || in.replyTarget == null) return;
        ConfigStore.ensureDefaults(c);
        if (!ConfigStore.isBotEnabled(c)) return;

        BotRuntime.rememberReplyTarget(in.contactKey, in.replyTarget);

        String raw = in.text.trim();
        String msg = norm(raw);
        if (msg.isEmpty()) return;

        String state = ConfigStore.state(c, in.contactKey);

        if (STATE_WAIT_RESELLER_EMAIL.equals(state)) {
            if (isEmail(raw)) {
                in.replyTarget.sendText(c, "Localizando seu cadastro, aguarde...");
                ConfigStore.clearState(c, in.contactKey);
                BotRuntime.startPanelTask(
                        c, "CREDIT", in.contactKey, in.contactLabel,
                        raw.trim().toLowerCase(Locale.ROOT),
                        in.replyTarget, true
                );
            } else {
                in.replyTarget.sendText(c,
                        ConfigStore.get(c, "txt_ask_email", "Envie o e-mail cadastrado."));
            }
            return;
        }

        if (STATE_WAIT_CREDIT_EMAIL.equals(state)) {
            if (isEmail(raw)) {
                ConfigStore.linkReseller(c, in.contactKey, raw.trim().toLowerCase(Locale.ROOT));
                ConfigStore.setState(c, in.contactKey, STATE_WAIT_CREDIT_CONFIRM);
                in.replyTarget.sendText(c,
                        ConfigStore.get(c, "txt_credit_confirm",
                                "Digite CONFIRMAR para receber 50 créditos."));
            } else {
                in.replyTarget.sendText(c,
                        ConfigStore.get(c, "txt_ask_email", "Envie o e-mail cadastrado."));
            }
            return;
        }

        if (STATE_WAIT_CREDIT_CONFIRM.equals(state)) {
            if ("confirmar".equals(msg)) {
                String email = ConfigStore.linkedReseller(c, in.contactKey);
                if (email.isEmpty()) {
                    ConfigStore.setState(c, in.contactKey, STATE_WAIT_CREDIT_EMAIL);
                    in.replyTarget.sendText(c,
                            ConfigStore.get(c, "txt_ask_email", "Envie o e-mail cadastrado."));
                } else {
                    ConfigStore.clearState(c, in.contactKey);
                    in.replyTarget.sendText(c, "Adicionando 50 créditos, aguarde...");
                    BotRuntime.startPanelTask(
                            c, "CREDIT", in.contactKey, in.contactLabel,
                            email, in.replyTarget, false
                    );
                }
            }
            return;
        }

        if (in.group) {
            String command = norm(ConfigStore.get(c, "group_command", "@infor"));
            if (msg.startsWith(command)) {
                String rest = msg.substring(command.length()).trim();

                if (rest.isEmpty()) {
                    ConfigStore.setState(c, in.contactKey, STATE_GROUP_MENU);
                    in.replyTarget.sendText(c,
                            ConfigStore.get(c, "txt_group_menu", "MASTER RESPONDE"));
                    return;
                }

                if (rest.contains("credito")) {
                    beginCredits(c, in);
                    return;
                }
                if (rest.contains("teste")) {
                    beginTest(c, in);
                    return;
                }
                if (rest.contains("tutorial")) {
                    BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_TUTORIALS);
                    return;
                }
                if (rest.contains("plano") || rest.contains("promoc")) {
                    BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_PLANS);
                    return;
                }
                if (rest.contains("app")) {
                    BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_PARTNERS);
                    return;
                }
                if (rest.contains("banner")) {
                    BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_BANNERS);
                    return;
                }
                if (rest.contains("aviso")) {
                    BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_ALERTS);
                    return;
                }
                if (rest.contains("apresent")) {
                    BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_PRESENTATION);
                    return;
                }
            }

            if (STATE_GROUP_MENU.equals(state)) {
                ConfigStore.clearState(c, in.contactKey);
                switch (msg) {
                    case "1":
                        BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_TUTORIALS);
                        return;
                    case "2":
                        BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_PLANS);
                        return;
                    case "3":
                        BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_PARTNERS);
                        return;
                    case "4":
                        BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_BANNERS);
                        return;
                    case "5":
                        BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_ALERTS);
                        return;
                    case "6":
                        BotRuntime.sendCategory(c, in.contactKey, ConfigStore.CAT_PRESENTATION);
                        return;
                    case "7":
                        beginCredits(c, in);
                        return;
                    case "8":
                        beginTest(c, in);
                        return;
                    case "0":
                        in.replyTarget.sendText(c,
                                ConfigStore.get(c, "txt_support", "Um atendente continuará."));
                        return;
                }
            }
        }

        if (matchesAny(msg, ConfigStore.get(c, "test_triggers", ""))) {
            beginTest(c, in);
            return;
        }

        if (matchesAny(msg, ConfigStore.get(c, "reseller_triggers", ""))) {
            in.replyTarget.sendText(c,
                    ConfigStore.get(c, "txt_reseller_invite",
                            "Faça seu cadastro e envie o e-mail utilizado."));
            ConfigStore.setState(c, in.contactKey, STATE_WAIT_RESELLER_EMAIL);
            return;
        }

        List<BotRule> rules = ConfigStore.rules(c);
        for (BotRule r : rules) {
            if (!r.enabled) continue;

            if (in.group && BotRule.TARGET_PRIVATE.equals(r.target)) continue;
            if (!in.group && BotRule.TARGET_GROUP.equals(r.target)) continue;

            String trigger = norm(r.trigger);
            boolean hit = r.exact ? msg.equals(trigger) : msg.contains(trigger);

            if (hit) {
                BotRuntime.sendCategory(c, in.contactKey, r.category);
                ConfigStore.addHistory(c, "REGRA", in.contactLabel, r.trigger, true);
                return;
            }
        }
    }

    private static void beginTest(Context c, Incoming in) {
        int hours = Math.max(0, ConfigStore.getInt(c, "test_limit_hours", 24));
        long last = ConfigStore.lastTest(c, in.contactKey);

        if (hours > 0 && last > 0) {
            long window = hours * 60L * 60L * 1000L;
            if (System.currentTimeMillis() - last < window) {
                in.replyTarget.sendText(c,
                        ConfigStore.get(c, "txt_test_limit",
                                "Você já recebeu um teste recentemente."));
                return;
            }
        }

        in.replyTarget.sendText(c,
                ConfigStore.get(c, "txt_test_wait", "Gerando seu teste, aguarde..."));

        BotRuntime.startPanelTask(
                c, "TEST", in.contactKey, in.contactLabel,
                "", in.replyTarget, false
        );
    }

    private static void beginCredits(Context c, Incoming in) {
        String email = ConfigStore.linkedReseller(c, in.contactKey);

        if (email.isEmpty()) {
            ConfigStore.setState(c, in.contactKey, STATE_WAIT_CREDIT_EMAIL);
            in.replyTarget.sendText(c,
                    ConfigStore.get(c, "txt_ask_email", "Envie o e-mail cadastrado."));
        } else {
            ConfigStore.setState(c, in.contactKey, STATE_WAIT_CREDIT_CONFIRM);
            in.replyTarget.sendText(c,
                    ConfigStore.get(c, "txt_credit_confirm",
                            "Digite CONFIRMAR para receber 50 créditos."));
        }
    }

    private static boolean isEmail(String value) {
        return value != null && value.trim().matches(
                "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        );
    }

    private static boolean matchesAny(String msg, String csv) {
        if (csv == null) return false;
        for (String s : csv.split(",")) {
            String t = norm(s);
            if (!t.isEmpty() && (msg.equals(t) || msg.contains(t))) return true;
        }
        return false;
    }

    private static String norm(String value) {
        if (value == null) return "";
        String s = java.text.Normalizer.normalize(value, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "");
        return s.toLowerCase(Locale.ROOT).trim();
    }
}
