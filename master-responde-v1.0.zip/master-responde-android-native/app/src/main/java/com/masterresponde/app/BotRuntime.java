package com.masterresponde.app;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class BotRuntime {
    public static class PendingPanelTask {
        public String id;
        public String type;
        public String contactKey;
        public String contactLabel;
        public String email;
        public ReplyTarget replyTarget;
        public boolean initialReseller;
    }

    private static final Map<String, ReplyTarget> replyTargets = new ConcurrentHashMap<>();
    private static final Map<String, PendingPanelTask> panelTasks = new ConcurrentHashMap<>();
    private static final Handler handler = new Handler(Looper.getMainLooper());

    public static void rememberReplyTarget(String contactKey, ReplyTarget target) {
        if (contactKey != null && target != null) replyTargets.put(contactKey, target);
    }

    public static ReplyTarget target(String contactKey) {
        return replyTargets.get(contactKey);
    }

    public static void sendCategory(Context c, String contactKey, String category) {
        ReplyTarget target = target(contactKey);
        if (target == null) return;

        List<ResponseItem> items = ConfigStore.responseItems(c, category);
        long delay = 0L;

        for (ResponseItem item : items) {
            delay += 800L;
            handler.postDelayed(() -> {
                boolean ok;
                if (ResponseItem.TYPE_TEXT.equals(item.type)) {
                    ok = target.sendText(c, item.value);
                } else {
                    String mime = mimeFor(item.type);
                    ok = target.sendMedia(c, Uri.parse(item.value), mime);
                }

                ConfigStore.addHistory(
                        c,
                        "RESPOSTA " + item.type,
                        contactKey,
                        item.title + (ok ? "" : " • não enviado pelo RemoteInput"),
                        ok
                );
            }, delay);
        }
    }

    public static String startPanelTask(
            Context c,
            String type,
            String contactKey,
            String contactLabel,
            String email,
            ReplyTarget target,
            boolean initialReseller
    ) {
        PendingPanelTask task = new PendingPanelTask();
        task.id = UUID.randomUUID().toString();
        task.type = type;
        task.contactKey = contactKey;
        task.contactLabel = contactLabel;
        task.email = email;
        task.replyTarget = target;
        task.initialReseller = initialReseller;
        panelTasks.put(task.id, task);

        PanelWorkerService.enqueue(c, task.id, type, email);
        return task.id;
    }

    public static void onPanelResult(Context c, String taskId, boolean ok, String payload, String code) {
        PendingPanelTask task = panelTasks.remove(taskId);

        if (task == null) {
            ConfigStore.addHistory(c, "MASTERFLIX", "manual", payload, ok);
            return;
        }

        ReplyTarget target = task.replyTarget;

        if ("TEST".equals(task.type)) {
            if (ok) {
                ConfigStore.setLastTest(c, task.contactKey, System.currentTimeMillis());
                if (target != null) target.sendText(c, payload);
                ConfigStore.addHistory(c, "TESTE", task.contactLabel, "Teste entregue", true);
            } else {
                if (target != null) target.sendText(c,
                        ConfigStore.get(c, "txt_panel_error", "Não foi possível concluir."));
                ConfigStore.addHistory(c, "TESTE", task.contactLabel, code + " • " + payload, false);
            }
            return;
        }

        if ("CREDIT".equals(task.type)) {
            if (ok) {
                if (task.email != null && !task.email.isEmpty()) {
                    ConfigStore.linkReseller(c, task.contactKey, task.email);
                }

                String text = ConfigStore.get(
                        c,
                        task.initialReseller ? "txt_reseller_success" : "txt_credit_success",
                        task.initialReseller
                                ? "✅ Revenda ativada com 50 créditos."
                                : "✅ Foram adicionados 50 créditos."
                );

                if (target != null) target.sendText(c, text);
                ConfigStore.addHistory(c, "CRÉDITOS +50", task.contactLabel, task.email, true);
                ConfigStore.clearState(c, task.contactKey);
            } else {
                if (target != null) target.sendText(c,
                        ConfigStore.get(c, "txt_panel_error", "Não foi possível concluir."));
                ConfigStore.addHistory(c, "CRÉDITOS +50", task.contactLabel, code + " • " + payload, false);
            }
        }
    }

    private static String mimeFor(String type) {
        if (ResponseItem.TYPE_IMAGE.equals(type)) return "image/*";
        if (ResponseItem.TYPE_VIDEO.equals(type)) return "video/*";
        if (ResponseItem.TYPE_AUDIO.equals(type)) return "audio/*";
        return "application/octet-stream";
    }
}
