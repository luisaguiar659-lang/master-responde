package com.masterresponde.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.app.ContextCompat;
import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.util.ArrayDeque;
import java.util.Locale;
import java.util.Queue;

public class PanelWorkerService extends Service {
    private static final String CHANNEL = "master_responde_panel";
    private static final int NOTIFICATION_ID = 7711;

    private static final String SIGN_IN = "https://masterflix.sigmab.pro/#/sign-in";
    private static final String DASHBOARD = "https://masterflix.sigmab.pro/#/dashboard";
    private static final String RESELLERS = "https://masterflix.sigmab.pro/#/resellers";

    private final Queue<Task> queue = new ArrayDeque<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private WebView webView;
    private Task current;
    private boolean busy = false;
    private boolean scriptInjected = false;
    private int authAttempts = 0;

    public static void enqueue(Context c, String taskId, String type, String email) {
        Intent i = new Intent(c, PanelWorkerService.class);
        i.putExtra("taskId", taskId);
        i.putExtra("type", type);
        i.putExtra("email", email == null ? "" : email);
        ContextCompat.startForegroundService(c, i);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        ConfigStore.ensureDefaults(this);
        createChannel();
        startForeground(
                NOTIFICATION_ID,
                new NotificationCompat.Builder(this, CHANNEL)
                        .setSmallIcon(android.R.drawable.stat_notify_sync)
                        .setContentTitle("MASTER RESPONDE")
                        .setContentText("MASTERFLIX pronto para processar tarefas")
                        .setOngoing(true)
                        .build()
        );

        webView = new WebView(getApplicationContext());
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUserAgentString(s.getUserAgentString() + " MasterResponde/1.0");

        webView.addJavascriptInterface(new Bridge(), "AutomationBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                handler.postDelayed(PanelWorkerService.this::routeCurrentPage, 1000);
            }
        });
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.hasExtra("taskId")) {
            Task t = new Task();
            t.id = intent.getStringExtra("taskId");
            t.type = intent.getStringExtra("type");
            t.email = intent.getStringExtra("email");
            queue.add(t);
        }

        if (!busy) processNext();
        return START_NOT_STICKY;
    }

    private void processNext() {
        current = queue.poll();

        if (current == null) {
            busy = false;
            stopForeground(STOP_FOREGROUND_REMOVE);
            stopSelf();
            return;
        }

        busy = true;
        scriptInjected = false;
        authAttempts = 0;

        updateNotification("Processando " + current.type + "...");

        String target = "CREDIT".equals(current.type) ? RESELLERS : DASHBOARD;
        webView.loadUrl(target);

        handler.postDelayed(() -> {
            if (busy && current != null) {
                fail("TIMEOUT", "O painel demorou demais para responder.");
            }
        }, 90000);
    }

    private void routeCurrentPage() {
        if (!busy || current == null) return;

        String url = webView.getUrl();
        String lower = url == null ? "" : url.toLowerCase(Locale.ROOT);

        if (lower.contains("sign-in") || lower.endsWith("sigmab.pro/")) {
            login();
            return;
        }

        ConfigStore.setPanelConnected(this, true);

        if (!scriptInjected) {
            scriptInjected = true;

            if ("TEST".equals(current.type)) {
                webView.evaluateJavascript(testScript(), null);
            } else if ("CREDIT".equals(current.type)) {
                webView.evaluateJavascript(creditScript(current.email), null);
            }
        }
    }

    private void login() {
        if (!ConfigStore.hasPanelCredentials(this)) {
            fail("NO_CREDENTIALS", "Configure o login do MASTERFLIX no aplicativo.");
            return;
        }

        if (authAttempts >= 3) {
            fail("LOGIN_FAILED", "Não foi possível entrar no MASTERFLIX.");
            return;
        }

        authAttempts++;
        scriptInjected = false;

        webView.evaluateJavascript(
                loginScript(ConfigStore.panelUser(this), ConfigStore.panelPassword(this)),
                null
        );

        handler.postDelayed(() -> {
            if (!busy || current == null) return;

            String u = webView.getUrl();
            String l = u == null ? "" : u.toLowerCase(Locale.ROOT);

            if (l.contains("sign-in")) {
                routeCurrentPage();
            } else {
                String target = "CREDIT".equals(current.type) ? RESELLERS : DASHBOARD;
                webView.loadUrl(target);
            }
        }, 4500);
    }

    private void success(String payload) {
        if (!busy || current == null) return;

        Task done = current;
        current = null;
        busy = false;
        ConfigStore.setPanelConnected(this, true);
        BotRuntime.onPanelResult(this, done.id, true, payload, "OK");
        handler.postDelayed(this::processNext, 500);
    }

    private void fail(String code, String message) {
        if (!busy || current == null) return;

        Task done = current;
        current = null;
        busy = false;
        ConfigStore.setPanelConnected(this, false);
        BotRuntime.onPanelResult(this, done.id, false, message, code);
        handler.postDelayed(this::processNext, 500);
    }

    private void updateNotification(String text) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.notify(
                NOTIFICATION_ID,
                new NotificationCompat.Builder(this, CHANNEL)
                        .setSmallIcon(android.R.drawable.stat_notify_sync)
                        .setContentTitle("MASTER RESPONDE")
                        .setContentText(text)
                        .setOngoing(true)
                        .build()
        );
    }

    private void createChannel() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(
                CHANNEL,
                "Automação MASTERFLIX",
                NotificationManager.IMPORTANCE_LOW
        );
        nm.createNotificationChannel(ch);
    }

    @Override
    public void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public class Bridge {
        @JavascriptInterface
        public void post(String raw) {
            handler.post(() -> {
                try {
                    JSONObject o = new JSONObject(raw);
                    String type = o.optString("type");
                    String code = o.optString("code");
                    String data = o.optString("data");

                    if ("success".equals(type)) {
                        success(data);
                    } else if ("error".equals(type)) {
                        fail(code, data);
                    }
                } catch (Exception e) {
                    fail("INVALID_BRIDGE", "Resposta inválida do painel.");
                }
            });
        }
    }

    private String loginScript(String user, String password) {
        return "(function(){"
                + "const USER=" + JSONObject.quote(user) + ";"
                + "const PASS=" + JSONObject.quote(password) + ";"
                + helpers()
                + "let n=0;const t=setInterval(()=>{n++;"
                + "const ins=[...document.querySelectorAll('input')];"
                + "const u=ins.find(i=>/usuario|usuário|e-mail|email/i.test((i.placeholder||'')+' '+(i.name||'')))||ins.find(i=>i.type==='text'||i.type==='email');"
                + "const p=ins.find(i=>i.type==='password');"
                + "if(!u||!p){if(n>40){clearInterval(t);post('error','LOGIN_FIELDS','Campos de login não encontrados.');}return;}"
                + "setVal(u,USER);setVal(p,PASS);"
                + "const cb=ins.find(i=>i.type==='checkbox');if(cb&&!cb.checked)clickReal(cb);"
                + "const btn=[...document.querySelectorAll('button')].find(b=>norm(b.innerText).includes('continuar'));"
                + "if(!btn){clearInterval(t);post('error','LOGIN_BUTTON','Botão Continuar não encontrado.');return;}"
                + "clearInterval(t);clickReal(btn);"
                + "},350);"
                + "})();true;";
    }

    private String testScript() {
        return "(function(){"
                + helpers()
                + "let copied=false;"
                + "function deliver(v){if(copied||!v)return;copied=true;post('success','TEST_COPIED',String(v));}"
                + "try{if(navigator.clipboard&&navigator.clipboard.writeText){"
                + "const old=navigator.clipboard.writeText.bind(navigator.clipboard);"
                + "navigator.clipboard.writeText=function(v){deliver(v);try{return old(v);}catch(e){return Promise.resolve();}};"
                + "}}catch(e){}"
                + "document.addEventListener('copy',()=>{setTimeout(()=>{const s=String(window.getSelection()||'');if(s)deliver(s);},0);},true);"
                + "let n=0;const find=setInterval(()=>{n++;"
                + "const all=[...document.querySelectorAll('button,a,div,span')];"
                + "const card=all.find(e=>norm(e.innerText)==='masterflix teste completo 1h')"
                + "||all.find(e=>norm(e.innerText).includes('masterflix teste completo 1h'));"
                + "if(!card){if(n>60){clearInterval(find);post('error','TEST_BUTTON','Teste padrão não encontrado.');}return;}"
                + "clearInterval(find);clickReal(card.closest('button,a')||card);"
                + "let w=0;const modalTimer=setInterval(()=>{w++;"
                + "const nodes=[...document.querySelectorAll('body *')];"
                + "const modal=nodes.find(e=>norm(e.innerText).includes('detalhes do cliente')&&norm(e.innerText).includes('copiar'));"
                + "if(!modal){if(w>80){clearInterval(modalTimer);post('error','TEST_MODAL','Detalhes do teste não apareceram.');}return;}"
                + "const copy=[...modal.querySelectorAll('button,a')].find(b=>norm(b.innerText)==='copiar');"
                + "if(copy){clickReal(copy);"
                + "setTimeout(()=>{if(!copied){"
                + "const text=modal.innerText||'';"
                + "if(/usuario|usuário/i.test(text)&&/senha/i.test(text)&&/m3u/i.test(text)){deliver(text);}else{post('error','TEST_COPY','Conteúdo copiado não pôde ser validado.');}"
                + "}},1200);clearInterval(modalTimer);}"
                + "},400);"
                + "},400);"
                + "})();true;";
    }

    private String creditScript(String email) {
        return "(function(){"
                + "const EMAIL=" + JSONObject.quote(email == null ? "" : email.toLowerCase(Locale.ROOT)) + ";"
                + helpers()
                + "function parseCredits(scope){const t=scope.innerText||'';const m=t.match(/cr[eé]ditos\\s*:?\\s*(\\d+)/i);return m?parseInt(m[1],10):null;}"
                + "let n=0;const timer=setInterval(()=>{n++;"
                + "const input=[...document.querySelectorAll('input')].find(i=>norm(i.placeholder).includes('pesquisar'));"
                + "if(!input){if(n>50){clearInterval(timer);post('error','SEARCH','Campo Pesquisar não encontrado.');}return;}"
                + "setVal(input,EMAIL);"
                + "const only=[...document.querySelectorAll('input[type=checkbox]')].find(c=>labelText(c).includes('somente essa revenda'));"
                + "if(only&&!only.checked)clickReal(only);"
                + "clearInterval(timer);"
                + "let w=0;const result=setInterval(()=>{w++;"
                + "const emailNode=[...document.querySelectorAll('body *')].find(e=>norm(e.innerText)===norm(EMAIL));"
                + "if(!emailNode){if(w>50){clearInterval(result);post('error','RESELLER_NOT_FOUND','Revenda não encontrada pelo e-mail informado.');}return;}"
                + "let card=emailNode;for(let d=0;card&&d<10;d++,card=card.parentElement){if(/cr[eé]ditos/i.test(card.innerText||''))break;}"
                + "if(!card){clearInterval(result);post('error','RESELLER_CARD','Cartão da revenda não encontrado.');return;}"
                + "const before=parseCredits(card);if(before===null){clearInterval(result);post('error','BALANCE_READ','Saldo atual não pôde ser lido.');return;}"
                + "let plus=[...card.querySelectorAll('button')].find(b=>norm((b.title||'')+' '+(b.getAttribute('aria-label')||'')+' '+(b.innerText||'')).includes('credito'));"
                + "if(!plus){plus=[...card.querySelectorAll('button')].find(b=>(b.innerText||'').trim()==='+');}"
                + "if(!plus){const bs=[...card.querySelectorAll('button')];if(bs.length===1)plus=bs[0];}"
                + "if(!plus){clearInterval(result);post('error','PLUS_BUTTON','Botão + Adicionar Créditos não encontrado.');return;}"
                + "clearInterval(result);clickReal(plus);"
                + "let m=0;const modalTimer=setInterval(()=>{m++;"
                + "const nodes=[...document.querySelectorAll('body *')];"
                + "const modal=nodes.find(e=>norm(e.innerText).includes('adicionar creditos')&&norm(e.innerText).includes('transferir'));"
                + "if(!modal){if(m>50){clearInterval(modalTimer);post('error','CREDIT_MODAL','Janela Adicionar Créditos não abriu.');}return;}"
                + "const visibleEmail=norm(modal.innerText);if(!visibleEmail.includes(norm(EMAIL))){clearInterval(modalTimer);post('error','EMAIL_MISMATCH','A conta aberta não corresponde ao e-mail solicitado.');return;}"
                + "const amount=[...modal.querySelectorAll('input')].find(i=>i.type==='number'||labelText(i).includes('credito'));"
                + "if(!amount){clearInterval(modalTimer);post('error','AMOUNT','Campo de créditos não encontrado.');return;}"
                + "setVal(amount,'50');"
                + "const cb=modal.querySelector('input[type=checkbox]');if(cb&&!cb.checked)clickReal(cb);"
                + "const add=[...modal.querySelectorAll('button')].find(b=>norm(b.innerText)==='adicionar');"
                + "if(!add){clearInterval(modalTimer);post('error','ADD_BUTTON','Botão Adicionar não encontrado.');return;}"
                + "clearInterval(modalTimer);clickReal(add);"
                + "let v=0;const verify=setInterval(()=>{v++;"
                + "const en=[...document.querySelectorAll('body *')].find(e=>norm(e.innerText)===norm(EMAIL));"
                + "if(en){let c=en;for(let d=0;c&&d<10;d++,c=c.parentElement){if(/cr[eé]ditos/i.test(c.innerText||''))break;}"
                + "if(c){const after=parseCredits(c);if(after===before+50){clearInterval(verify);post('success','CREDIT_OK','Saldo anterior: '+before+' | Saldo atual: '+after);return;}}}"
                + "if(v>60){clearInterval(verify);post('error','CREDIT_PENDING','A transferência foi enviada, mas o novo saldo não pôde ser confirmado. Não repetir automaticamente.');}"
                + "},500);"
                + "},400);"
                + "},400);"
                + "})();true;";
    }

    private String helpers() {
        return ""
                + "function post(type,code,data){try{AutomationBridge.post(JSON.stringify({type:type,code:code,data:data}));}catch(e){}}"
                + "function norm(v){return (v||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase().trim();}"
                + "function setVal(el,v){if(!el)return;const p=Object.getPrototypeOf(el);const d=Object.getOwnPropertyDescriptor(p,'value');if(d&&d.set)d.set.call(el,v);else el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}"
                + "function clickReal(el){if(!el)return;['pointerdown','mousedown','pointerup','mouseup','click'].forEach(t=>{try{el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window}));}catch(e){}});}"
                + "function labelText(el){let p=el,n=0,s='';while(p&&n<4){s+=' '+(p.innerText||'');p=p.parentElement;n++;}return norm(s);}";
    }

    private static class Task {
        String id;
        String type;
        String email;
    }
}
