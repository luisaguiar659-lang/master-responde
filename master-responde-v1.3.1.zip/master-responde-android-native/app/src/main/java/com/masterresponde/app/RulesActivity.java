package com.masterresponde.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.UUID;

public class RulesActivity extends Activity {

    private SharedPreferences prefs;
    private LinearLayout content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("master_responde", MODE_PRIVATE);
        buildScreen();
        renderRules();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14), dp(10), dp(14), dp(10));

        Button back = new Button(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(24);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(58), dp(54)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(text("REGRAS", 21, Color.WHITE, true));
        titles.addView(text(
                "Autorespostas de texto configuráveis",
                12,
                Color.rgb(150, 160, 170),
                false
        ));
        header.addView(titles, new LinearLayout.LayoutParams(0, dp(58), 1f));

        root.addView(header);

        View line = new View(this);
        line.setBackgroundResource(getResources().getIdentifier(
                "line", "drawable", getPackageName()));
        root.addView(line, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(40));
        scroll.addView(content);

        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void renderRules() {
        content.removeAllViews();

        Button add = actionButton("+ ADICIONAR REGRA", true);
        add.setOnClickListener(v -> showAddDialog());
        content.addView(add);

        gap(12);

        content.addView(text(
                "Quando o Bot estiver ativo, o MASTER RESPONDE verifica estas regras nas mensagens recebidas pelo WhatsApp Business.",
                12,
                Color.rgb(145, 155, 165),
                false
        ));

        gap(16);

        JSONArray rules = loadRules();

        if (rules.length() == 0) {
            LinearLayout empty = card();
            empty.addView(text(
                    "Nenhuma regra cadastrada.",
                    15,
                    Color.rgb(170, 180, 190),
                    false
            ));
            empty.addView(text(
                    "Exemplo:\nGatilho: bom dia\nResposta: Olá! Como posso ajudar?",
                    13,
                    Color.rgb(130, 145, 155),
                    false
            ));
            content.addView(empty);
            return;
        }

        for (int i = 0; i < rules.length(); i++) {
            JSONObject rule = rules.optJSONObject(i);
            if (rule == null) continue;

            String id = rule.optString("id");
            String trigger = rule.optString("trigger");
            String reply = rule.optString("reply");
            boolean exact = rule.optBoolean("exact", false);

            LinearLayout c = card();

            c.addView(text(
                    trigger,
                    17,
                    Color.WHITE,
                    true
            ));

            c.addView(text(
                    exact ? "Correspondência: EXATA" : "Correspondência: CONTÉM",
                    11,
                    Color.rgb(255, 150, 0),
                    true
            ));

            TextView response = text(
                    reply,
                    13,
                    Color.rgb(205, 215, 220),
                    false
            );
            response.setPadding(0, dp(10), 0, dp(8));
            c.addView(response);

            Button delete = actionButton("EXCLUIR", false);
            delete.setOnClickListener(v -> confirmDelete(id));
            c.addView(delete);

            content.addView(c);
            gap(10);
        }
    }

    private void showAddDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(18), dp(8), dp(18), dp(8));

        EditText trigger = field("Palavra ou frase");
        box.addView(trigger);

        EditText reply = field("Resposta automática");
        reply.setMinLines(3);
        reply.setGravity(Gravity.TOP);
        box.addView(reply);

        CheckBox exact = new CheckBox(this);
        exact.setText("Responder somente se a mensagem for exatamente igual");
        exact.setTextColor(Color.rgb(40, 40, 40));
        box.addView(exact);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Nova regra")
                .setView(box)
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("SALVAR", null)
                .create();

        dialog.setOnShowListener(d -> {
            Button save = dialog.getButton(AlertDialog.BUTTON_POSITIVE);

            save.setOnClickListener(v -> {
                String t = trigger.getText().toString().trim();
                String r = reply.getText().toString().trim();

                if (t.isEmpty()) {
                    trigger.setError("Informe a palavra ou frase.");
                    return;
                }

                if (r.isEmpty()) {
                    reply.setError("Informe a resposta.");
                    return;
                }

                addRule(t, r, exact.isChecked());
                dialog.dismiss();
                renderRules();

                Toast.makeText(
                        this,
                        "Regra salva.",
                        Toast.LENGTH_SHORT
                ).show();
            });
        });

        dialog.show();
    }

    private void addRule(String trigger, String reply, boolean exact) {
        JSONArray rules = loadRules();

        JSONObject rule = new JSONObject();

        try {
            rule.put("id", UUID.randomUUID().toString());
            rule.put("trigger", trigger);
            rule.put("reply", reply);
            rule.put("exact", exact);
            rules.put(rule);

            prefs.edit()
                    .putString("text_rules", rules.toString())
                    .apply();

        } catch (Exception ignored) {
        }
    }

    private void confirmDelete(String id) {
        new AlertDialog.Builder(this)
                .setTitle("Excluir regra?")
                .setMessage("Essa regra deixará de responder automaticamente.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("EXCLUIR", (d, w) -> {
                    deleteRule(id);
                    renderRules();
                })
                .show();
    }

    private void deleteRule(String id) {
        JSONArray oldRules = loadRules();
        JSONArray newRules = new JSONArray();

        for (int i = 0; i < oldRules.length(); i++) {
            JSONObject rule = oldRules.optJSONObject(i);
            if (rule == null) continue;

            if (!id.equals(rule.optString("id"))) {
                newRules.put(rule);
            }
        }

        prefs.edit()
                .putString("text_rules", newRules.toString())
                .apply();
    }

    private JSONArray loadRules() {
        try {
            return new JSONArray(
                    prefs.getString("text_rules", "[]")
            );
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15), dp(15), dp(15), dp(15));
        c.setBackgroundResource(getResources().getIdentifier(
                "card", "drawable", getPackageName()));
        return c;
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextColor(Color.BLACK);
        e.setHintTextColor(Color.rgb(120, 120, 120));
        e.setTextSize(14);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, dp(5), 0, dp(10));
        e.setLayoutParams(lp);

        return e;
    }

    private Button actionButton(String label, boolean orange) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setTypeface(null, 1);
        b.setBackgroundResource(getResources().getIdentifier(
                orange ? "button_orange" : "button_dark",
                "drawable",
                getPackageName()
        ));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
        );
        b.setLayoutParams(lp);

        return b;
    }

    private TextView text(
            String value,
            int size,
            int color,
            boolean bold
    ) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);

        if (bold) {
            t.setTypeface(null, 1);
        }

        return t;
    }

    private void gap(int height) {
        View v = new View(this);
        content.addView(
                v,
                new LinearLayout.LayoutParams(1, dp(height))
        );
    }

    private int dp(int value) {
        return Math.round(
                value * getResources().getDisplayMetrics().density
        );
    }
}
