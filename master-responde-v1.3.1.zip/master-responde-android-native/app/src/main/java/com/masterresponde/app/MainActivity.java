package com.masterresponde.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private LinearLayout content;
    private SharedPreferences prefs;
    private TextView botStatus;
    private TextView waStatus;
    private Switch botSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("master_responde", MODE_PRIVATE);

        if (android.os.Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }

        buildScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(10), dp(16), dp(10));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier(
                "logo_master_responde", "drawable", getPackageName()));
        header.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(10), 0, 0, 0);
        titles.addView(text("MASTER RESPONDE", 21, Color.WHITE, true));
        titles.addView(text("Central inteligente de atendimento", 12,
                Color.rgb(150, 160, 170), false));
        header.addView(titles, new LinearLayout.LayoutParams(0, dp(62), 1f));

        root.addView(header);

        View line = new View(this);
        line.setBackgroundResource(getResources().getIdentifier(
                "line", "drawable", getPackageName()));
        root.addView(line, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));

        ScrollView scroll = new ScrollView(this);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(18), dp(16), dp(40));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        buildDashboard();
    }

    private void buildDashboard() {
        content.removeAllViews();

        LinearLayout hero = card();

        LinearLayout heroRow = new LinearLayout(this);
        heroRow.setOrientation(LinearLayout.HORIZONTAL);
        heroRow.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout heroText = new LinearLayout(this);
        heroText.setOrientation(LinearLayout.VERTICAL);
        heroText.addView(text("MASTER RESPONDE", 24, Color.WHITE, true));
        heroText.addView(text("Dashboard v1.3.1", 14,
                Color.rgb(255, 150, 0), true));
        heroText.addView(text(
                "Etapa 4: regras de texto + proteção contra duplicidade.",
                13, Color.rgb(170, 180, 190), false));

        heroRow.addView(heroText, new LinearLayout.LayoutParams(0, -2, 1f));

        botSwitch = new Switch(this);
        botSwitch.setChecked(prefs.getBoolean("bot_enabled", false));
        botSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("bot_enabled", isChecked).apply();
            refreshStatus();
            Toast.makeText(
                    this,
                    isChecked ? "Bot ativado." : "Bot desativado.",
                    Toast.LENGTH_SHORT
            ).show();
        });
        heroRow.addView(botSwitch);

        hero.addView(heroRow);
        content.addView(hero);

        gap(16);
        section("STATUS");

        GridLayout statusGrid = new GridLayout(this);
        statusGrid.setColumnCount(2);

        botStatus = addStatus(statusGrid, "Bot", "● Desativado",
                Color.rgb(0, 184, 255), null);

        waStatus = addStatus(statusGrid, "WhatsApp Business", "● Verificando",
                Color.rgb(0, 184, 255), this::openNotificationAccess);

        addStatus(statusGrid, "MASTERFLIX", "● Em breve",
                Color.rgb(255, 145, 0), null);

        addStatus(statusGrid, "Fila", "● 0 aguardando",
                Color.rgb(255, 145, 0), null);

        content.addView(statusGrid);

        gap(18);
        section("CONTROLE");

        Button notificationButton = fullButton(
                "LIBERAR ACESSO ÀS NOTIFICAÇÕES", true);
        notificationButton.setOnClickListener(v -> openNotificationAccess());
        content.addView(notificationButton);

        gap(10);

        content.addView(text(
                "A v1.3 mantém o teste \"teste bot\" e adiciona regras de texto.\n\n" +
                "Abra REGRAS para cadastrar palavra/frase e resposta automática.",
                12, Color.rgb(145, 155, 165), false));

        gap(10);

        content.addView(text(
                prefs.getString(
                        "last_test_status",
                        "Último teste: ainda não realizado"
                ),
                12,
                Color.rgb(0, 184, 255),
                true
        ));

        gap(18);
        section("ATALHOS");

        GridLayout shortcuts = new GridLayout(this);
        shortcuts.setColumnCount(2);

        addButton(shortcuts, "Gerar teste", true);
        addButton(shortcuts, "Nova revenda", false);
        addButton(shortcuts, "Créditos +50", true);
        addButton(shortcuts, "@infor grupos", false);

        content.addView(shortcuts);

        gap(18);
        section("MÓDULOS");

        GridLayout modules = new GridLayout(this);
        modules.setColumnCount(2);

        Button rulesButton = addButton(modules, "Regras", false);
        rulesButton.setOnClickListener(v ->
                startActivity(new Intent(this, RulesActivity.class)));
        addButton(modules, "Mídias", false);
        addButton(modules, "Revendas", false);
        addButton(modules, "Grupos", false);
        addButton(modules, "Histórico", false);
        addButton(modules, "Configurações", false);

        content.addView(modules);

        refreshStatus();
    }

    private void refreshStatus() {
        if (botStatus != null) {
            boolean enabled = prefs.getBoolean("bot_enabled", false);
            botStatus.setText(enabled ? "● Ativo" : "● Desativado");
            botStatus.setTextColor(enabled
                    ? Color.rgb(0, 184, 255)
                    : Color.rgb(145, 155, 165));
        }

        if (waStatus != null) {
            boolean installed = isPackageInstalled("com.whatsapp.w4b");
            boolean access = hasNotificationAccess();

            if (!installed) {
                waStatus.setText("● Não instalado");
                waStatus.setTextColor(Color.rgb(255, 145, 0));
            } else if (access) {
                waStatus.setText("● Acesso liberado");
                waStatus.setTextColor(Color.rgb(0, 184, 255));
            } else {
                waStatus.setText("● Permissão necessária");
                waStatus.setTextColor(Color.rgb(255, 145, 0));
            }
        }
    }

    private boolean hasNotificationAccess() {
        String enabled = Settings.Secure.getString(
                getContentResolver(), "enabled_notification_listeners");
        return enabled != null && enabled.contains(getPackageName());
    }

    private boolean isPackageInstalled(String packageName) {
        try {
            getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void openNotificationAccess() {
        try {
            Intent intent = new Intent(
                    "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS");
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Abra Configurações > Acesso às notificações.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackgroundResource(getResources().getIdentifier(
                "card", "drawable", getPackageName()));
        return c;
    }

    private TextView addStatus(
            GridLayout parent,
            String title,
            String value,
            int accent,
            Runnable click
    ) {
        LinearLayout c = card();

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = dp(110);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        c.setLayoutParams(lp);

        c.addView(text(title, 12, Color.rgb(145, 155, 165), false));

        TextView v = text(value, 15, accent, true);
        v.setPadding(0, dp(10), 0, 0);
        c.addView(v);

        if (click != null) {
            c.setOnClickListener(view -> click.run());
        }

        parent.addView(c);
        return v;
    }

    private Button fullButton(String label, boolean orange) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(null, 1);
        b.setBackgroundResource(getResources().getIdentifier(
                orange ? "button_orange" : "button_dark",
                "drawable", getPackageName()));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        b.setLayoutParams(lp);
        return b;
    }

    private Button addButton(GridLayout parent, String label, boolean orange) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(null, 1);
        b.setBackgroundResource(getResources().getIdentifier(
                orange ? "button_orange" : "button_dark",
                "drawable", getPackageName()));

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = dp(58);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(lp);

        parent.addView(b);
        return b;
    }

    private void section(String value) {
        TextView t = text(value, 12, Color.rgb(255, 150, 0), true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, 0, 0, dp(8));
        content.addView(t);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private void gap(int height) {
        View v = new View(this);
        content.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
