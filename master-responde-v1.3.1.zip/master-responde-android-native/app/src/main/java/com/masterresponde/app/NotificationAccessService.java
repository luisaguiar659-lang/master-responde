package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NotificationAccessService extends NotificationListenerService {

    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    // Proteção em memória contra atualizações repetidas da mesma notificação.
    private static final Map<String, Long> RECENT =
            new ConcurrentHashMap<>();

    private static final Object SEND_LOCK = new Object();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (!WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        SharedPreferences prefs =
                getSharedPreferences("master_responde", MODE_PRIVATE);

        if (!prefs.getBoolean("bot_enabled", false)) return;

        Notification notification = sbn.getNotification();

        if (notification == null || notification.extras == null) return;

        CharSequence value =
                notification.extras.getCharSequence(Notification.EXTRA_TEXT);

        if (value == null) return;

        String incoming = normalize(value.toString());

        if (incoming.isEmpty()) return;

        String notificationKey = sbn.getKey() == null
                ? "no-key"
                : sbn.getKey();

        // Regra fixa aprovada na v1.2.1
        if ("teste bot".equals(incoming)) {
            sendWithProtection(
                    notification,
                    notificationKey,
                    "fixed_test",
                    incoming,
                    "✅ MASTER RESPONDE ativo e funcionando."
            );
            return;
        }

        // Regras configuráveis
        try {
            JSONArray rules = new JSONArray(
                    prefs.getString("text_rules", "[]")
            );

            for (int i = 0; i < rules.length(); i++) {
                JSONObject rule = rules.optJSONObject(i);

                if (rule == null) continue;

                String trigger = normalize(
                        rule.optString("trigger", "")
                );

                String response =
                        rule.optString("reply", "").trim();

                boolean exact =
                        rule.optBoolean("exact", false);

                if (trigger.isEmpty() || response.isEmpty()) {
                    continue;
                }

                boolean match = exact
                        ? incoming.equals(trigger)
                        : incoming.contains(trigger);

                if (match) {
                    String ruleId = rule.optString(
                            "id",
                            String.valueOf(i)
                    );

                    sendWithProtection(
                            notification,
                            notificationKey,
                            "rule|" + ruleId,
                            incoming,
                            response
                    );

                    return;
                }
            }

        } catch (Exception ignored) {
        }
    }

    private void sendWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            String message
    ) {
        synchronized (SEND_LOCK) {

            long now = System.currentTimeMillis();

            String fingerprint =
                    notificationKey
                            + "|"
                            + ruleKey
                            + "|"
                            + incoming;

            Long memoryTime = RECENT.get(fingerprint);

            if (memoryTime != null
                    && now - memoryTime < 8000L) {
                return;
            }

            SharedPreferences prefs =
                    getSharedPreferences(
                            "master_responde",
                            MODE_PRIVATE
                    );

            String last =
                    prefs.getString(
                            "last_rule_fingerprint",
                            ""
                    );

            long lastTime =
                    prefs.getLong(
                            "last_rule_fingerprint_time",
                            0L
                    );

            if (fingerprint.equals(last)
                    && now - lastTime < 8000L) {
                RECENT.put(fingerprint, now);
                return;
            }

            // Marca ANTES de enviar para impedir duas callbacks simultâneas.
            RECENT.put(fingerprint, now);

            prefs.edit()
                    .putString(
                            "last_rule_fingerprint",
                            fingerprint
                    )
                    .putLong(
                            "last_rule_fingerprint_time",
                            now
                    )
                    .commit();

            boolean sent = reply(
                    notification,
                    message
            );

            prefs.edit()
                    .putString(
                            "last_test_status",
                            sent
                                    ? "Última autoresposta: enviada"
                                    : "Última autoresposta: não disponível"
                    )
                    .apply();

            // Limpeza simples para não crescer indefinidamente.
            if (RECENT.size() > 200) {
                RECENT.clear();
                RECENT.put(fingerprint, now);
            }
        }
    }

    private boolean reply(
            Notification notification,
            String message
    ) {
        Notification.Action[] actions =
                notification.actions;

        if (actions == null) return false;

        for (Notification.Action action : actions) {
            if (action == null
                    || action.actionIntent == null) {
                continue;
            }

            RemoteInput[] inputs =
                    action.getRemoteInputs();

            if (inputs == null
                    || inputs.length == 0) {
                continue;
            }

            for (RemoteInput input : inputs) {
                if (input == null) continue;

                if (!input.getAllowFreeFormInput()) {
                    continue;
                }

                try {
                    Intent intent = new Intent();
                    Bundle results = new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            this,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) return "";

        return Normalizer
                .normalize(
                        value,
                        Normalizer.Form.NFD
                )
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
