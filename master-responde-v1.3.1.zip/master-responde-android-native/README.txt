MASTER RESPONDE v1.3.1

Base:
- v1.0 dashboard
- v1.1.1 Bot + notificações
- v1.2.1 primeira autoresposta
- v1.3 regras configuráveis

CORREÇÃO ÚNICA DA v1.3.1:
- proteção forte contra resposta duplicada.

A correção:
- identifica a notificação do WhatsApp;
- cria uma impressão digital por notificação + regra + mensagem;
- trava envios simultâneos;
- registra a impressão ANTES de responder;
- bloqueia repetição da mesma notificação por 8 segundos.

IMPORTANTE PARA O TESTE:
Se houver outro aplicativo de autoresposta com acesso às notificações,
desative temporariamente esse outro aplicativo para testar apenas
o MASTER RESPONDE.

Nenhuma função nova foi adicionada.
