MASTER RESPONDE v1.8.7

Base: v1.8.6.

CORREÇÕES DESTA VERSÃO:

1. BOTÃO "ADICIONAR CRÉDITOS"
O MASTERFLIX mostra cada revenda como um cartão.
Agora o bot:
- localiza o e-mail exato;
- sobe até o cartão que contém aquele e-mail;
- exige que o MESMO cartão contenha "Adicionar Créditos";
- localiza exatamente esse rótulo;
- procura o botão/elemento clicável ligado ao rótulo;
- rola até ele e clica.

Ele não procura mais um sinal "+" genérico em qualquer parte da página.

2. MENSAGENS DUPLICADAS DURANTE A AUTOMAÇÃO
Enquanto o fluxo estiver:
- aguardando e-mail;
- procurando revenda;
- adicionando créditos;

atualizações/republicações da notificação não geram mais:
- "Envie somente o mesmo e-mail..."
- "A operação da revenda ainda está em andamento..."

Essas etapas ficam silenciosas para evitar o loop visto nos prints.

PRESERVADO:
- sem pedir CONFIRMAR;
- +50 automático;
- caixa "Eu concordo em transferir 50 créditos";
- clique final único;
- sem leitura de saldo;
- link do grupo de suporte editável;
- link de cadastro editável;
- geração de teste em segundo plano.

PRÓXIMA ETAPA PLANEJADA:
v1.9 - MENSAGENS E TEMPOS
Todas as mensagens automáticas passam a ser editáveis manualmente no app,
com atraso e intervalos configuráveis em segundos.
