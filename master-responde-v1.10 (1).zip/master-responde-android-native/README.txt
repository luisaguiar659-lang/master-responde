MASTER RESPONDE v1.10

BASE ESTÁVEL:
v1.9

FUNÇÃO NOVA:
FOTOS NAS MÍDIAS

Nesta versão foi adicionada somente a função de CADASTRAR FOTOS
dentro das categorias, mantendo a regra de uma função por versão.

COMO FUNCIONA:
1. Abra MÍDIAS.
2. Crie ou abra uma categoria.
3. Toque em + ADICIONAR FOTO.
4. Escolha uma imagem no celular.
5. A foto fica salva na categoria.
6. É possível cadastrar várias fotos na mesma categoria.
7. A tela mostra:
   - posição do item;
   - nome do arquivo;
   - pré-visualização da foto;
   - botão EXCLUIR FOTO.

ARMAZENAMENTO:
- o app usa o seletor de documentos do Android;
- não precisa pedir acesso geral à galeria;
- tenta manter permissão persistente para continuar lendo a foto
  mesmo depois de fechar o aplicativo.

COMPATIBILIDADE:
- os textos antigos continuam funcionando normalmente;
- objetos antigos sem campo "type" continuam sendo tratados como texto;
- regras com categoria continuam enviando somente os textos nesta v1.10;
- uma categoria apenas com fotos não aparece ainda como categoria pronta
  para regra automática de texto.

IMPORTANTE:
O ENVIO AUTOMÁTICO DA FOTO PELO WHATSAPP NÃO FOI ATIVADO NESTA VERSÃO.

Motivo:
resposta de texto usa RemoteInput de forma confiável, mas mídia precisa
ser testada separadamente no WhatsApp Business do aparelho.

PRÓXIMA ETAPA APÓS VALIDAR A v1.10:
testar o envio de uma foto cadastrada pelo WhatsApp Business, sem mexer
nos textos, revendas, testes ou demais funções estáveis.

PRESERVADO DA v1.9:
- Mensagens e Tempos;
- gatilhos editáveis;
- mensagens automáticas editáveis;
- tempos em segundos;
- bloqueios de repetição;
- regras;
- categorias de texto;
- nova revenda com verificação de e-mail;
- link de cadastro editável;
- grupo de suporte editável;
- geração automática de testes;
- @infor;
- MASTERFLIX login/sessão.
