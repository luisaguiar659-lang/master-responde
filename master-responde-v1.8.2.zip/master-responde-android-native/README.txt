MASTER RESPONDE v1.8.2

Base: v1.8.1.

CORREÇÃO ÚNICA:
LOOP DE RESPOSTAS NO FLUXO "QUERO SER REVENDA".

Problema observado:
- cliente envia "Quero ser Revenda";
- bot envia o link corretamente;
- o WhatsApp atualiza/republica a mesma notificação;
- como o estado já estava WAITING_EMAIL, o mesmo comando podia ser
  interpretado novamente como uma mensagem inválida;
- o bot começava a repetir:
  "Envie somente o mesmo e-mail usado no cadastro da revenda."

Correção:
1. Toda mensagem privada passa por deduplicação ANTES do fluxo de revenda.
2. A identificação usa conversa + horário/evento + conteúdo.
3. Existe uma segunda proteção de conteúdo por 12 segundos para
   atualizações rápidas onde o WhatsApp muda a identificação da notificação.
4. A mesma mensagem/evento fica bloqueada por até 2 minutos.
5. Enquanto estiver WAITING_EMAIL, uma repetição de "Quero ser Revenda"
   é ignorada silenciosamente.
6. O fluxo só avança quando chegar uma nova mensagem contendo e-mail válido.

MENSAGEM DE CADASTRO:
"Após concluir seu cadastro, envie o e-mail usado no cadastro para ativar seu painel."

NÃO FOI ALTERADO:
- geração automática de teste;
- automação MASTERFLIX em segundo plano;
- busca da revenda;
- CONFIRMAR;
- crédito inicial +50;
- proteção contra crédito duplicado;
- menus, regras e grupos.

TESTE:
1. Envie "Quero ser Revenda".
2. O bot deve enviar o link UMA VEZ.
3. Aguarde alguns segundos sem enviar nada.
4. O bot NÃO deve mandar mensagens repetidas.
5. Envie um texto qualquer sem e-mail.
6. Deve orientar uma vez para enviar o e-mail.
7. Envie um e-mail válido.
8. O fluxo deve continuar normalmente.
