MASTER RESPONDE v1.16

BASE:
v1.15 — motor aberto/segundo plano, trava de teste e menu lateral.

ALTERAÇÕES DA v1.16

1. @infor — CORREÇÃO DO MENU
O menu dos grupos deixou de depender de uma lista fixa de categorias.

Agora:
- o @infor lê as categorias realmente cadastradas em MÍDIAS;
- somente categorias que possuem ao menos um TEXTO ou LINK enviável aparecem;
- a numeração é criada dinamicamente na ordem cadastrada;
- número e nome real da categoria podem ser usados;
- o comando 0 continua direcionado ao suporte;
- o texto antigo do menu é migrado automaticamente quando ainda estiver salvo;
- categorias inexistentes deixam de aparecer no menu, evitando mensagens
  repetidas de "categoria ainda não configurada".

Também foi reforçada a deduplicação nos grupos:
- além do identificador do evento do WhatsApp, o conteúdo do comando fica
  protegido por grupo durante a janela de duplicação configurada;
- várias notificações iguais de "1", "2", "3" etc. não devem disparar
  respostas repetidas em sequência.

2. MASTERFLIX — MINI PAINEL RESTAURADO
A tela MASTERFLIX voltou ao comportamento clássico:
- sessão;
- usuário/e-mail;
- senha;
- SALVAR CREDENCIAIS;
- PREENCHER LOGIN SALVO;
- ENCERRAR SESSÃO;
- PAINEL MASTERFLIX incorporado dentro do card.

Ao carregar o dashboard do MASTERFLIX, o aplicativo NÃO troca mais a tela
inteira pelo WebView original.

O login salvo e o preenchimento automático continuam funcionando.

3. MENU LATERAL
Todas as opções do menu lateral agora usam a mesma aparência escura/neutra.
Os antigos botões laranja/amarelos do menu lateral foram padronizados.

Atalhos:
- Gerar Teste
- Nova Revenda
- MASTERFLIX
- Mídias / Links
- @infor Grupos

Módulos:
- Regras
- Mídias
- Revendas
- Grupos
- Mensagens e Tempos
- Histórico
- Configurações

4. VOLTAR PARA O MESMO MENU
Quando uma tela é aberta pelo menu ☰:
- a tela abre normalmente;
- ao tocar na seta Voltar, retorna ao dashboard;
- o menu lateral é reaberto automaticamente no mesmo ponto de navegação.

Essa função pode ser ligada/desligada em Configurações.

5. CONFIGURAÇÕES DO APLICATIVO
A antiga opção "Configurações / MASTERFLIX" foi separada.

Agora CONFIGURAÇÕES abre somente preferências do MASTER RESPONDE:
- tema da interface principal: Escuro ou Claro;
- voltar automaticamente ao menu lateral;
- reconexão automática do motor;
- mostrar/ocultar detalhes do dashboard;
- restaurar preferências de interface.

As configurações não apagam:
- regras;
- categorias;
- mensagens;
- credenciais;
- sessão MASTERFLIX.

O MASTERFLIX continua acessível pelo card de status e por um atalho próprio
no menu lateral.

6. RECONEXÃO AUTOMÁTICA
A nova opção de reconexão está ligada ao motor real:
- abertura do app;
- desconexão do listener;
- encerramento normal do serviço;
- reinício do aparelho;
- atualização do APK.

7. NOVO ÍCONE
A v1.16 inclui um novo ícone launcher MASTER RESPONDE com identidade MR,
fundo escuro e destaque azul.

8. PRESERVADO
- Bot liga/desliga;
- WhatsApp Business;
- motor em segundo plano;
- regras privadas;
- Mensagens e Tempos;
- deduplicação;
- teste MASTERFLIX;
- trava contra teste duplicado;
- nova revenda sem adição automática de créditos;
- verificação do e-mail da revenda;
- grupo de suporte;
- categorias de Mídias usadas pelo @infor;
- textos e links;
- credenciais MASTERFLIX criptografadas;
- preenchimento automático do login;
- CAPTCHA/verificação humana continua manual.

VERSÃO:
1.16
versionCode 43
