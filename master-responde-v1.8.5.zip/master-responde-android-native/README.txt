MASTER RESPONDE v1.8.5

Base: v1.8.4.

CORREÇÃO/ADIÇÃO ÚNICA:
LINK EDITÁVEL DO GRUPO DE SUPORTE APÓS ATIVAÇÃO DA REVENDA.

FLUXO:
1. Cliente envia "Quero ser Revenda".
2. Bot envia o link de cadastro.
3. Cliente conclui o cadastro e envia o e-mail usado.
4. Bot encontra a revenda pelo e-mail exato.
5. Adiciona 50 créditos automaticamente.
6. Quando a ativação é concluída, envia:
   - confirmação de painel ativado;
   - informação dos 50 créditos;
   - link do grupo de suporte.

LINK PADRÃO DO GRUPO DE SUPORTE:
https://chat.whatsapp.com/IWHogXDJTem2VgJTJhsTA0?s=cl&p=a&mlu=0&ilr=1

EDIÇÃO MANUAL:
- abra MASTER RESPONDE;
- entre em REVENDAS;
- localize "GRUPO DE SUPORTE";
- altere o link;
- toque em "SALVAR GRUPO DE SUPORTE";
- as próximas ativações passam a usar o novo link.

IMPORTANTE:
- o link não fica preso à mensagem do código;
- o valor salvo em SharedPreferences é usado nas próximas ativações;
- se nunca for alterado, usa o link padrão acima.

PRESERVADO:
- sem etapa CONFIRMAR;
- +50 automático;
- sem leitura de saldo;
- proteção contra clique duplicado;
- correção de loop;
- testes automáticos em segundo plano.
