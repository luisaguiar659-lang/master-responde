MASTER RESPONDE v1.8.10

Base: v1.8.9.

Correção baseada no vídeo real do MASTERFLIX.

A TELA MOSTRADA NO VÍDEO TEM:
- rótulo "Créditos *";
- controle com botão - / campo numérico / botão +;
- checkbox "Use casas decimais" (NÃO deve ser marcado);
- campos Referência e Observação particular;
- checkbox de pagamento manual/offline (NÃO deve ser marcado);
- autorização:
  "Eu concordo em transferir 50 créditos";
- botão final "Adicionar →".

AUTOMAÇÃO v1.8.10:
1. encontra exatamente "Créditos *";
2. localiza o campo entre - e +;
3. coloca 50;
4. confirma que o campo realmente ficou com 50;
5. ignora "Use casas decimais";
6. ignora pagamento manual/offline;
7. encontra especificamente "Eu concordo em transferir 50 créditos";
8. marca somente essa autorização;
9. procura "Adicionar →" somente dentro do mesmo bloco da autorização;
10. grava proteção contra duplicidade;
11. clica uma única vez;
12. aguarda a tela de transferência desaparecer;
13. envia confirmação + grupo de suporte.

PRESERVADO:
- cartão localizado pelo e-mail exato;
- sem pedir CONFIRMAR;
- sem leitura de saldo;
- mensagens intermediárias silenciosas para evitar duplicação;
- links editáveis;
- teste automático em segundo plano.
