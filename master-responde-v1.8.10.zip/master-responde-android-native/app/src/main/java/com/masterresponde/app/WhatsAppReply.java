package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class WhatsAppReply {

    public static boolean send(
            Context context,
            Notification notification,
            String message
    ) {
        if (notification == null
                || message == null
                || message.trim().isEmpty()) {
            return false;
        }

        Notification.Action[] actions =
                notification.actions;

        if (actions == null) {
            return false;
        }

        for (Notification.Action action : actions) {
            if (action == null
                    || action.actionIntent == null) {
                continue;
            }

            RemoteInput[] inputs =
                    action.getRemoteInputs();

            if (inputs == null
                    || inputs.length == 0) {
                continue;
            }

            for (RemoteInput input : inputs) {
                if (input == null
                        || !input.getAllowFreeFormInput()) {
                    continue;
                }

                try {
                    Intent intent =
                            new Intent();

                    Bundle results =
                            new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            context,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }
}
