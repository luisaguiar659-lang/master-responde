package com.masterresponde.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MasterflixActivity extends Activity {

    private static final String LOGIN_URL =
            "https://masterflix.sigmab.pro/#/sign-in";

    private static final String DASHBOARD_URL =
            "https://masterflix.sigmab.pro/#/dashboard";

    private SharedPreferences prefs;
    private SecureStore secureStore;

    private EditText userField;
    private EditText passField;
    private TextView sessionStatus;
    private TextView generationStatus;
    private WebView webView;

    private final Handler automationHandler =
            new Handler(Looper.getMainLooper());

    private boolean autoGenerateRequested = false;
    private boolean generationRunning = false;
    private int findProductAttempts = 0;
    private int findCopyAttempts = 0;
    private int clipboardAttempts = 0;
    private int copyScrollAttempts = 0;
    private boolean loginAssistAttempted = false;
    private volatile String capturedCopyText = "";

    private static final String TEST_PRODUCT =
            "MASTERFLIX TESTE COMPLETO 1H";

    private static final String CLIPBOARD_MARKER =
            "__MASTER_RESPONDE_WAITING__";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences(
                "master_responde",
                MODE_PRIVATE
        );

        secureStore = new SecureStore(this);

        autoGenerateRequested =
                (getIntent() != null
                        && getIntent().getBooleanExtra(
                                "auto_generate_test",
                                false
                        ))
                        || TestTaskBridge.hasPending();

        buildScreen();
        loadSavedCredentials();
        updateSessionStatus();

        if (autoGenerateRequested) {
            updateGenerationStatus(
                    "Preparando geração automática..."
            );
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);

        if (intent != null
                && intent.getBooleanExtra(
                        "auto_generate_test",
                        false
                )) {

            autoGenerateRequested = true;
            generationRunning = false;
            findProductAttempts = 0;
            findCopyAttempts = 0;
            clipboardAttempts = 0;

            updateGenerationStatus(
                    "Preparando geração automática..."
            );

            openDashboard();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("MasterRespondeBridge");
            webView.stopLoading();
            webView.destroy();
        }

        super.onDestroy();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(8), dp(12), dp(8));

        Button back = new Button(this);
        back.setText("←");
        back.setTextColor(Color.WHITE);
        back.setTextSize(24);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v -> finish());
        header.addView(
                back,
                new LinearLayout.LayoutParams(
                        dp(58),
                        dp(54)
                )
        );

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.addView(
                text(
                        "MASTERFLIX",
                        21,
                        Color.WHITE,
                        true
                )
        );
        titleBox.addView(
                text(
                        "Login e sessão do painel",
                        12,
                        Color.rgb(150, 160, 170),
                        false
                )
        );

        header.addView(
                titleBox,
                new LinearLayout.LayoutParams(
                        0,
                        dp(58),
                        1f
                )
        );

        root.addView(header);

        View line = new View(this);
        line.setBackgroundResource(
                getResources().getIdentifier(
                        "line",
                        "drawable",
                        getPackageName()
                )
        );

        root.addView(
                line,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(3)
                )
        );

        ScrollView scroll = new ScrollView(this);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(
                dp(16),
                dp(16),
                dp(16),
                dp(30)
        );

        LinearLayout statusCard = card();

        statusCard.addView(
                text(
                        "SESSÃO",
                        11,
                        Color.rgb(255, 150, 0),
                        true
                )
        );

        sessionStatus = text(
                "● Login necessário",
                16,
                Color.rgb(255, 145, 0),
                true
        );

        sessionStatus.setPadding(
                0,
                dp(8),
                0,
                0
        );

        statusCard.addView(sessionStatus);
        content.addView(statusCard);

        gap(content, 12);

        LinearLayout loginCard = card();

        loginCard.addView(
                text(
                        "CREDENCIAIS",
                        11,
                        Color.rgb(255, 150, 0),
                        true
                )
        );

        userField = field(
                "Usuário ou E-mail"
        );

        loginCard.addView(userField);

        passField = field(
                "Senha"
        );

        passField.setInputType(
                android.text.InputType.TYPE_CLASS_TEXT
                        | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        );

        loginCard.addView(passField);

        Button save = actionButton(
                "SALVAR CREDENCIAIS",
                true
        );

        save.setOnClickListener(
                v -> saveCredentials()
        );

        loginCard.addView(save);

        Button fill = actionButton(
                "PREENCHER LOGIN SALVO",
                false
        );

        fill.setOnClickListener(
                v -> fillSavedLogin()
        );

        loginCard.addView(fill);

        Button clearSession = actionButton(
                "ENCERRAR SESSÃO",
                false
        );

        clearSession.setOnClickListener(
                v -> confirmClearSession()
        );

        loginCard.addView(clearSession);

        content.addView(loginCard);

        gap(content, 12);

        TextView notice = text(
                "A v1.7.3 salva usuário e senha criptografados no aparelho. " +
                "O MASTER RESPONDE pode preencher os campos do login, mas NÃO marca " +
                "“Verificado”, não resolve CAPTCHA e não tenta contornar proteções do painel. " +
                "Quando essa verificação aparecer, conclua manualmente e toque em Continuar.",
                12,
                Color.rgb(150, 160, 170),
                false
        );

        content.addView(notice);

        gap(content, 12);

        LinearLayout browserCard = card();

        LinearLayout browserHeader = new LinearLayout(this);
        browserHeader.setOrientation(LinearLayout.HORIZONTAL);
        browserHeader.setGravity(Gravity.CENTER_VERTICAL);

        browserHeader.addView(
                text(
                        "PAINEL MASTERFLIX",
                        12,
                        Color.WHITE,
                        true
                ),
                new LinearLayout.LayoutParams(
                        0,
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        1f
                )
        );

        Button loginButton = smallButton("LOGIN");
        loginButton.setOnClickListener(
                v -> openLogin()
        );

        browserHeader.addView(loginButton);

        Button dashboardButton = smallButton("PAINEL");
        dashboardButton.setOnClickListener(
                v -> openDashboard()
        );

        browserHeader.addView(dashboardButton);

        browserCard.addView(browserHeader);

        generationStatus = text(
                "Teste: aguardando comando",
                12,
                Color.rgb(0, 184, 255),
                true
        );

        generationStatus.setPadding(
                0,
                dp(10),
                0,
                dp(6)
        );

        browserCard.addView(generationStatus);

        Button generateButton = actionButton(
                "GERAR TESTE COMPLETO 1H",
                true
        );

        generateButton.setOnClickListener(
                v -> requestGenerateTest()
        );

        browserCard.addView(generateButton);

        webView = new WebView(this);

        LinearLayout.LayoutParams webLp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(500)
                );

        webLp.setMargins(
                0,
                dp(10),
                0,
                0
        );

        webView.setLayoutParams(webLp);

        // O MASTERFLIX fica dentro de um ScrollView do app.
        // Sem isso o ScrollView externo pode "roubar" o gesto e
        // impedir a rolagem do próprio painel.
        webView.setVerticalScrollBarEnabled(true);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
        webView.setNestedScrollingEnabled(true);

        webView.setOnTouchListener((view, event) -> {
            int action = event.getActionMasked();

            if (action == android.view.MotionEvent.ACTION_DOWN
                    || action == android.view.MotionEvent.ACTION_MOVE) {

                view.getParent()
                        .requestDisallowInterceptTouchEvent(true);

            } else if (action == android.view.MotionEvent.ACTION_UP
                    || action == android.view.MotionEvent.ACTION_CANCEL) {

                view.getParent()
                        .requestDisallowInterceptTouchEvent(false);
            }

            return false;
        });

        configureWebView();

        browserCard.addView(webView);

        content.addView(browserCard);

        scroll.addView(content);

        root.addView(
                scroll,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        0,
                        1f
                )
        );

        setContentView(root);

        openDashboard();
    }

    private void configureWebView() {
        WebSettings settings =
                webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);

        CookieManager cookieManager =
                CookieManager.getInstance();

        cookieManager.setAcceptCookie(true);

        if (android.os.Build.VERSION.SDK_INT >= 21) {
            cookieManager.setAcceptThirdPartyCookies(
                    webView,
                    true
            );
        }

        webView.addJavascriptInterface(
                new MasterRespondeBridge(),
                "MasterRespondeBridge"
        );

        webView.setWebViewClient(
                new WebViewClient() {

                    @Override
                    public void onPageFinished(
                            WebView view,
                            String url
                    ) {
                        super.onPageFinished(
                                view,
                                url
                        );

                        inspectCurrentLocation();
                        maybeStartAutomation();
                    }

                    @Override
                    public void doUpdateVisitedHistory(
                            WebView view,
                            String url,
                            boolean isReload
                    ) {
                        super.doUpdateVisitedHistory(
                                view,
                                url,
                                isReload
                        );

                        inspectCurrentLocation();
                        maybeStartAutomation();
                    }
                }
        );
    }

    private void inspectCurrentLocation() {
        if (webView == null) return;

        webView.evaluateJavascript(
                "(function(){try{" +
                        "return JSON.stringify({" +
                        "href:location.href," +
                        "path:location.hash||''" +
                        "});" +
                        "}catch(e){return ''}})();",
                value -> {
                    if (value == null) return;

                    String decoded = decodeJavascriptString(
                            value
                    );

                    if (decoded.isEmpty()) return;

                    try {
                        JSONObject object =
                                new JSONObject(decoded);

                        String href =
                                object.optString(
                                        "href",
                                        ""
                                );

                        updateSessionFromUrl(
                                href
                        );

                    } catch (Exception ignored) {
                    }
                }
        );
    }

    private void updateSessionFromUrl(
            String url
    ) {
        if (url == null) return;

        if (url.contains("#/dashboard")) {
            prefs.edit()
                    .putBoolean(
                            "masterflix_session_active",
                            true
                    )
                    .apply();

            runOnUiThread(
                    this::updateSessionStatus
            );

        } else if (url.contains("#/sign-in")) {
            prefs.edit()
                    .putBoolean(
                            "masterflix_session_active",
                            false
                    )
                    .apply();

            runOnUiThread(
                    this::updateSessionStatus
            );
        }
    }

    private void openLogin() {
        webView.loadUrl(LOGIN_URL);
    }

    private void openDashboard() {
        webView.loadUrl(DASHBOARD_URL);
    }

    private void requestGenerateTest() {
        autoGenerateRequested = true;
        generationRunning = false;
        findProductAttempts = 0;
        findCopyAttempts = 0;
        clipboardAttempts = 0;
        copyScrollAttempts = 0;
        loginAssistAttempted = false;
        capturedCopyText = "";

        updateGenerationStatus(
                "Abrindo MASTERFLIX TESTE COMPLETO 1H..."
        );

        openDashboard();

        automationHandler.postDelayed(
                this::maybeStartAutomation,
                900L
        );
    }

    private void maybeStartAutomation() {
        if (!autoGenerateRequested
                || generationRunning
                || webView == null) {
            return;
        }

        String url =
                webView.getUrl();

        if (url == null
                || url.isEmpty()) {
            return;
        }

        if (url.contains("#/sign-in")) {
            updateGenerationStatus(
                    "Login/verificação necessária no MASTERFLIX."
            );

            if (!loginAssistAttempted) {
                loginAssistAttempted = true;

                automationHandler.postDelayed(
                        this::fillSavedLogin,
                        500L
                );
            }

            return;
        }

        if (!url.contains("#/dashboard")) {
            return;
        }

        generationRunning = true;
        findProductAttempts = 0;
        findCopyAttempts = 0;
        clipboardAttempts = 0;
        copyScrollAttempts = 0;
        capturedCopyText = "";

        updateGenerationStatus(
                "Procurando " + TEST_PRODUCT + "..."
        );

        automationHandler.postDelayed(
                this::findAndClickTestProduct,
                900L
        );
    }

    private void findAndClickTestProduct() {
        if (!generationRunning
                || webView == null) {
            return;
        }

        findProductAttempts++;

        String target =
                JSONObject.quote(
                        TEST_PRODUCT
                );

        String script =
                "(function(){" +
                        "function n(v){" +
                        "return (v||'')" +
                        ".replace(/\\\\s+/g,' ')" +
                        ".trim()" +
                        ".toUpperCase();" +
                        "}" +
                        "var wanted=n(" + target + ");" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best=null;" +
                        "var bestLen=999999;" +
                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=n(el.innerText||el.textContent);" +
                        "if(text.indexOf(wanted)!==-1){" +
                        "if(text.length<bestLen){" +
                        "best=el;" +
                        "bestLen=text.length;" +
                        "}" +
                        "}" +
                        "}" +
                        "if(!best){return 'not_found';}" +
                        "try{" +
                        "best.scrollIntoView({" +
                        "behavior:'auto'," +
                        "block:'center'," +
                        "inline:'nearest'" +
                        "});" +
                        "}catch(e){}" +
                        "var clickable=best.closest(" +
                        "'button,a,[role=button],[tabindex],li'" +
                        ");" +
                        "var targetEl=clickable||best;" +
                        "try{" +
                        "targetEl.click();" +
                        "return 'clicked';" +
                        "}catch(e){" +
                        "try{" +
                        "best.dispatchEvent(new MouseEvent(" +
                        "'click'," +
                        "{bubbles:true,cancelable:true,view:window}" +
                        "));" +
                        "return 'clicked';" +
                        "}catch(e2){" +
                        "return 'error';" +
                        "}" +
                        "}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("clicked".equals(result)) {
                        updateGenerationStatus(
                                "Teste localizado e selecionado. Aguardando Detalhes do Cliente..."
                        );

                        clearClipboardMarker();
                        installCopyCaptureHook();

                        automationHandler.postDelayed(
                                this::findAndClickCopyButton,
                                900L
                        );

                        return;
                    }

                    if (findProductAttempts < 30) {
                        updateGenerationStatus(
                                "Procurando o teste no painel... tentativa "
                                        + findProductAttempts
                        );

                        automationHandler.postDelayed(
                                this::findAndClickTestProduct,
                                650L
                        );
                    } else {
                        failGeneration(
                                "Não encontrei " + TEST_PRODUCT + " no painel."
                        );
                    }
                }
        );
    }

    private void findAndClickCopyButton() {
        if (!generationRunning
                || webView == null) {
            return;
        }

        findCopyAttempts++;
        copyScrollAttempts++;

        // 1) Procura COPIAR em todo o DOM.
        // 2) Se ainda não estiver disponível, força a rolagem
        //    de TODOS os contêineres roláveis do painel.
        // 3) Repete até o botão existir.
        String script =
                "(function(){" +
                        "function n(v){" +
                        "return (v||'')" +
                        ".replace(/\\\\s+/g,' ')" +
                        ".trim()" +
                        ".toUpperCase();" +
                        "}" +

                        "function findCopy(){" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best=null;" +
                        "var bestLen=999999;" +
                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=n(el.innerText||el.textContent);" +
                        "if(text==='COPIAR'){" +
                        "if(text.length<bestLen){" +
                        "best=el;" +
                        "bestLen=text.length;" +
                        "}" +
                        "}" +
                        "}" +
                        "return best;" +
                        "}" +

                        "var copy=findCopy();" +

                        "if(copy){" +
                        "try{" +
                        "copy.scrollIntoView({" +
                        "behavior:'auto'," +
                        "block:'center'," +
                        "inline:'nearest'" +
                        "});" +
                        "}catch(e){}" +
                        "return 'found';" +
                        "}" +

                        // Força a rolagem em elementos internos
                        // que usam overflow:auto/scroll.
                        "var scrollables=[];" +
                        "var nodes=document.querySelectorAll('body *');" +
                        "for(var j=0;j<nodes.length;j++){" +
                        "var node=nodes[j];" +
                        "try{" +
                        "var st=getComputedStyle(node);" +
                        "var oy=st.overflowY;" +
                        "if(node.scrollHeight>node.clientHeight+40" +
                        "&&(oy==='auto'||oy==='scroll'||oy==='overlay')){" +
                        "scrollables.push(node);" +
                        "}" +
                        "}catch(e){}" +
                        "}" +

                        "for(var k=0;k<scrollables.length;k++){" +
                        "var box=scrollables[k];" +
                        "var step=Math.max(350,Math.floor(box.clientHeight*0.80));" +
                        "box.scrollTop=Math.min(" +
                        "box.scrollHeight," +
                        "box.scrollTop+step" +
                        ");" +
                        "}" +

                        "try{" +
                        "window.scrollBy(0,Math.max(500,window.innerHeight*0.8));" +
                        "}catch(e){}" +

                        "return 'scrolled';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("found".equals(result)) {
                        updateGenerationStatus(
                                "Botão COPIAR localizado. Rolando até ele..."
                        );

                        automationHandler.postDelayed(
                                this::clickCopyButton,
                                350L
                        );

                        return;
                    }

                    if (findCopyAttempts < 65) {
                        updateGenerationStatus(
                                "Descendo no teste para localizar COPIAR..."
                        );

                        automationHandler.postDelayed(
                                this::findAndClickCopyButton,
                                450L
                        );

                    } else {
                        // Último fallback: tenta extrair o cartão completo
                        // de Detalhes do Cliente sem adivinhar credenciais.
                        extractGeneratedDetailsFromDom();
                    }
                }
        );
    }

    private void clickCopyButton() {
        if (!generationRunning
                || webView == null) {
            return;
        }

        installCopyCaptureHook();

        String script =
                "(function(){" +
                        "function n(v){" +
                        "return (v||'')" +
                        ".replace(/\\\\s+/g,' ')" +
                        ".trim()" +
                        ".toUpperCase();" +
                        "}" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best=null;" +
                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "if(n(el.innerText||el.textContent)==='COPIAR'){" +
                        "best=el;" +
                        "break;" +
                        "}" +
                        "}" +
                        "if(!best){return 'not_found';}" +
                        "try{" +
                        "best.scrollIntoView({behavior:'auto',block:'center'});" +
                        "}catch(e){}" +
                        "var clickable=best.closest(" +
                        "'button,a,[role=button],[tabindex]'" +
                        ")||best;" +
                        "try{" +
                        "clickable.click();" +
                        "return 'clicked';" +
                        "}catch(e){" +
                        "try{" +
                        "best.dispatchEvent(new MouseEvent(" +
                        "'click'," +
                        "{bubbles:true,cancelable:true,view:window}" +
                        "));" +
                        "return 'clicked';" +
                        "}catch(e2){" +
                        "return 'error';" +
                        "}" +
                        "}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("clicked".equals(result)) {
                        updateGenerationStatus(
                                "COPIAR acionado. Capturando o teste..."
                        );

                        clipboardAttempts = 0;

                        automationHandler.postDelayed(
                                this::readGeneratedTestFromClipboard,
                                450L
                        );

                    } else {
                        automationHandler.postDelayed(
                                this::findAndClickCopyButton,
                                350L
                        );
                    }
                }
        );
    }

    private void installCopyCaptureHook() {
        if (webView == null) return;

        String script =
                "(function(){" +
                        "try{" +
                        "if(window.__masterRespondeCopyHookInstalled){" +
                        "return 'already';" +
                        "}" +
                        "window.__masterRespondeCopyHookInstalled=true;" +

                        // Captura navigator.clipboard.writeText.
                        "if(navigator.clipboard&&navigator.clipboard.writeText){" +
                        "var originalWriteText=" +
                        "navigator.clipboard.writeText.bind(navigator.clipboard);" +
                        "navigator.clipboard.writeText=function(text){" +
                        "try{" +
                        "window.MasterRespondeBridge.copiedText(String(text||''));" +
                        "}catch(e){}" +
                        "return originalWriteText(text);" +
                        "};" +
                        "}" +

                        // Captura eventos copy como segunda camada.
                        "document.addEventListener('copy',function(ev){" +
                        "try{" +
                        "var txt='';" +
                        "if(ev.clipboardData){" +
                        "txt=ev.clipboardData.getData('text/plain')||'';" +
                        "}" +
                        "if(!txt&&window.getSelection){" +
                        "txt=String(window.getSelection()||'');" +
                        "}" +
                        "if(txt){" +
                        "window.MasterRespondeBridge.copiedText(txt);" +
                        "}" +
                        "}catch(e){}" +
                        "},true);" +

                        "return 'ok';" +
                        "}catch(e){" +
                        "return 'error';" +
                        "}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                null
        );
    }

    private void clearClipboardMarker() {
        try {
            ClipboardManager manager =
                    (ClipboardManager) getSystemService(
                            Context.CLIPBOARD_SERVICE
                    );

            if (manager != null) {
                manager.setPrimaryClip(
                        ClipData.newPlainText(
                                "MASTER RESPONDE",
                                CLIPBOARD_MARKER
                        )
                );
            }

        } catch (Exception ignored) {
        }
    }

    private void readGeneratedTestFromClipboard() {
        if (!generationRunning) {
            return;
        }

        clipboardAttempts++;

        String value =
                capturedCopyText == null
                        ? ""
                        : capturedCopyText.trim();

        if (value.isEmpty()) {
            value = readClipboardText();
        }

        if (value.isEmpty()
                || CLIPBOARD_MARKER.equals(value)) {

            if (clipboardAttempts < 18) {
                automationHandler.postDelayed(
                        this::readGeneratedTestFromClipboard,
                        350L
                );
            } else {
                extractGeneratedDetailsFromDom();
            }

            return;
        }

        if (!isValidGeneratedTest(value)) {
            failGeneration(
                    "O conteúdo copiado não passou na validação de usuário, senha e M3U."
            );
            return;
        }

        finishGeneratedTest(
                value
        );
    }

    private void extractGeneratedDetailsFromDom() {
        if (!generationRunning
                || webView == null) {
            return;
        }

        updateGenerationStatus(
                "Lendo o bloco completo de Detalhes do Cliente..."
        );

        String script =
                "(function(){" +
                        "function norm(v){" +
                        "return (v||'').replace(/\\\\s+/g,' ').trim();" +
                        "}" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best='';" +
                        "for(var i=0;i<all.length;i++){" +
                        "var text=(all[i].innerText||all[i].textContent||'').trim();" +
                        "if(!text)continue;" +
                        "var low=text.toLowerCase();" +
                        "var hasM3u=low.indexOf('m3u')!==-1||low.indexOf('get.php')!==-1;" +
                        "var hasPass=low.indexOf('senha')!==-1||low.indexOf('password=')!==-1;" +
                        "var hasUser=low.indexOf('usuario')!==-1||low.indexOf('username=')!==-1;" +
                        "if(hasM3u&&hasPass&&hasUser){" +
                        "if(!best||text.length<best.length){" +
                        "best=text;" +
                        "}" +
                        "}" +
                        "}" +
                        "return best;" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String text =
                            decodeJavascriptString(
                                    value
                            ).trim();

                    if (!text.isEmpty()
                            && isValidGeneratedTest(text)) {

                        finishGeneratedTest(
                                text
                        );

                    } else {
                        failGeneration(
                                "Não consegui capturar o conteúdo completo do teste."
                        );
                    }
                }
        );
    }

    private String readClipboardText() {
        try {
            ClipboardManager manager =
                    (ClipboardManager) getSystemService(
                            Context.CLIPBOARD_SERVICE
                    );

            if (manager == null
                    || !manager.hasPrimaryClip()) {
                return "";
            }

            ClipData clip =
                    manager.getPrimaryClip();

            if (clip == null
                    || clip.getItemCount() == 0) {
                return "";
            }

            CharSequence value =
                    clip.getItemAt(0)
                            .coerceToText(this);

            return value == null
                    ? ""
                    : value.toString().trim();

        } catch (Exception e) {
            return "";
        }
    }

    private boolean isValidGeneratedTest(
            String value
    ) {
        if (value == null
                || value.trim().isEmpty()) {
            return false;
        }

        String normalized =
                normalizeText(
                        value
                );

        boolean hasUrl =
                normalized.contains("http://")
                        || normalized.contains("https://");

        boolean hasCredentials =
                (normalized.contains("usuario")
                        && normalized.contains("senha"))
                        || (normalized.contains("username=")
                        && normalized.contains("password="))
                        || (normalized.contains("user:")
                        && (normalized.contains("pass:")
                        || normalized.contains("senha:")));

        boolean hasM3u =
                normalized.contains("m3u")
                        || normalized.contains("get.php")
                        || (normalized.contains("username=")
                        && normalized.contains("password="));

        return hasUrl
                && hasCredentials
                && hasM3u;
    }

    private String normalizeText(
            String value
    ) {
        if (value == null) return "";

        return java.text.Normalizer
                .normalize(
                        value,
                        java.text.Normalizer.Form.NFD
                )
                .replaceAll("\\p{M}", "")
                .toLowerCase(
                        java.util.Locale.ROOT
                );
    }

    private void finishGeneratedTest(
            String fullContent
    ) {
        generationRunning = false;
        autoGenerateRequested = false;

        Notification target =
                TestTaskBridge.getNotification();

        boolean sent = false;

        if (target != null) {
            sent = WhatsAppReply.send(
                    this,
                    target,
                    fullContent
            );
        }

        prefs.edit()
                .putString(
                        "last_test_status",
                        target == null
                                ? "Teste gerado com sucesso"
                                : sent
                                ? "Teste gerado e enviado ao cliente"
                                : "Teste gerado, mas não foi possível enviar"
                )
                .putLong(
                        "last_test_success_time",
                        System.currentTimeMillis()
                )
                .apply();

        if (target != null) {
            TestTaskBridge.complete();
        }

        updateGenerationStatus(
                target == null
                        ? "✅ Teste gerado com sucesso. Conteúdo está no clipboard."
                        : sent
                        ? "✅ Teste gerado e enviado ao WhatsApp."
                        : "⚠️ Teste gerado, mas o envio ao WhatsApp falhou."
        );

        Toast.makeText(
                this,
                target == null
                        ? "Teste gerado com sucesso."
                        : sent
                        ? "Teste enviado ao cliente."
                        : "Teste gerado, mas não enviado.",
                Toast.LENGTH_LONG
        ).show();
    }

    private void failGeneration(
            String reason
    ) {
        generationRunning = false;
        autoGenerateRequested = false;

        Notification target =
                TestTaskBridge.getNotification();

        if (target != null) {
            WhatsAppReply.send(
                    this,
                    target,
                    "Não consegui concluir o teste automaticamente. " +
                            "Confira o MASTERFLIX no MASTER RESPONDE."
            );

            TestTaskBridge.complete();
        }

        prefs.edit()
                .putString(
                        "last_test_status",
                        "Teste: falhou - " + reason
                )
                .apply();

        updateGenerationStatus(
                "⚠️ " + reason
        );
    }

    private void updateGenerationStatus(
            String value
    ) {
        runOnUiThread(
                () -> {
                    if (generationStatus != null) {
                        generationStatus.setText(
                                value
                        );
                    }
                }
        );
    }

    private void saveCredentials() {
        String user =
                userField.getText()
                        .toString()
                        .trim();

        String pass =
                passField.getText()
                        .toString();

        if (user.isEmpty()) {
            userField.setError(
                    "Informe o usuário ou e-mail."
            );
            return;
        }

        if (pass.isEmpty()) {
            passField.setError(
                    "Informe a senha."
            );
            return;
        }

        try {
            secureStore.put(
                    "masterflix_user",
                    user
            );

            secureStore.put(
                    "masterflix_pass",
                    pass
            );

            prefs.edit()
                    .putBoolean(
                            "masterflix_credentials_saved",
                            true
                    )
                    .apply();

            hideKeyboard();

            Toast.makeText(
                    this,
                    "Credenciais salvas com criptografia.",
                    Toast.LENGTH_SHORT
            ).show();

        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "Não foi possível salvar as credenciais.",
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void loadSavedCredentials() {
        String user =
                secureStore.get(
                        "masterflix_user"
                );

        String pass =
                secureStore.get(
                        "masterflix_pass"
                );

        userField.setText(user);
        passField.setText(pass);
    }

    private void fillSavedLogin() {
        final String user =
                secureStore.get(
                        "masterflix_user"
                );

        final String pass =
                secureStore.get(
                        "masterflix_pass"
                );

        if (user.isEmpty()
                || pass.isEmpty()) {

            Toast.makeText(
                    this,
                    "Salve primeiro o usuário e a senha.",
                    Toast.LENGTH_LONG
            ).show();

            return;
        }

        if (webView.getUrl() == null
                || !webView.getUrl()
                .contains("masterflix.sigmab.pro")) {

            openLogin();
        }

        final String userJson =
                JSONObject.quote(user);

        final String passJson =
                JSONObject.quote(pass);

        String script =
                "(function(){" +
                        "var inputs=document.querySelectorAll('input');" +
                        "var user=null,pass=null;" +
                        "for(var i=0;i<inputs.length;i++){" +
                        "var t=(inputs[i].type||'').toLowerCase();" +
                        "if(t==='password'&&!pass){pass=inputs[i];}" +
                        "else if((t==='text'||t==='email'||!t)&&!user){user=inputs[i];}" +
                        "}" +
                        "function set(el,v){" +
                        "if(!el)return false;" +
                        "var setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
                        "setter.call(el,v);" +
                        "el.dispatchEvent(new Event('input',{bubbles:true}));" +
                        "el.dispatchEvent(new Event('change',{bubbles:true}));" +
                        "return true;" +
                        "}" +
                        "return set(user," + userJson + ")&&set(pass," + passJson + ");" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> Toast.makeText(
                        this,
                        "Campos preenchidos. Conclua “Verificado” e toque em Continuar.",
                        Toast.LENGTH_LONG
                ).show()
        );
    }

    private void confirmClearSession() {
        new AlertDialog.Builder(this)
                .setTitle("Encerrar sessão MASTERFLIX?")
                .setMessage(
                        "Os cookies da sessão serão apagados. " +
                        "As credenciais criptografadas continuarão salvas."
                )
                .setNegativeButton(
                        "CANCELAR",
                        null
                )
                .setPositiveButton(
                        "ENCERRAR",
                        (dialog, which) ->
                                clearSession()
                )
                .show();
    }

    private void clearSession() {
        CookieManager.getInstance()
                .removeAllCookies(
                        value -> {
                            CookieManager.getInstance()
                                    .flush();

                            prefs.edit()
                                    .putBoolean(
                                            "masterflix_session_active",
                                            false
                                    )
                                    .apply();

                            updateSessionStatus();
                            openLogin();

                            Toast.makeText(
                                    this,
                                    "Sessão encerrada.",
                                    Toast.LENGTH_SHORT
                            ).show();
                        }
                );
    }

    private void updateSessionStatus() {
        boolean active =
                prefs.getBoolean(
                        "masterflix_session_active",
                        false
                );

        if (active) {
            sessionStatus.setText(
                    "● Sessão ativa"
            );

            sessionStatus.setTextColor(
                    Color.rgb(
                            0,
                            184,
                            255
                    )
            );

        } else {
            sessionStatus.setText(
                    "● Login necessário"
            );

            sessionStatus.setTextColor(
                    Color.rgb(
                            255,
                            145,
                            0
                    )
            );
        }
    }

    private String decodeJavascriptString(
            String value
    ) {
        if (value == null
                || "null".equals(value)) {
            return "";
        }

        try {
            return new org.json.JSONTokener(
                    value
            ).nextValue().toString();

        } catch (Exception e) {
            return "";
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager manager =
                    (InputMethodManager) getSystemService(
                            Context.INPUT_METHOD_SERVICE
                    );

            View current =
                    getCurrentFocus();

            if (manager != null
                    && current != null) {
                manager.hideSoftInputFromWindow(
                        current.getWindowToken(),
                        0
                );
            }

        } catch (Exception ignored) {
        }
    }

    private LinearLayout card() {
        LinearLayout c =
                new LinearLayout(this);

        c.setOrientation(
                LinearLayout.VERTICAL
        );

        c.setPadding(
                dp(15),
                dp(15),
                dp(15),
                dp(15)
        );

        c.setBackgroundResource(
                getResources().getIdentifier(
                        "card",
                        "drawable",
                        getPackageName()
                )
        );

        return c;
    }

    private EditText field(
            String hint
    ) {
        EditText e =
                new EditText(this);

        e.setHint(hint);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(
                Color.rgb(
                        130,
                        140,
                        150
                )
        );

        e.setTextSize(14);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        lp.setMargins(
                0,
                dp(5),
                0,
                dp(8)
        );

        e.setLayoutParams(lp);

        return e;
    }

    private Button actionButton(
            String label,
            boolean orange
    ) {
        Button b =
                new Button(this);

        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setTypeface(null, 1);

        b.setBackgroundResource(
                getResources().getIdentifier(
                        orange
                                ? "button_orange"
                                : "button_dark",
                        "drawable",
                        getPackageName()
                )
        );

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(52)
                );

        lp.setMargins(
                0,
                dp(4),
                0,
                dp(4)
        );

        b.setLayoutParams(lp);

        return b;
    }

    private Button smallButton(
            String label
    ) {
        Button b =
                new Button(this);

        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(10);
        b.setTypeface(null, 1);

        b.setBackgroundResource(
                getResources().getIdentifier(
                        "button_dark",
                        "drawable",
                        getPackageName()
                )
        );

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        dp(82),
                        dp(46)
                );

        lp.setMargins(
                dp(4),
                0,
                0,
                0
        );

        b.setLayoutParams(lp);

        return b;
    }

    private TextView text(
            String value,
            int size,
            int color,
            boolean bold
    ) {
        TextView t =
                new TextView(this);

        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);

        if (bold) {
            t.setTypeface(null, 1);
        }

        return t;
    }

    private void gap(
            LinearLayout parent,
            int height
    ) {
        View v =
                new View(this);

        parent.addView(
                v,
                new LinearLayout.LayoutParams(
                        1,
                        dp(height)
                )
        );
    }

    private int dp(
            int value
    ) {
        return Math.round(
                value
                        * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    public class MasterRespondeBridge {
        @JavascriptInterface
        public void sessionUrl(
                String url
        ) {
            updateSessionFromUrl(
                    url
            );
        }

        @JavascriptInterface
        public void copiedText(
                String value
        ) {
            if (value == null) return;

            String text =
                    value.trim();

            if (!text.isEmpty()) {
                capturedCopyText =
                        text;
            }
        }
    }
}
