package com.masterresponde.app;

import android.app.Notification;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;

public class MasterflixBackgroundAutomation {

    private static final Object LOCK =
            new Object();

    private static MasterflixBackgroundAutomation current;

    private final Context context;
    private final Notification whatsappNotification;
    private final SharedPreferences prefs;
    private final Handler handler =
            new Handler(Looper.getMainLooper());

    private WebView webView;

    private boolean finished = false;
    private boolean dashboardSeen = false;
    private boolean loginAssistAttempted = false;
    private int productAttempts = 0;
    private int autoCaptureAttempts = 0;
    private int scrollAttempts = 0;
    private int copyAttempts = 0;
    private int captureAttempts = 0;

    private volatile String capturedCopyText = "";

    private MasterflixBackgroundAutomation(
            Context context,
            Notification notification,
            SharedPreferences prefs
    ) {
        this.context =
                context.getApplicationContext();

        this.whatsappNotification =
                notification;

        this.prefs =
                prefs;
    }

    public static boolean start(
            Context context,
            Notification notification,
            SharedPreferences prefs
    ) {
        synchronized (LOCK) {
            if (current != null
                    && !current.finished) {
                return false;
            }

            if (!MasterflixAutomationGate.tryAcquire(
                    "test"
            )) {
                return false;
            }

            try {
                current =
                        new MasterflixBackgroundAutomation(
                                context,
                                notification,
                                prefs
                        );

                current.handler.post(
                        current::createAndStart
                );

                return true;

            } catch (Throwable e) {
                MasterflixAutomationGate.release(
                        "test"
                );

                current =
                        null;

                return false;
            }
        }
    }

    public static boolean isRunning() {
        synchronized (LOCK) {
            return current != null
                    && !current.finished;
        }
    }

    private void createAndStart() {
        try {
            updateStatus(
                    "Teste: iniciando "
                            + SigmaPanelConfig.getPanelName(context)
                            + " em segundo plano"
            );

            webView =
                    new WebView(context);

            WebSettings settings =
                    webView.getSettings();

            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setLoadsImagesAutomatically(true);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);

            CookieManager cookieManager =
                    CookieManager.getInstance();

            cookieManager.setAcceptCookie(true);

            if (android.os.Build.VERSION.SDK_INT >= 21) {
                cookieManager.setAcceptThirdPartyCookies(
                        webView,
                        true
                );
            }

            webView.addJavascriptInterface(
                    new Bridge(),
                    "MasterRespondeBridge"
            );

            webView.setWebViewClient(
                    new WebViewClient() {

                        @Override
                        public void onPageFinished(
                                WebView view,
                                String url
                        ) {
                            super.onPageFinished(
                                    view,
                                    url
                            );

                            handleLocation();
                        }

                        @Override
                        public void doUpdateVisitedHistory(
                                WebView view,
                                String url,
                                boolean isReload
                        ) {
                            super.doUpdateVisitedHistory(
                                    view,
                                    url,
                                    isReload
                            );

                            handleLocation();
                        }
                    }
            );

            webView.loadUrl(
                    SigmaPanelConfig.dashboardUrl(
                            context
                    )
            );

            // Segurança contra fluxo preso para sempre.
            handler.postDelayed(
                    () -> {
                        if (!finished
                                && !dashboardSeen) {
                            inspectForSessionTimeout();
                        }
                    },
                    12000L
            );

        } catch (Throwable e) {
            fail(
                    "Não foi possível iniciar o painel Sigma em segundo plano."
            );
        }
    }

    private void handleLocation() {
        if (finished
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (finished) return;

                    if (url.contains("#/dashboard")) {
                        dashboardSeen =
                                true;

                        prefs.edit()
                                .putBoolean(
                                        "masterflix_session_active",
                                        true
                                )
                                .apply();

                        updateStatus(
                                "Teste: sessão "
                                        + SigmaPanelConfig.getPanelName(context)
                                        + " ativa"
                        );

                        if (productAttempts == 0) {
                            handler.postDelayed(
                                    this::findAndClickProduct,
                                    1200L
                            );
                        }

                    } else if (url.contains("#/sign-in")) {

                        prefs.edit()
                                .putBoolean(
                                        "masterflix_session_active",
                                        false
                                )
                                .apply();

                        if (!loginAssistAttempted) {
                            loginAssistAttempted = true;

                            updateStatus(
                                    "Teste: sessão expirada; tentando login salvo"
                            );

                            handler.postDelayed(
                                    () -> MasterflixLoginAssist.fillAndSubmitIfSafe(
                                            context,
                                            webView,
                                            result -> {
                                                if ("verification_required".equals(result)) {
                                                    fail(
                                                            "Login preenchido, mas o painel Sigma exige verificação manual."
                                                    );
                                                    return;
                                                }

                                                if ("no_credentials".equals(result)) {
                                                    fail(
                                                            "Sessão expirada e não há credenciais salvas."
                                                    );
                                                    return;
                                                }

                                                handler.postDelayed(
                                                        this::confirmStillOnLogin,
                                                        2500L
                                                );
                                            }
                                    ),
                                    500L
                            );

                        } else {
                            handler.postDelayed(
                                    this::confirmStillOnLogin,
                                    1800L
                            );
                        }
                    }
                }
        );
    }

    private void confirmStillOnLogin() {
        if (finished
                || dashboardSeen
                || webView == null) {
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (!finished
                            && !dashboardSeen
                            && url.contains("#/sign-in")) {

                        fail(
                                "Sessão do painel Sigma expirada. As credenciais salvas foram tentadas; verifique o login manualmente."
                        );
                    }
                }
        );
    }

    private void inspectForSessionTimeout() {
        if (finished
                || dashboardSeen) {
            return;
        }

        if (webView == null) {
            fail(
                    "O painel Sigma não iniciou em segundo plano."
            );
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return location.href||'';}catch(e){return '';}})();",
                value -> {
                    String url =
                            decodeJavascriptString(
                                    value
                            );

                    if (url.contains("#/sign-in")) {
                        fail(
                                "Sessão do painel Sigma expirada. As credenciais salvas foram tentadas; verifique o login manualmente."
                        );
                    } else if (!dashboardSeen) {
                        fail(
                                "O painel Sigma não carregou o dashboard em segundo plano."
                        );
                    }
                }
        );
    }

    private void findAndClickProduct() {
        if (finished
                || webView == null) {
            return;
        }

        productAttempts++;

        String preferred =
                org.json.JSONObject.quote(
                        SigmaPanelConfig.getPreferredTest(
                                context
                        )
                );

        // A captura precisa estar armada ANTES do clique que gera o teste.
        capturedCopyText =
                "";

        installCopyHook();

        String script =
                "(function(){" +
                        "function n(v){return (v||'').replace(/\\s+/g,' ').trim().toUpperCase();}" +
                        "var wanted=n(" + preferred + ");" +
                        "var all=document.querySelectorAll('body *');" +
                        "var best=null,bestScore=-999999,bestLen=999999;" +
                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=n(el.innerText||el.textContent);" +
                        "if(!text||text.length>240)continue;" +
                        "if(text==='TESTE RÁPIDO'||text==='TESTE RAPIDO'||text==='PESQUISAR')continue;" +
                        "if(text.indexOf('TESTE')===-1)continue;" +
                        "if(text.indexOf('ADICIONAR CLIENTE')!==-1)continue;" +
                        "var score=0;" +
                        "if(wanted&&text.indexOf(wanted)!==-1)score+=10000;" +
                        "if(text.indexOf('COMPLETO')!==-1)score+=500;" +
                        "if(text.indexOf('1H')!==-1)score+=100;" +
                        "score-=text.length;" +
                        "if(score>bestScore||(score===bestScore&&text.length<bestLen)){" +
                        "best=el;bestScore=score;bestLen=text.length;" +
                        "}" +
                        "}" +
                        "if(!best){" +
                        "try{window.scrollBy(0,700);}catch(e){}" +
                        "var nodes=document.querySelectorAll('body *');" +
                        "for(var j=0;j<nodes.length;j++){" +
                        "var x=nodes[j];" +
                        "try{" +
                        "if(x.scrollHeight>x.clientHeight+40){" +
                        "x.scrollTop=Math.min(x.scrollHeight,x.scrollTop+Math.max(400,x.clientHeight*0.8));" +
                        "}" +
                        "}catch(e){}" +
                        "}" +
                        "return 'not_found';" +
                        "}" +
                        "try{best.scrollIntoView({behavior:'auto',block:'center'});}catch(e){}" +
                        "var clickable=best.closest('button,a,[role=button],[tabindex],li')||best;" +
                        "try{clickable.click();return 'clicked';}" +
                        "catch(e){" +
                        "try{best.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));return 'clicked';}" +
                        "catch(e2){return 'error';}" +
                        "}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("clicked".equals(result)) {
                        updateStatus(
                                "Teste: gerando e aguardando cópia automática"
                        );

                        autoCaptureAttempts =
                                0;

                        scrollAttempts =
                                0;

                        copyAttempts =
                                0;

                        handler.postDelayed(
                                this::waitForAutomaticCopy,
                                450L
                        );

                        return;
                    }

                    if (productAttempts < 35) {
                        updateStatus(
                                "Teste: procurando opção disponível no painel Sigma"
                        );

                        handler.postDelayed(
                                this::findAndClickProduct,
                                550L
                        );

                    } else {
                        fail(
                                "Não encontrei uma opção de teste disponível no painel Sigma."
                        );
                    }
                }
        );
    }

    private void installCopyHook() {
        if (finished
                || webView == null) {
            return;
        }

        String script =
                "(function(){" +
                        "try{" +
                        "if(window.__mrCopyHook){return 'ok';}" +
                        "window.__mrCopyHook=true;" +

                        "function send(text){" +
                        "try{" +
                        "text=String(text||'').trim();" +
                        "if(text)window.MasterRespondeBridge.copiedText(text);" +
                        "}catch(e){}" +
                        "}" +

                        "if(navigator.clipboard&&navigator.clipboard.writeText){" +
                        "try{" +
                        "var originalWriteText=navigator.clipboard.writeText.bind(navigator.clipboard);" +
                        "navigator.clipboard.writeText=function(text){" +
                        "send(text);" +
                        "try{return originalWriteText(text);}catch(e){return Promise.resolve();}" +
                        "};" +
                        "}catch(e){}" +
                        "}" +

                        "try{" +
                        "var originalExec=document.execCommand.bind(document);" +
                        "document.execCommand=function(cmd){" +
                        "try{" +
                        "if(String(cmd||'').toLowerCase()==='copy'){" +
                        "var sel='';" +
                        "try{sel=String(window.getSelection?window.getSelection():'');}catch(e){}" +
                        "send(sel);" +
                        "}" +
                        "}catch(e){}" +
                        "return originalExec.apply(document,arguments);" +
                        "};" +
                        "}catch(e){}" +

                        "document.addEventListener('copy',function(ev){" +
                        "try{" +
                        "var txt='';" +
                        "if(ev.clipboardData)txt=ev.clipboardData.getData('text/plain')||'';" +
                        "if(!txt&&window.getSelection)txt=String(window.getSelection()||'');" +
                        "send(txt);" +
                        "}catch(e){}" +
                        "},true);" +

                        "return 'ok';" +
                        "}catch(e){return 'error';}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                null
        );
    }

    private void waitForAutomaticCopy() {
        if (finished
                || webView == null) {
            return;
        }

        autoCaptureAttempts++;

        String value =
                capturedCopyText == null
                        ? ""
                        : cleanupCopiedText(
                                capturedCopyText
                        );

        if (!value.isEmpty()
                && isValidGeneratedTest(
                        value
                )) {
            updateStatus(
                    "Teste: cópia automática capturada"
            );

            success(
                    value
            );

            return;
        }

        // Dá alguns segundos para o próprio Sigma copiar automaticamente
        // após gerar. Se não vier nada, inicia o fallback manual.
        if (autoCaptureAttempts < 14) {
            handler.postDelayed(
                    this::waitForAutomaticCopy,
                    300L
            );
            return;
        }

        updateStatus(
                "Teste: cópia automática não veio; rolando até o fim"
        );

        scrollAttempts =
                0;

        handler.post(
                this::scrollToBottomBeforeCopy
        );
    }

    private void scrollToBottomBeforeCopy() {
        if (finished
                || webView == null) {
            return;
        }

        scrollAttempts++;

        String script =
                "(function(){" +
                        "try{" +
                        "var changed=0;" +
                        "var root=document.scrollingElement||document.documentElement||document.body;" +
                        "if(root){" +
                        "var before=root.scrollTop||0;" +
                        "var max=Math.max(0,(root.scrollHeight||0)-(root.clientHeight||0));" +
                        "root.scrollTop=max;" +
                        "try{window.scrollTo(0,document.body?document.body.scrollHeight:9999999);}catch(e){}" +
                        "if((root.scrollTop||0)>before+2)changed++;" +
                        "}" +
                        "var nodes=document.querySelectorAll('body *');" +
                        "for(var i=0;i<nodes.length;i++){" +
                        "var x=nodes[i];" +
                        "try{" +
                        "if(x.scrollHeight>x.clientHeight+40){" +
                        "var before=x.scrollTop||0;" +
                        "var max=x.scrollHeight-x.clientHeight;" +
                        "x.scrollTop=max;" +
                        "if((x.scrollTop||0)>before+2)changed++;" +
                        "}" +
                        "}catch(e){}" +
                        "}" +
                        "return changed>0?'moved':'bottom';" +
                        "}catch(e){return 'error';}" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("bottom".equals(result)
                            || scrollAttempts >= 8) {
                        updateStatus(
                                "Teste: fim da tela alcançado; procurando COPIAR"
                        );

                        handler.postDelayed(
                                this::findAndClickCopy,
                                350L
                        );

                        return;
                    }

                    updateStatus(
                            "Teste: rolando até o fim da página"
                    );

                    handler.postDelayed(
                            this::scrollToBottomBeforeCopy,
                            280L
                    );
                }
        );
    }

    private void findAndClickCopy() {
        if (finished
                || webView == null) {
            return;
        }

        copyAttempts++;

        installCopyHook();

        String script =
                "(function(){" +
                        "function n(v){return (v||'').replace(/\\s+/g,' ').trim().toUpperCase();}" +
                        "function useful(text){" +
                        "var t=n(text),score=0;" +
                        "if(t.indexOf('DETALHES DO CLIENTE')!==-1)score+=220;" +
                        "if(t.indexOf('USUÁRIO')!==-1||t.indexOf('USUARIO')!==-1||t.indexOf('USERNAME')!==-1)score+=120;" +
                        "if(t.indexOf('SENHA')!==-1||t.indexOf('PASSWORD')!==-1)score+=120;" +
                        "if(t.indexOf('M3U')!==-1||t.indexOf('GET.PHP')!==-1)score+=120;" +
                        "if(t.indexOf('DNS')!==-1)score+=80;" +
                        "if(t.indexOf('VENCIMENTO')!==-1)score+=50;" +
                        "if(t.indexOf('HTTP://')!==-1||t.indexOf('HTTPS://')!==-1)score+=120;" +
                        "return score;" +
                        "}" +
                        "function captureBeforeClose(el){" +
                        "var x=el,best='',bestScore=-1;" +
                        "for(var k=0;k<10&&x&&x!==document.body;k++,x=x.parentElement){" +
                        "var text=(x.innerText||x.textContent||'').trim();" +
                        "if(!text||text.length<40||text.length>12000)continue;" +
                        "var score=useful(text);" +
                        "if(score>bestScore){best=text;bestScore=score;}" +
                        "}" +
                        "if(best&&bestScore>=120){" +
                        "try{window.MasterRespondeBridge.copiedText(best);}catch(e){}" +
                        "}" +
                        "}" +
                        "var all=document.querySelectorAll('button,a,[role=button],[tabindex],body *');" +
                        "var copy=null;" +
                        "for(var i=0;i<all.length;i++){" +
                        "var el=all[i];" +
                        "var text=n(el.innerText||el.textContent);" +
                        "if(text==='COPIAR E FECHAR'||text==='COPIAR'){copy=el;break;}" +
                        "}" +
                        "if(copy){" +
                        "captureBeforeClose(copy);" +
                        "try{copy.scrollIntoView({behavior:'auto',block:'center'});}catch(e){}" +
                        "var clickable=copy.closest('button,a,[role=button],[tabindex]')||copy;" +
                        "try{clickable.click();return 'clicked';}" +
                        "catch(e){" +
                        "try{copy.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));return 'clicked';}" +
                        "catch(e2){return 'error';}" +
                        "}" +
                        "}" +
                        "return 'not_found';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String result =
                            decodeJavascriptString(
                                    value
                            );

                    if ("clicked".equals(result)) {
                        updateStatus(
                                "Teste: botão COPIAR acionado"
                        );

                        captureAttempts =
                                0;

                        handler.postDelayed(
                                this::waitForCapturedText,
                                350L
                        );

                        return;
                    }

                    if (copyAttempts < 20) {
                        updateStatus(
                                "Teste: procurando COPIAR no fim da página"
                        );

                        handler.postDelayed(
                                this::findAndClickCopy,
                                350L
                        );

                    } else {
                        extractDetailsFromDom();
                    }
                }
        );
    }

    private void waitForCapturedText() {
        if (finished) return;

        captureAttempts++;

        String value =
                capturedCopyText == null
                        ? ""
                        : cleanupCopiedText(
                                capturedCopyText
                        );

        if (!value.isEmpty()) {
            if (isValidGeneratedTest(value)) {
                success(value);
            } else {
                extractDetailsFromDom();
            }

            return;
        }

        if (captureAttempts < 18) {
            handler.postDelayed(
                    this::waitForCapturedText,
                    300L
            );
        } else {
            extractDetailsFromDom();
        }
    }

    private void extractDetailsFromDom() {
        if (finished
                || webView == null) {
            return;
        }

        updateStatus(
                "Teste: lendo somente Detalhes do Cliente"
        );

        String script =
                "(function(){" +
                        "function n(v){return (v||'').replace(/\\s+/g,' ').trim().toUpperCase();}" +
                        "function valid(text){" +
                        "var t=n(text);" +
                        "var signals=0;" +
                        "if(t.indexOf('HTTP://')!==-1||t.indexOf('HTTPS://')!==-1)signals++;" +
                        "if(t.indexOf('USUÁRIO')!==-1||t.indexOf('USUARIO')!==-1||t.indexOf('USERNAME')!==-1)signals++;" +
                        "if(t.indexOf('SENHA')!==-1||t.indexOf('PASSWORD')!==-1)signals++;" +
                        "if(t.indexOf('M3U')!==-1||t.indexOf('GET.PHP')!==-1)signals++;" +
                        "if(t.indexOf('DNS')!==-1)signals++;" +
                        "if(t.indexOf('VENCIMENTO')!==-1)signals++;" +
                        "return signals>=3;" +
                        "}" +
                        "var candidates=[];" +
                        "var selectors='[role=dialog],.modal,.modal-content,.dialog,.drawer,.card,[class*=modal],[class*=dialog]';" +
                        "try{candidates=Array.prototype.slice.call(document.querySelectorAll(selectors));}catch(e){}" +
                        "var best='';" +
                        "for(var i=0;i<candidates.length;i++){" +
                        "var el=candidates[i];" +
                        "var text=(el.innerText||el.textContent||'').trim();" +
                        "if(!text)continue;" +
                        "var t=n(text);" +
                        "if(t.indexOf('DETALHES DO CLIENTE')===-1)continue;" +
                        "if(!valid(text))continue;" +
                        "if(text.length>12000)continue;" +
                        "if(!best||text.length<best.length)best=text;" +
                        "}" +
                        "if(best)return best;" +

                        // Fallback ainda restrito: começa no texto 'Detalhes do Cliente'
                        // e sobe poucos níveis, nunca chegando ao body.
                        "var all=document.querySelectorAll('body *');" +
                        "for(var j=0;j<all.length;j++){" +
                        "var node=all[j];" +
                        "var nt=n(node.innerText||node.textContent);" +
                        "if(nt!=='DETALHES DO CLIENTE')continue;" +
                        "var x=node.parentElement;" +
                        "for(var k=0;k<5&&x&&x!==document.body;k++,x=x.parentElement){" +
                        "var text=(x.innerText||x.textContent||'').trim();" +
                        "if(text&&text.length<12000&&valid(text))return text;" +
                        "}" +
                        "}" +
                        "return '';" +
                        "})();";

        webView.evaluateJavascript(
                script,
                value -> {
                    String text =
                            decodeJavascriptString(
                                    value
                            ).trim();

                    if (!text.isEmpty()
                            && isValidGeneratedTest(
                                    text
                            )) {

                        success(
                                cleanupCopiedText(
                                        text
                                )
                        );

                    } else {
                        fail(
                                "O teste foi gerado, mas não consegui capturar o texto do botão COPIAR."
                        );
                    }
                }
        );
    }

    private String cleanupCopiedText(
            String value
    ) {
        if (value == null) {
            return "";
        }

        String text =
                value.replace(
                        "\r",
                        ""
                );

        StringBuilder out =
                new StringBuilder();

        String[] lines =
                text.split(
                        "\n"
                );

        for (String raw : lines) {
            String line =
                    raw == null
                            ? ""
                            : raw.trim();

            if (line.isEmpty()) {
                continue;
            }

            String normalized =
                    normalizeText(
                            line
                    );

            if ("copiar".equals(normalized)
                    || "copiar e fechar".equals(normalized)
                    || "fechar".equals(normalized)
                    || "cancelar".equals(normalized)
                    || "detalhes do cliente".equals(normalized)) {
                continue;
            }

            if (out.length() > 0) {
                out.append(
                        '\n'
                );
            }

            out.append(
                    line
            );
        }

        return out.toString()
                .trim();
    }

    private boolean isValidGeneratedTest(
            String value
    ) {
        if (value == null
                || value.trim().isEmpty()) {
            return false;
        }

        String normalized =
                normalizeText(value);

        boolean hasUrl =
                normalized.contains("http://")
                        || normalized.contains("https://");

        boolean hasUser =
                normalized.contains("usuario")
                        || normalized.contains("username=")
                        || normalized.contains("user:");

        boolean hasPass =
                normalized.contains("senha")
                        || normalized.contains("password=")
                        || normalized.contains("pass:");

        boolean hasM3u =
                normalized.contains("m3u")
                        || normalized.contains("get.php");

        return hasUrl
                && hasUser
                && hasPass
                && hasM3u;
    }

    private void success(
            String fullContent
    ) {
        if (finished) return;

        finished =
                true;

        // Limpa a pendência antes de responder no WhatsApp.
        // Assim a própria atualização da notificação causada pelo envio
        // não pode ser interpretada como uma tarefa antiga a recuperar.
        BackgroundRuntime.clearTestPending(
                prefs
        );

        TestTaskBridge.complete();

        boolean sent =
                WhatsAppReply.send(
                        context,
                        whatsappNotification,
                        fullContent
                );

        prefs.edit()
                .putString(
                        "last_test_status",
                        sent
                                ? "Teste gerado em segundo plano e enviado"
                                : "Teste gerado em segundo plano, mas envio falhou"
                )
                .putLong(
                        "last_test_success_time",
                        System.currentTimeMillis()
                )
                .apply();

        cleanup();
    }

    private void fail(
            String reason
    ) {
        if (finished) return;

        finished =
                true;

        prefs.edit()
                .putString(
                        "last_test_status",
                        "Teste: " + reason
                )
                .apply();

        MessageSettings.send(
                context,
                whatsappNotification,
                prefs,
                MessageSettings.MSG_TEST_FAIL,
                MessageSettings.DEFAULT_TEST_FAIL
        );

        TestTaskBridge.complete();

        cleanup();
    }

    private void cleanup() {
        handler.post(
                () -> {
                    try {
                        if (webView != null) {
                            webView.removeJavascriptInterface(
                                    "MasterRespondeBridge"
                            );

                            webView.stopLoading();
                            webView.loadUrl(
                                    "about:blank"
                            );

                            webView.destroy();
                            webView =
                                    null;
                        }

                    } catch (Throwable ignored) {
                    }

                    BackgroundRuntime.clearTestPending(
                            prefs
                    );

                    MasterflixAutomationGate.release(
                            "test"
                    );

                    synchronized (LOCK) {
                        if (current == this) {
                            current =
                                    null;
                        }
                    }
                }
        );
    }

    private void updateStatus(
            String value
    ) {
        prefs.edit()
                .putString(
                        "last_test_status",
                        value
                )
                .apply();
    }

    private String decodeJavascriptString(
            String value
    ) {
        if (value == null
                || "null".equals(value)) {
            return "";
        }

        try {
            Object decoded =
                    new org.json.JSONTokener(
                            value
                    ).nextValue();

            return decoded == null
                    ? ""
                    : decoded.toString();

        } catch (Exception e) {
            return "";
        }
    }

    private String normalizeText(
            String value
    ) {
        if (value == null) return "";

        return Normalizer
                .normalize(
                        value,
                        Normalizer.Form.NFD
                )
                .replaceAll("\\p{M}", "")
                .toLowerCase(
                        Locale.ROOT
                );
    }

    public class Bridge {

        @JavascriptInterface
        public void copiedText(
                String value
        ) {
            if (value == null) return;

            String text =
                    value.trim();

            if (!text.isEmpty()) {
                capturedCopyText =
                        cleanupCopiedText(
                                text
                        );
            }
        }
    }
}
