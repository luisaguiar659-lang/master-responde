MASTER RESPONDE v1.17.6

CORREÇÃO DO TESTE AUTOMÁTICO

Base: v1.17.5.

Fluxo implementado:
1. O interceptador de cópia é instalado ANTES de clicar no teste.
2. O bot aciona a geração.
3. Aguarda alguns segundos pela cópia automática do próprio painel Sigma.
4. Se receber um teste válido, envia imediatamente ao WhatsApp.
5. Se a cópia automática não vier, o bot força a rolagem até o final da página
   e de todos os contêineres roláveis.
6. Só depois de alcançar o fim procura COPIAR ou COPIAR E FECHAR.
7. Clica no botão encontrado.
8. Captura e valida o conteúdo.
9. Se ainda não houver clipboard, mantém somente o fallback restrito a
   Detalhes do Cliente, nunca ao Dashboard inteiro.

A rolagem não é mais um scrollBy simples. Ela tenta colocar a janela e cada
contêiner rolável em scrollHeight-clientHeight até estabilizar no fim.

NÃO ALTERADO
- revenda
- @infor
- regras
- mídias/links
- mensagens e tempos
- painel Sigma genérico
- login automático
- assinatura release permanente

VERSÃO
1.17.6
versionCode 50
