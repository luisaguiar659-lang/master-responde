MASTER RESPONDE v1.5.1

Base: v1.5 funcionando no aparelho.

CORREÇÕES:
- Intervalo entre respostas de categoria reduzido de 1,2 s para cerca de 0,4 s.
- Comando direto no mesmo @infor:
  @infor 1
  @infor 2
  @infor planos
  @infor tutoriais
  @infor aplicativos
  @infor banners
  @infor avisos
  @infor apresentação
- @infor sozinho continua mostrando o menu.
- Depois de @infor, o menu permanece aberto por 2 minutos.
- Nesse período você pode escolher 1, depois 2, depois 3 sem mandar @infor de novo.
- Ajustada a identificação do grupo para não depender do nome do remetente.

Nenhuma função nova foi adicionada além dessas correções.
