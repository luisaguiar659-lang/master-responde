package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Normalizer;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class NotificationAccessService extends NotificationListenerService {

    private static final String WHATSAPP_BUSINESS = "com.whatsapp.w4b";

    private static final Map<String, Long> RECENT = new ConcurrentHashMap<>();
    private static final Map<String, Long> GROUP_MENU_OPEN = new ConcurrentHashMap<>();
    private static final Object SEND_LOCK = new Object();

    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final long GROUP_MENU_TIMEOUT = 120000L;
    private static final long SEQUENCE_DELAY = 400L;

    private static final String[] GROUP_CATEGORIES = new String[]{
            "Tutoriais",
            "Promoções e Planos",
            "Aplicativos Parceiros",
            "Banners",
            "Avisos",
            "Apresentação do Servidor"
    };

    private static final String GROUP_MENU =
            "🤖 *MASTER RESPONDE — CENTRAL DE SUPORTE*\n\n" +
            "1️⃣ Tutoriais\n" +
            "2️⃣ Promoções e Planos\n" +
            "3️⃣ Aplicativos Parceiros\n" +
            "4️⃣ Banners\n" +
            "5️⃣ Avisos\n" +
            "6️⃣ Apresentação do Servidor\n" +
            "7️⃣ Solicitar 50 Créditos\n" +
            "8️⃣ Gerar Teste\n" +
            "0️⃣ Falar com Suporte\n\n" +
            "Atalhos diretos:\n" +
            "@infor 1\n" +
            "@infor planos\n" +
            "@infor tutoriais";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null) return;
        if (!WHATSAPP_BUSINESS.equals(sbn.getPackageName())) return;

        SharedPreferences prefs = getSharedPreferences("master_responde", MODE_PRIVATE);
        if (!prefs.getBoolean("bot_enabled", false)) return;

        Notification notification = sbn.getNotification();
        if (notification == null || notification.extras == null) return;

        CharSequence value = notification.extras.getCharSequence(Notification.EXTRA_TEXT);
        if (value == null) return;

        String incoming = normalize(value.toString());
        if (incoming.isEmpty()) return;

        String notificationKey = sbn.getKey() == null ? "no-key" : sbn.getKey();

        boolean isGroup = notification.extras.getBoolean(
                Notification.EXTRA_IS_GROUP_CONVERSATION,
                false
        );

        if (isGroup) {
            handleGroup(notification, notificationKey, incoming, prefs);
        } else {
            handlePrivate(notification, notificationKey, incoming, prefs);
        }
    }

    private void handleGroup(
            Notification notification,
            String notificationKey,
            String incoming,
            SharedPreferences prefs
    ) {
        String groupKey = groupConversationKey(notification);

        if ("@infor".equals(incoming)) {
            GROUP_MENU_OPEN.put(groupKey, System.currentTimeMillis());

            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "group_menu|" + groupKey,
                    incoming,
                    GROUP_MENU
            );
            return;
        }

        // Permite executar direto no mesmo comando:
        // @infor 1 / @infor planos / @infor tutoriais...
        if (incoming.startsWith("@infor ")) {
            String command = incoming.substring("@infor ".length()).trim();

            executeGroupCommand(
                    notification,
                    notificationKey,
                    command,
                    prefs
            );

            GROUP_MENU_OPEN.put(groupKey, System.currentTimeMillis());
            return;
        }

        // Mantém o menu aberto para várias escolhas seguidas sem novo @infor.
        Long openedAt = GROUP_MENU_OPEN.get(groupKey);
        if (openedAt == null) return;

        if (System.currentTimeMillis() - openedAt > GROUP_MENU_TIMEOUT) {
            GROUP_MENU_OPEN.remove(groupKey);
            return;
        }

        if (isRecognizedGroupCommand(incoming)) {
            executeGroupCommand(
                    notification,
                    notificationKey,
                    incoming,
                    prefs
            );

            GROUP_MENU_OPEN.put(groupKey, System.currentTimeMillis());
        }
    }

    private boolean isRecognizedGroupCommand(String command) {
        String c = normalize(command);

        return c.equals("0")
                || c.equals("1")
                || c.equals("2")
                || c.equals("3")
                || c.equals("4")
                || c.equals("5")
                || c.equals("6")
                || c.equals("7")
                || c.equals("8")
                || c.contains("tutorial")
                || c.contains("plano")
                || c.contains("promoc")
                || c.contains("aplicativo")
                || c.equals("apps")
                || c.contains("banner")
                || c.contains("aviso")
                || c.contains("apresent")
                || c.contains("credito")
                || c.contains("teste")
                || c.contains("suporte");
    }

    private void executeGroupCommand(
            Notification notification,
            String notificationKey,
            String command,
            SharedPreferences prefs
    ) {
        String c = normalize(command);
        int option = resolveGroupOption(c);

        if (option >= 1 && option <= 6) {
            String categoryName = GROUP_CATEGORIES[option - 1];

            JSONArray responses = categoryResponsesByName(
                    prefs,
                    categoryName
            );

            if (responses.length() == 0) {
                sendSingleWithProtection(
                        notification,
                        notificationKey,
                        "group_missing|" + option,
                        c,
                        "⚠️ A categoria \"" + categoryName +
                                "\" ainda não foi configurada no MASTER RESPONDE."
                );
            } else {
                sendSequenceWithProtection(
                        notification,
                        notificationKey,
                        "group_category|" + option,
                        c,
                        responses
                );
            }

            return;
        }

        if (option == 7 || option == 8) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "group_future|" + option,
                    c,
                    "🔒 Essa opção será liberada nas próximas etapas do MASTER RESPONDE."
            );
            return;
        }

        if (option == 0) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "group_support",
                    c,
                    "👤 Um atendente continuará o suporte."
            );
            return;
        }

        sendSingleWithProtection(
                notification,
                notificationKey,
                "group_unknown",
                c,
                "⚠️ Opção não reconhecida. Envie @infor para ver o menu."
        );
    }

    private int resolveGroupOption(String command) {
        String c = normalize(command);

        if ("1".equals(c) || c.contains("tutorial")) return 1;
        if ("2".equals(c) || c.contains("plano") || c.contains("promoc")) return 2;

        if ("3".equals(c)
                || c.contains("aplicativo")
                || "apps".equals(c)
                || c.contains("app parceiro")) {
            return 3;
        }

        if ("4".equals(c) || c.contains("banner")) return 4;
        if ("5".equals(c) || c.contains("aviso")) return 5;
        if ("6".equals(c) || c.contains("apresent")) return 6;
        if ("7".equals(c) || c.contains("credito")) return 7;
        if ("8".equals(c) || c.contains("teste")) return 8;
        if ("0".equals(c) || c.contains("suporte")) return 0;

        return -1;
    }

    private void handlePrivate(
            Notification notification,
            String notificationKey,
            String incoming,
            SharedPreferences prefs
    ) {
        if ("teste bot".equals(incoming)) {
            sendSingleWithProtection(
                    notification,
                    notificationKey,
                    "fixed_test",
                    incoming,
                    "✅ MASTER RESPONDE ativo e funcionando."
            );
            return;
        }

        try {
            JSONArray rules = new JSONArray(
                    prefs.getString("text_rules", "[]")
            );

            for (int i = 0; i < rules.length(); i++) {
                JSONObject rule = rules.optJSONObject(i);
                if (rule == null) continue;

                String trigger = normalize(
                        rule.optString("trigger", "")
                );

                boolean exact = rule.optBoolean("exact", false);
                if (trigger.isEmpty()) continue;

                boolean match = exact
                        ? incoming.equals(trigger)
                        : incoming.contains(trigger);

                if (!match) continue;

                String ruleId = rule.optString("id", String.valueOf(i));
                String categoryId = rule.optString("category_id", "");

                if (!categoryId.isEmpty()) {
                    JSONArray responses = categoryResponsesById(
                            prefs,
                            categoryId
                    );

                    if (responses.length() > 0) {
                        sendSequenceWithProtection(
                                notification,
                                notificationKey,
                                "category_rule|" + ruleId,
                                incoming,
                                responses
                        );
                    }

                    return;
                }

                String response = rule.optString("reply", "").trim();

                if (!response.isEmpty()) {
                    sendSingleWithProtection(
                            notification,
                            notificationKey,
                            "rule|" + ruleId,
                            incoming,
                            response
                    );
                }

                return;
            }

        } catch (Exception ignored) {
        }
    }

    private String groupConversationKey(Notification notification) {
        CharSequence conversation = notification.extras.getCharSequence(
                Notification.EXTRA_CONVERSATION_TITLE
        );

        if (conversation != null && conversation.length() > 0) {
            return normalize(conversation.toString());
        }

        // Evita usar EXTRA_TITLE, pois em alguns aparelhos ele muda com o remetente.
        return "grupo";
    }

    private JSONArray categoryResponsesById(
            SharedPreferences prefs,
            String categoryId
    ) {
        try {
            JSONArray categories = new JSONArray(
                    prefs.getString("text_categories", "[]")
            );

            for (int i = 0; i < categories.length(); i++) {
                JSONObject category = categories.optJSONObject(i);
                if (category == null) continue;

                if (!categoryId.equals(category.optString("id"))) continue;

                return cleanResponses(
                        category.optJSONArray("responses")
                );
            }

        } catch (Exception ignored) {
        }

        return new JSONArray();
    }

    private JSONArray categoryResponsesByName(
            SharedPreferences prefs,
            String categoryName
    ) {
        try {
            JSONArray categories = new JSONArray(
                    prefs.getString("text_categories", "[]")
            );

            String wanted = normalize(categoryName);

            for (int i = 0; i < categories.length(); i++) {
                JSONObject category = categories.optJSONObject(i);
                if (category == null) continue;

                String name = normalize(
                        category.optString("name", "")
                );

                if (!wanted.equals(name)) continue;

                return cleanResponses(
                        category.optJSONArray("responses")
                );
            }

        } catch (Exception ignored) {
        }

        return new JSONArray();
    }

    private JSONArray cleanResponses(JSONArray responses) {
        JSONArray result = new JSONArray();

        if (responses == null) return result;

        for (int i = 0; i < responses.length(); i++) {
            JSONObject response = responses.optJSONObject(i);
            if (response == null) continue;

            String text = response.optString("text", "").trim();

            if (!text.isEmpty()) {
                result.put(text);
            }
        }

        return result;
    }

    private void sendSingleWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            String message
    ) {
        String fingerprint =
                notificationKey + "|" + ruleKey + "|" + incoming;

        if (!reserveFingerprint(fingerprint)) return;

        boolean sent = reply(notification, message);

        updateStatus(
                sent
                        ? "Última autoresposta: enviada"
                        : "Última autoresposta: não disponível"
        );
    }

    private void sendSequenceWithProtection(
            Notification notification,
            String notificationKey,
            String ruleKey,
            String incoming,
            JSONArray messages
    ) {
        String fingerprint =
                notificationKey + "|" + ruleKey + "|" + incoming;

        if (!reserveFingerprint(fingerprint)) return;

        updateStatus(
                "Última sequência: iniciada com " +
                        messages.length() +
                        " respostas"
        );

        int lastIndex = messages.length() - 1;

        for (int i = 0; i < messages.length(); i++) {
            final String message = messages.optString(i, "").trim();
            if (message.isEmpty()) continue;

            final boolean last = i == lastIndex;
            long delay = i * SEQUENCE_DELAY;

            handler.postDelayed(
                    () -> {
                        boolean sent = reply(notification, message);

                        if (!sent) {
                            updateStatus(
                                    "Última sequência: envio interrompido"
                            );
                        } else if (last) {
                            updateStatus(
                                    "Última sequência: concluída"
                            );
                        }
                    },
                    delay
            );
        }
    }

    private boolean reserveFingerprint(String fingerprint) {
        synchronized (SEND_LOCK) {
            long now = System.currentTimeMillis();

            Long memoryTime = RECENT.get(fingerprint);

            if (memoryTime != null && now - memoryTime < 10000L) {
                return false;
            }

            SharedPreferences prefs = getSharedPreferences(
                    "master_responde",
                    MODE_PRIVATE
            );

            String last = prefs.getString(
                    "last_rule_fingerprint",
                    ""
            );

            long lastTime = prefs.getLong(
                    "last_rule_fingerprint_time",
                    0L
            );

            if (fingerprint.equals(last) && now - lastTime < 10000L) {
                RECENT.put(fingerprint, now);
                return false;
            }

            RECENT.put(fingerprint, now);

            prefs.edit()
                    .putString(
                            "last_rule_fingerprint",
                            fingerprint
                    )
                    .putLong(
                            "last_rule_fingerprint_time",
                            now
                    )
                    .commit();

            if (RECENT.size() > 250) {
                RECENT.clear();
                RECENT.put(fingerprint, now);
            }

            return true;
        }
    }

    private void updateStatus(String value) {
        getSharedPreferences(
                "master_responde",
                MODE_PRIVATE
        )
                .edit()
                .putString(
                        "last_test_status",
                        value
                )
                .apply();
    }

    private boolean reply(
            Notification notification,
            String message
    ) {
        Notification.Action[] actions = notification.actions;
        if (actions == null) return false;

        for (Notification.Action action : actions) {
            if (action == null || action.actionIntent == null) continue;

            RemoteInput[] inputs = action.getRemoteInputs();
            if (inputs == null || inputs.length == 0) continue;

            for (RemoteInput input : inputs) {
                if (input == null) continue;
                if (!input.getAllowFreeFormInput()) continue;

                try {
                    Intent intent = new Intent();
                    Bundle results = new Bundle();

                    results.putCharSequence(
                            input.getResultKey(),
                            message
                    );

                    RemoteInput.addResultsToIntent(
                            new RemoteInput[]{input},
                            intent,
                            results
                    );

                    action.actionIntent.send(
                            this,
                            0,
                            intent
                    );

                    return true;

                } catch (PendingIntent.CanceledException e) {
                    return false;
                }
            }
        }

        return false;
    }

    private String normalize(String value) {
        if (value == null) return "";

        return Normalizer
                .normalize(
                        value,
                        Normalizer.Form.NFD
                )
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }
}
