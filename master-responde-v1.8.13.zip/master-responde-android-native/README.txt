MASTER RESPONDE v1.8.13

Base: v1.8.12.

MUDANÇA PRINCIPAL:
A ativação de NOVA REVENDA não usa mais o WebView oculto para adicionar créditos.

AGORA A AUTOMAÇÃO USA A TELA ORIGINAL E VISÍVEL DO MASTERFLIX:
1. recebe o e-mail do cliente;
2. abre MASTERFLIX em tela cheia;
3. entra em Revendas;
4. usa somente o campo Pesquisar para buscar o e-mail;
5. espera o cartão da revenda aparecer;
6. dentro do mesmo cartão encontra "Adicionar Créditos";
7. abre a tela original "Adicionar Créditos";
8. procura exclusivamente o controle − [campo] +;
9. coloca 50;
10. espera "Eu concordo em transferir 50 créditos";
11. marca somente essa autorização;
12. procura o botão final "Adicionar";
13. grava a proteção contra duplicidade;
14. clica UMA ÚNICA VEZ;
15. aguarda a tela de transferência fechar;
16. envia confirmação + link configurável do grupo de suporte.

IMPORTANTE:
- o fluxo de TESTE continua funcionando em segundo plano como antes;
- somente a NOVA REVENDA passa a usar a tela visível do MASTERFLIX;
- o MASTERFLIX continua em tela cheia;
- se o Android impedir a abertura automática quando o app estiver totalmente em segundo plano,
  basta abrir MASTER RESPONDE: a tarefa pendente é retomada automaticamente;
- CAPTCHA/Verificado continuam manuais e nunca são contornados.

PRESERVADO:
- sem pedir CONFIRMAR;
- sem leitura de saldo;
- +50 fixo;
- proteção contra clique duplicado;
- link de cadastro editável;
- link do grupo de suporte editável;
- correção contra mensagens duplicadas;
- regras, categorias e @infor.
