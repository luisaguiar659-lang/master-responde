MASTER RESPONDE v1.0 - ETAPA 1

Objetivo:
- Compilar
- Instalar
- Abrir
- Mostrar o dashboard

Nesta versão NÃO existem:
- automação WhatsApp
- MASTERFLIX
- regras
- mídias
- fila
- revendas

Essas funções serão adicionadas apenas depois de a base estar confirmada no aparelho.
