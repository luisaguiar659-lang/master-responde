package com.masterresponde.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private LinearLayout content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7, 9, 11));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(16), dp(10), dp(16), dp(10));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier(
                "logo_master_responde", "drawable", getPackageName()));
        header.addView(logo, new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(10), 0, 0, 0);
        titles.addView(text("MASTER RESPONDE", 21, Color.WHITE, true));
        titles.addView(text("Central inteligente de atendimento", 12,
                Color.rgb(150, 160, 170), false));
        header.addView(titles, new LinearLayout.LayoutParams(0, dp(62), 1f));

        root.addView(header);

        View line = new View(this);
        line.setBackgroundResource(getResources().getIdentifier(
                "line", "drawable", getPackageName()));
        root.addView(line, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(3)));

        ScrollView scroll = new ScrollView(this);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(18), dp(16), dp(40));

        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);

        buildDashboard();
    }

    private void buildDashboard() {
        content.removeAllViews();

        LinearLayout hero = card();
        hero.addView(text("MASTER RESPONDE", 24, Color.WHITE, true));
        hero.addView(text("Dashboard v1.0", 14,
                Color.rgb(255, 150, 0), true));
        hero.addView(text(
                "Primeira etapa do projeto: interface base funcionando.",
                13, Color.rgb(170, 180, 190), false));
        content.addView(hero);

        gap(16);

        section("STATUS");

        GridLayout statusGrid = new GridLayout(this);
        statusGrid.setColumnCount(2);

        addStatus(statusGrid, "Bot", "Em breve", Color.rgb(0, 184, 255));
        addStatus(statusGrid, "MASTERFLIX", "Em breve", Color.rgb(255, 145, 0));
        addStatus(statusGrid, "WhatsApp Business", "Em breve", Color.rgb(0, 184, 255));
        addStatus(statusGrid, "Fila", "0 aguardando", Color.rgb(255, 145, 0));

        content.addView(statusGrid);

        gap(18);

        section("ATALHOS");

        GridLayout shortcuts = new GridLayout(this);
        shortcuts.setColumnCount(2);

        addButton(shortcuts, "Gerar teste", true);
        addButton(shortcuts, "Nova revenda", false);
        addButton(shortcuts, "Créditos +50", true);
        addButton(shortcuts, "@infor grupos", false);

        content.addView(shortcuts);

        gap(18);

        section("MÓDULOS");

        GridLayout modules = new GridLayout(this);
        modules.setColumnCount(2);

        addButton(modules, "Regras", false);
        addButton(modules, "Mídias", false);
        addButton(modules, "Revendas", false);
        addButton(modules, "Grupos", false);
        addButton(modules, "Histórico", false);
        addButton(modules, "Configurações", false);

        content.addView(modules);

        gap(20);

        content.addView(text(
                "Nesta versão os botões são apenas visuais. " +
                "As funções serão adicionadas uma por vez nas próximas versões.",
                12, Color.rgb(135, 145, 155), false));
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackgroundResource(getResources().getIdentifier(
                "card", "drawable", getPackageName()));
        return c;
    }

    private void addStatus(GridLayout parent, String title, String value, int accent) {
        LinearLayout c = card();

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = dp(100);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        c.setLayoutParams(lp);

        c.addView(text(title, 12, Color.rgb(145, 155, 165), false));

        TextView v = text("● " + value, 16, accent, true);
        v.setPadding(0, dp(10), 0, 0);
        c.addView(v);

        parent.addView(c);
    }

    private void addButton(GridLayout parent, String label, boolean orange) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setTypeface(null, 1);
        b.setBackgroundResource(getResources().getIdentifier(
                orange ? "button_orange" : "button_dark",
                "drawable", getPackageName()));

        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0;
        lp.height = dp(58);
        lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        b.setLayoutParams(lp);

        parent.addView(b);
    }

    private void section(String value) {
        TextView t = text(value, 12, Color.rgb(255, 150, 0), true);
        t.setLetterSpacing(0.08f);
        t.setPadding(0, 0, 0, dp(8));
        content.addView(t);
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private void gap(int height) {
        View v = new View(this);
        content.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
