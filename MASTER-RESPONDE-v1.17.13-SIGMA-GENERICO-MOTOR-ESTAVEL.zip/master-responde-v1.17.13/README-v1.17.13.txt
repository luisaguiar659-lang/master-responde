MASTER RESPONDE v1.17.13

Correção Sigma genérico mantendo o motor de teste estável da v1.17.12.

- Remove URL fixa do MASTERFLIX no motor em segundo plano.
- Usa SigmaPanelConfig.dashboardUrl(context) do painel atualmente salvo.
- Remove produto fixo MASTERFLIX TESTE COMPLETO 1H.
- Usa o teste preferido do painel Sigma e, se vazio, procura uma opção de teste disponível.
- Mantém o motor antigo de COPIAR/captura que funcionou na v1.17.12.
- Mantém a correção de encerramento do loop de testes.
- versionName 1.17.13
- versionCode 57
