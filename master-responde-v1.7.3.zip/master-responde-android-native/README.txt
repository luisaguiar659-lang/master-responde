MASTER RESPONDE v1.7.3

Base: v1.7.2 aprovada com o aplicativo aberto.

CORREÇÃO PRINCIPAL:
GERAÇÃO DE TESTE COM O APP FECHADO / EM SEGUNDO PLANO.

Problema:
- o NotificationListenerService recebia "Teste";
- enviava "Gerando seu teste, aguarde...";
- mas Android podia impedir a abertura automática da Activity MASTERFLIX
  quando o app estava em segundo plano.

Mudança da v1.7.3:
- o pedido recebido pelo WhatsApp não tenta mais abrir a Activity;
- o NotificationListenerService inicia um WebView de automação em segundo plano;
- esse WebView compartilha os cookies/sessão do MASTERFLIX já salvos pelo app;
- procura MASTERFLIX TESTE COMPLETO 1H;
- gera o teste;
- desce pelos contêineres da página;
- localiza COPIAR;
- intercepta o texto enviado pelo próprio botão COPIAR;
- valida usuário/senha/M3U;
- responde ao mesmo WhatsApp.

IMPORTANTE:
- se a sessão MASTERFLIX estiver ativa, o fluxo pode funcionar sem a tela do app aberta;
- se a sessão estiver expirada, aparecer login, Verificado ou CAPTCHA,
  a automação NÃO tenta contornar essa verificação;
- nesse caso o app informa falha e é necessário abrir MASTER RESPONDE
  para renovar a sessão manualmente.

TESTE:
1. Abra MASTER RESPONDE uma vez e confirme MASTERFLIX = Sessão ativa.
2. Volte para a tela inicial do celular.
3. NÃO deixe o MASTER RESPONDE aberto na tela.
4. De outro WhatsApp envie:
   Teste
5. Deve receber:
   Gerando seu teste, aguarde...
6. Não deve ser necessário abrir a tela MASTERFLIX.
7. Aguarde o bloco completo do teste chegar no mesmo WhatsApp.

O botão GERAR TESTE dentro do aplicativo continua usando a tela visível
para testes manuais.

Ainda não inclui:
- nova revenda;
- créditos +50.
