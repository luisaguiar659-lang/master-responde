package com.masterresponde.app;

import android.app.Notification;
import android.app.RemoteInput;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;
import java.util.Map;

public class WhatsAppNotificationService extends NotificationListenerService {
    private static final String WA_BUSINESS = "com.whatsapp.w4b";
    private final Map<String, Long> seen = new HashMap<>();

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || !WA_BUSINESS.equals(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        if (n == null) return;

        ReplyTarget target = replyTarget(n);
        if (target == null) return;

        Data d = data(n);
        if (d == null || d.text == null || d.text.trim().length() == 0) return;

        String fingerprint = sbn.getKey() + "|" + d.conversation + "|" + d.sender + "|" + d.text;
        long now = System.currentTimeMillis();
        Long old = seen.get(fingerprint);
        if (old != null && now - old < 5000L) return;
        if (seen.size() > 300) seen.clear();
        seen.put(fingerprint, now);

        BotEngine.Incoming in = new BotEngine.Incoming();
        in.text = d.text;
        in.group = d.group;
        in.label = d.group ? d.conversation + " • " + d.sender : d.conversation;
        in.key = d.group ? "G|" + d.conversation + "|" + d.sender : "P|" + d.conversation;
        in.reply = target;
        BotEngine.handle(getApplicationContext(), in);
    }

    private ReplyTarget replyTarget(Notification n) {
        if (n.actions == null) return null;
        for (Notification.Action a : n.actions) {
            if (a == null || a.actionIntent == null) continue;
            RemoteInput[] inputs = a.getRemoteInputs();
            if (inputs == null) continue;
            for (RemoteInput input : inputs) {
                if (input != null && input.getAllowFreeFormInput()) return new ReplyTarget(a, input);
            }
        }
        return null;
    }

    private Data data(Notification n) {
        Bundle e = n.extras;
        if (e == null) return null;

        Data d = new Data();
        d.group = e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false);

        CharSequence conv = e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
        CharSequence title = e.getCharSequence(Notification.EXTRA_TITLE);
        d.conversation = conv != null ? conv.toString() : title != null ? title.toString() : "WhatsApp";

        Parcelable[] messages = e.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (messages != null && messages.length > 0) {
            Parcelable p = messages[messages.length - 1];
            if (p instanceof Bundle) {
                Notification.MessagingStyle.Message m =
                        Notification.MessagingStyle.Message.getMessageFromBundle((Bundle)p);
                if (m != null) {
                    CharSequence t = m.getText();
                    d.text = t == null ? "" : t.toString();
                    if (android.os.Build.VERSION.SDK_INT >= 28 && m.getSenderPerson() != null) {
                        CharSequence s = m.getSenderPerson().getName();
                        d.sender = s == null ? d.conversation : s.toString();
                    } else {
                        CharSequence s = m.getSender();
                        d.sender = s == null ? d.conversation : s.toString();
                    }
                    return d;
                }
            }
        }

        CharSequence t = e.getCharSequence(Notification.EXTRA_TEXT);
        d.text = t == null ? "" : t.toString();
        d.sender = d.group && title != null ? title.toString() : d.conversation;
        return d;
    }

    private static class Data {
        String text;
        String sender;
        String conversation;
        boolean group;
    }
}
