package com.masterresponde.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class ReplyTarget {
    private final Notification.Action action;
    private final RemoteInput input;

    public ReplyTarget(Notification.Action action, RemoteInput input) {
        this.action = action;
        this.input = input;
    }

    public boolean text(Context c, String value) {
        try {
            Intent intent = new Intent();
            Bundle b = new Bundle();
            b.putCharSequence(input.getResultKey(), value);
            RemoteInput.addResultsToIntent(new RemoteInput[]{input}, intent, b);
            action.actionIntent.send(c, 0, intent);
            return true;
        } catch (PendingIntent.CanceledException e) {
            return false;
        }
    }

    public boolean media(Context c, Uri uri, String mime) {
        try {
            Set<String> allowed = input.getAllowedDataTypes();
            if (allowed == null || allowed.size() == 0) return false;
            boolean ok = allowed.contains(mime);
            if (!ok && mime.startsWith("image/")) ok = allowed.contains("image/*");
            if (!ok && mime.startsWith("video/")) ok = allowed.contains("video/*");
            if (!ok && mime.startsWith("audio/")) ok = allowed.contains("audio/*");
            if (!ok) return false;

            Intent intent = new Intent();
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Map<String, Uri> data = new HashMap<>();
            data.put(mime, uri);
            RemoteInput.addDataResultToIntent(input, intent, data);
            action.actionIntent.send(c, 0, intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
