package com.masterresponde.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.Locale;

public class PanelService extends Service {
    private static final String CHANNEL = "master_responde_panel";
    private static final int NOTIF = 4401;
    private static final String SIGNIN = "https://masterflix.sigmab.pro/#/sign-in";
    private static final String DASH = "https://masterflix.sigmab.pro/#/dashboard";
    private static final String RESELLERS = "https://masterflix.sigmab.pro/#/resellers";

    private WebView web;
    private JSONObject current;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean injected = false;
    private boolean running = false;
    private int loginAttempts = 0;

    public static void start(Context c) {
        Intent i = new Intent(c, PanelService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    @Override public void onCreate() {
        super.onCreate();
        Store.defaults(this);
        channel();

        android.app.Notification notification;
        if (Build.VERSION.SDK_INT >= 26) {
            notification = new android.app.Notification.Builder(this, CHANNEL)
                    .setSmallIcon(android.R.drawable.stat_notify_sync)
                    .setContentTitle("MASTER RESPONDE")
                    .setContentText("Processando fila MASTERFLIX")
                    .setOngoing(true).build();
        } else {
            notification = new android.app.Notification.Builder(this)
                    .setSmallIcon(android.R.drawable.stat_notify_sync)
                    .setContentTitle("MASTER RESPONDE")
                    .setContentText("Processando fila MASTERFLIX")
                    .setOngoing(true).build();
        }
        startForeground(NOTIF, notification);

        web = new WebView(getApplicationContext());
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);

        web.addJavascriptInterface(new Bridge(), "MRBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                main.postDelayed(new Runnable() {
                    @Override public void run() { route(); }
                }, 900L);
            }
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) next();
        return START_NOT_STICKY;
    }

    private void next() {
        current = Store.dequeue(this);
        if (current == null) {
            running = false;
            stopForeground(true);
            stopSelf();
            return;
        }
        running = true;
        injected = false;
        loginAttempts = 0;
        String type = current.optString("type");
        web.loadUrl("CREDIT".equals(type) ? RESELLERS : DASH);
        main.postDelayed(new Runnable() {
            @Override public void run() {
                if (running && current != null) fail("TIMEOUT", "O painel demorou demais para responder.");
            }
        }, 90000L);
    }

    private void route() {
        if (!running || current == null) return;
        String url = web.getUrl();
        String u = url == null ? "" : url.toLowerCase(Locale.ROOT);

        if (u.contains("sign-in") || u.endsWith("sigmab.pro/")) {
            login();
            return;
        }

        Store.panelConnected(this, true);
        if (injected) return;
        injected = true;

        if ("TEST".equals(current.optString("type"))) {
            web.evaluateJavascript(testScript(), null);
        } else {
            web.evaluateJavascript(creditScript(current.optString("email")), null);
        }
    }

    private void login() {
        if (!Store.hasPanelLogin(this)) {
            fail("NO_LOGIN", "Configure o login do MASTERFLIX no aplicativo.");
            return;
        }
        if (loginAttempts >= 3) {
            fail("LOGIN_FAILED", "Não foi possível entrar no MASTERFLIX.");
            return;
        }
        loginAttempts++;
        injected = false;
        web.evaluateJavascript(loginScript(Store.panelUser(this), Store.panelPass(this)), null);
        main.postDelayed(new Runnable() {
            @Override public void run() {
                if (!running || current == null) return;
                String url = web.getUrl();
                if (url != null && url.toLowerCase(Locale.ROOT).contains("sign-in")) {
                    route();
                } else {
                    web.loadUrl("CREDIT".equals(current.optString("type")) ? RESELLERS : DASH);
                }
            }
        }, 4500L);
    }

    private void finish(boolean ok, String code, String payload) {
        if (current == null) return;
        JSONObject done = current;
        current = null;
        running = false;
        if (!ok) Store.panelConnected(this, false);

        RuntimeHub.panelResult(
                this,
                done.optString("id"),
                done.optString("contactKey"),
                done.optString("contactLabel"),
                done.optString("type"),
                done.optString("email"),
                done.optBoolean("initial"),
                ok, payload, code
        );
        main.postDelayed(new Runnable() {
            @Override public void run() { next(); }
        }, 500L);
    }

    private void fail(String code, String text) { finish(false, code, text); }
    private void success(String text) { finish(true, "OK", text); }

    private void channel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "Automação MASTERFLIX", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        if (web != null) {
            web.stopLoading();
            web.destroy();
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    public class Bridge {
        @JavascriptInterface public void post(final String raw) {
            main.post(new Runnable() {
                @Override public void run() {
                    try {
                        JSONObject o = new JSONObject(raw);
                        if ("success".equals(o.optString("type"))) success(o.optString("data"));
                        else fail(o.optString("code"), o.optString("data"));
                    } catch (Exception e) {
                        fail("BRIDGE", "Resposta inválida do painel.");
                    }
                }
            });
        }
    }

    private String loginScript(String user, String pass) {
        return "(function(){const USER=" + JSONObject.quote(user) +
                ",PASS=" + JSONObject.quote(pass) + ";" + helpers() +
                "let n=0,t=setInterval(()=>{n++;const ins=[...document.querySelectorAll('input')]," +
                "u=ins.find(i=>/usuario|usuário|email|e-mail/i.test((i.placeholder||'')+' '+(i.name||'')))||ins.find(i=>i.type==='text'||i.type==='email')," +
                "p=ins.find(i=>i.type==='password');if(!u||!p){if(n>50){clearInterval(t);post('error','LOGIN_FIELDS','Campos de login não encontrados.')}return}" +
                "setv(u,USER);setv(p,PASS);const cb=ins.find(i=>i.type==='checkbox');if(cb&&!cb.checked)cb.click();" +
                "const b=[...document.querySelectorAll('button')].find(x=>norm(x.innerText).includes('continuar'));" +
                "if(!b){clearInterval(t);post('error','LOGIN_BUTTON','Botão Continuar não encontrado.');return}" +
                "clearInterval(t);b.click();},300);})();true;";
    }

    private String testScript() {
        return "(function(){" + helpers() +
                "let sent=false;function deliver(v){if(sent||!v)return;sent=true;post('success','TEST',String(v));}" +
                "try{if(navigator.clipboard&&navigator.clipboard.writeText){const old=navigator.clipboard.writeText.bind(navigator.clipboard);" +
                "navigator.clipboard.writeText=function(v){deliver(v);try{return old(v)}catch(e){return Promise.resolve()}}}}catch(e){}" +
                "let n=0,t=setInterval(()=>{n++;const els=[...document.querySelectorAll('button,a,div,span')]," +
                "x=els.find(e=>norm(e.innerText).includes('masterflix teste completo 1h'));" +
                "if(!x){if(n>70){clearInterval(t);post('error','TEST_OPTION','Teste MASTERFLIX 1H não encontrado.')}return}" +
                "clearInterval(t);(x.closest('button,a')||x).click();" +
                "let m=0,q=setInterval(()=>{m++;const all=[...document.querySelectorAll('body *')]," +
                "box=all.find(e=>norm(e.innerText).includes('detalhes do cliente')&&norm(e.innerText).includes('copiar'));" +
                "if(!box){if(m>80){clearInterval(q);post('error','TEST_DETAILS','Detalhes do teste não apareceram.')}return}" +
                "const copy=[...box.querySelectorAll('button,a')].find(b=>norm(b.innerText)==='copiar');" +
                "if(copy){clearInterval(q);copy.click();setTimeout(()=>{if(!sent){const v=box.innerText||'';" +
                "if(/senha/i.test(v)&&/m3u/i.test(v)&&/usu[aá]rio/i.test(v))deliver(v);" +
                "else post('error','TEST_COPY','Conteúdo do teste não pôde ser validado.')}},1200)}},350);},350);})();true;";
    }

    private String creditScript(String email) {
        return "(function(){const EMAIL=" + JSONObject.quote(email == null ? "" : email.toLowerCase(Locale.ROOT)) + ";" +
                helpers() +
                "function credits(el){const m=(el.innerText||'').match(/cr[eé]ditos\\s*:?\\s*(\\d+)/i);return m?parseInt(m[1],10):null}" +
                "let n=0,t=setInterval(()=>{n++;const input=[...document.querySelectorAll('input')].find(i=>norm(i.placeholder).includes('pesquisar'));" +
                "if(!input){if(n>60){clearInterval(t);post('error','SEARCH','Campo Pesquisar não encontrado.')}return}" +
                "setv(input,EMAIL);clearInterval(t);" +
                "let r=0,w=setInterval(()=>{r++;const e=[...document.querySelectorAll('body *')].find(x=>norm(x.innerText)===norm(EMAIL));" +
                "if(!e){if(r>60){clearInterval(w);post('error','NOT_FOUND','Revenda não encontrada.')}return}" +
                "let card=e;for(let i=0;card&&i<10;i++,card=card.parentElement){if(/cr[eé]ditos/i.test(card.innerText||''))break}" +
                "if(!card){clearInterval(w);post('error','CARD','Cartão da revenda não encontrado.');return}" +
                "const before=credits(card);if(before===null){clearInterval(w);post('error','BALANCE','Saldo não pôde ser lido.');return}" +
                "let plus=[...card.querySelectorAll('button')].find(b=>(b.innerText||'').trim()==='+');" +
                "if(!plus){plus=[...card.querySelectorAll('button')].find(b=>norm((b.title||'')+' '+(b.getAttribute('aria-label')||'')).includes('credito'))}" +
                "if(!plus){clearInterval(w);post('error','PLUS','Botão + não encontrado.');return}" +
                "clearInterval(w);plus.click();" +
                "let z=0,modal=setInterval(()=>{z++;const nodes=[...document.querySelectorAll('body *')]," +
                "box=nodes.find(x=>norm(x.innerText).includes('adicionar creditos')&&norm(x.innerText).includes('transferir'));" +
                "if(!box){if(z>60){clearInterval(modal);post('error','MODAL','Janela de créditos não abriu.')}return}" +
                "if(!norm(box.innerText).includes(norm(EMAIL))){clearInterval(modal);post('error','EMAIL_MISMATCH','E-mail da revenda não confere.');return}" +
                "const amount=[...box.querySelectorAll('input')].find(i=>i.type==='number'||label(i).includes('credito'));" +
                "if(!amount){clearInterval(modal);post('error','AMOUNT','Campo de créditos não encontrado.');return}" +
                "setv(amount,'50');const cb=box.querySelector('input[type=checkbox]');if(cb&&!cb.checked)cb.click();" +
                "const add=[...box.querySelectorAll('button')].find(b=>norm(b.innerText)==='adicionar');" +
                "if(!add){clearInterval(modal);post('error','ADD','Botão Adicionar não encontrado.');return}" +
                "clearInterval(modal);add.click();" +
                "let k=0,verify=setInterval(()=>{k++;const en=[...document.querySelectorAll('body *')].find(x=>norm(x.innerText)===norm(EMAIL));" +
                "if(en){let c=en;for(let i=0;c&&i<10;i++,c=c.parentElement){if(/cr[eé]ditos/i.test(c.innerText||''))break}" +
                "if(c){const after=credits(c);if(after===before+50){clearInterval(verify);post('success','CREDIT','Saldo anterior: '+before+' | Saldo atual: '+after);return}}}" +
                "if(k>70){clearInterval(verify);post('error','UNCERTAIN','Transferência enviada, mas o saldo final não foi confirmado. Não repetir automaticamente.')}},450);},350);},350);},350);})();true;";
    }

    private String helpers() {
        return "function post(type,code,data){try{MRBridge.post(JSON.stringify({type:type,code:code,data:data}))}catch(e){}}" +
                "function norm(v){return(v||'').normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').toLowerCase().trim()}" +
                "function setv(el,v){const p=Object.getPrototypeOf(el),d=Object.getOwnPropertyDescriptor(p,'value');if(d&&d.set)d.set.call(el,v);else el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))}" +
                "function label(el){let s='',p=el;for(let i=0;p&&i<4;i++,p=p.parentElement)s+=' '+(p.innerText||'');return norm(s)}";
    }
}
