package com.masterresponde.app;

import org.json.JSONObject;

public class BotRule {
    public String id = "";
    public String trigger = "";
    public String category = "";
    public String target = "BOTH";
    public boolean exact = false;
    public boolean enabled = true;

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("trigger", trigger);
            o.put("category", category);
            o.put("target", target);
            o.put("exact", exact);
            o.put("enabled", enabled);
        } catch (Exception ignored) {}
        return o;
    }

    public static BotRule fromJson(JSONObject o) {
        BotRule r = new BotRule();
        r.id = o.optString("id");
        r.trigger = o.optString("trigger");
        r.category = o.optString("category");
        r.target = o.optString("target", "BOTH");
        r.exact = o.optBoolean("exact", false);
        r.enabled = o.optBoolean("enabled", true);
        return r;
    }
}
