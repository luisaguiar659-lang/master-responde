package com.masterresponde.app;

import org.json.JSONObject;

public class ResponseItem {
    public static final String TEXT = "TEXT";
    public static final String IMAGE = "IMAGE";
    public static final String VIDEO = "VIDEO";
    public static final String AUDIO = "AUDIO";

    public String id = "";
    public String category = "";
    public String type = TEXT;
    public String title = "";
    public String value = "";
    public int order = 0;
    public boolean enabled = true;

    public JSONObject toJson() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", id);
            o.put("category", category);
            o.put("type", type);
            o.put("title", title);
            o.put("value", value);
            o.put("order", order);
            o.put("enabled", enabled);
        } catch (Exception ignored) {}
        return o;
    }

    public static ResponseItem fromJson(JSONObject o) {
        ResponseItem i = new ResponseItem();
        i.id = o.optString("id");
        i.category = o.optString("category");
        i.type = o.optString("type", TEXT);
        i.title = o.optString("title");
        i.value = o.optString("value");
        i.order = o.optInt("order", 0);
        i.enabled = o.optBoolean("enabled", true);
        return i;
    }
}
