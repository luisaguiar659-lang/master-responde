package com.masterresponde.app;

import android.content.Context;

import org.json.JSONObject;

import java.text.Normalizer;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class BotEngine {
    private static final String WAIT_RESELLER_EMAIL = "WAIT_RESELLER_EMAIL";
    private static final String WAIT_CREDIT_EMAIL = "WAIT_CREDIT_EMAIL";
    private static final String WAIT_CONFIRM = "WAIT_CONFIRM";
    private static final String GROUP_MENU = "GROUP_MENU";

    public static class Incoming {
        public String text;
        public String key;
        public String label;
        public boolean group;
        public ReplyTarget reply;
    }

    public static void handle(Context c, Incoming in) {
        Store.defaults(c);
        if (!Store.bot(c) || in == null || in.reply == null) return;
        String msg = norm(in.text);
        if (msg.length() == 0) return;

        RuntimeHub.remember(in.key, in.reply);
        String state = Store.state(c, in.key);

        if (!in.group && WAIT_RESELLER_EMAIL.equals(state)) {
            if (email(in.text)) {
                in.reply.text(c, "Localizando seu cadastro, aguarde...");
                Store.clearState(c, in.key);
                enqueuePanel(c, "CREDIT", in, in.text.trim().toLowerCase(Locale.ROOT), true);
            } else {
                in.reply.text(c, Store.get(c, "msg_email", "Envie o e-mail cadastrado."));
            }
            return;
        }

        if (!in.group && WAIT_CREDIT_EMAIL.equals(state)) {
            if (email(in.text)) {
                Store.link(c, in.key, in.text.trim().toLowerCase(Locale.ROOT));
                Store.state(c, in.key, WAIT_CONFIRM);
                in.reply.text(c, Store.get(c, "msg_confirm", "Digite CONFIRMAR."));
            } else {
                in.reply.text(c, Store.get(c, "msg_email", "Envie o e-mail cadastrado."));
            }
            return;
        }

        if (!in.group && WAIT_CONFIRM.equals(state)) {
            if ("confirmar".equals(msg)) {
                String e = Store.linked(c, in.key);
                if (e.length() == 0) {
                    Store.state(c, in.key, WAIT_CREDIT_EMAIL);
                    in.reply.text(c, Store.get(c, "msg_email", "Envie o e-mail cadastrado."));
                } else {
                    Store.clearState(c, in.key);
                    in.reply.text(c, "Adicionando 50 créditos, aguarde...");
                    enqueuePanel(c, "CREDIT", in, e, false);
                }
            }
            return;
        }

        if (in.group) {
            String cmd = norm(Store.get(c, "group_command", "@infor"));
            if (msg.startsWith(cmd)) {
                String rest = msg.substring(cmd.length()).trim();
                if (rest.length() == 0) {
                    Store.state(c, in.key, GROUP_MENU);
                    in.reply.text(c, Store.get(c, "group_menu", "MASTER RESPONDE"));
                    return;
                }
                if (rest.contains("tutorial")) { RuntimeHub.sendCategory(c, in.key, Store.CAT_TUTORIALS); return; }
                if (rest.contains("plano") || rest.contains("promoc")) { RuntimeHub.sendCategory(c, in.key, Store.CAT_PLANS); return; }
                if (rest.contains("app")) { RuntimeHub.sendCategory(c, in.key, Store.CAT_APPS); return; }
                if (rest.contains("banner")) { RuntimeHub.sendCategory(c, in.key, Store.CAT_BANNERS); return; }
                if (rest.contains("aviso")) { RuntimeHub.sendCategory(c, in.key, Store.CAT_ALERTS); return; }
                if (rest.contains("apresent")) { RuntimeHub.sendCategory(c, in.key, Store.CAT_PRESENT); return; }
                if (rest.contains("credito") || rest.contains("teste")) {
                    in.reply.text(c, Store.get(c, "msg_private", "Envie no privado."));
                    return;
                }
            }

            if (GROUP_MENU.equals(state)) {
                Store.clearState(c, in.key);
                if ("1".equals(msg)) RuntimeHub.sendCategory(c, in.key, Store.CAT_TUTORIALS);
                else if ("2".equals(msg)) RuntimeHub.sendCategory(c, in.key, Store.CAT_PLANS);
                else if ("3".equals(msg)) RuntimeHub.sendCategory(c, in.key, Store.CAT_APPS);
                else if ("4".equals(msg)) RuntimeHub.sendCategory(c, in.key, Store.CAT_BANNERS);
                else if ("5".equals(msg)) RuntimeHub.sendCategory(c, in.key, Store.CAT_ALERTS);
                else if ("6".equals(msg)) RuntimeHub.sendCategory(c, in.key, Store.CAT_PRESENT);
                else if ("7".equals(msg) || "8".equals(msg)) in.reply.text(c, Store.get(c, "msg_private", "Envie no privado."));
                else if ("0".equals(msg)) in.reply.text(c, Store.get(c, "msg_support", "Um atendente continuará."));
                return;
            }
        } else {
            if (matches(msg, Store.get(c, "test_triggers", ""))) {
                test(c, in);
                return;
            }
            if (matches(msg, Store.get(c, "reseller_triggers", ""))) {
                in.reply.text(c, Store.get(c, "msg_reseller", "Faça o cadastro e envie seu e-mail."));
                Store.state(c, in.key, WAIT_RESELLER_EMAIL);
                return;
            }
            if (matches(msg, Store.get(c, "credit_triggers", ""))) {
                credits(c, in);
                return;
            }
        }

        List<BotRule> rules = Store.rules(c);
        for (BotRule r : rules) {
            if (!r.enabled) continue;
            if (in.group && "PRIVATE".equals(r.target)) continue;
            if (!in.group && "GROUP".equals(r.target)) continue;
            String t = norm(r.trigger);
            boolean hit = r.exact ? msg.equals(t) : msg.contains(t);
            if (hit) {
                RuntimeHub.sendCategory(c, in.key, r.category);
                Store.history(c, "REGRA", in.label, r.trigger, true);
                return;
            }
        }
    }

    private static void test(Context c, Incoming in) {
        int hours = Math.max(0, Store.getInt(c, "test_limit_hours", 0));
        if (hours > 0) {
            long last = Store.lastTest(c, in.key);
            long window = hours * 60L * 60L * 1000L;
            if (last > 0 && System.currentTimeMillis() - last < window) {
                in.reply.text(c, Store.get(c, "msg_test_limit", "Teste recente."));
                return;
            }
        }
        in.reply.text(c, Store.get(c, "msg_test_wait", "Gerando seu teste, aguarde..."));
        enqueuePanel(c, "TEST", in, "", false);
    }

    private static void credits(Context c, Incoming in) {
        String e = Store.linked(c, in.key);
        if (e.length() == 0) {
            Store.state(c, in.key, WAIT_CREDIT_EMAIL);
            in.reply.text(c, Store.get(c, "msg_email", "Envie o e-mail cadastrado."));
        } else {
            Store.state(c, in.key, WAIT_CONFIRM);
            in.reply.text(c, Store.get(c, "msg_confirm", "Digite CONFIRMAR."));
        }
    }

    private static void enqueuePanel(Context c, String type, Incoming in, String email, boolean initial) {
        try {
            JSONObject o = new JSONObject();
            o.put("id", UUID.randomUUID().toString());
            o.put("type", type);
            o.put("contactKey", in.key);
            o.put("contactLabel", in.label);
            o.put("email", email == null ? "" : email);
            o.put("initial", initial);
            Store.enqueue(c, o);
            PanelService.start(c);
        } catch (Exception e) {
            Store.history(c, "FILA", in.label, e.getMessage(), false);
        }
    }

    private static boolean email(String v) {
        return v != null && v.trim().matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    }

    private static boolean matches(String msg, String csv) {
        if (csv == null) return false;
        for (String x : csv.split(",")) {
            String t = norm(x);
            if (t.length() > 0 && (msg.equals(t) || msg.contains(t))) return true;
        }
        return false;
    }

    private static String norm(String v) {
        if (v == null) return "";
        return Normalizer.normalize(v, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT).trim();
    }
}
