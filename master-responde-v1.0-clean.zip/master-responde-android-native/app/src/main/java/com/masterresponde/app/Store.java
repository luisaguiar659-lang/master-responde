package com.masterresponde.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class Store {
    public static final String CAT_TUTORIALS = "Tutoriais";
    public static final String CAT_PLANS = "Promoções e Planos";
    public static final String CAT_APPS = "Aplicativos Parceiros";
    public static final String CAT_BANNERS = "Banners";
    public static final String CAT_ALERTS = "Avisos";
    public static final String CAT_PRESENT = "Apresentação do Servidor";

    public static final String[] CATEGORIES = {
            CAT_TUTORIALS, CAT_PLANS, CAT_APPS,
            CAT_BANNERS, CAT_ALERTS, CAT_PRESENT
    };

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences("master_responde", Context.MODE_PRIVATE);
    }

    public static void defaults(Context c) {
        if (p(c).getBoolean("defaults", false)) return;
        p(c).edit()
                .putBoolean("defaults", true)
                .putBoolean("bot", false)
                .putBoolean("panel_connected", false)
                .putString("group_command", "@infor")
                .putString("test_triggers", "teste,quero um teste,teste gratis,me libera um teste")
                .putString("reseller_triggers", "quero ser revenda,quero ser uma revenda")
                .putString("credit_triggers", "creditos,solicitar creditos,quero creditos")
                .putInt("test_limit_hours", 0)
                .putString("msg_test_wait", "Gerando seu teste, aguarde...")
                .putString("msg_test_limit", "Você já recebeu um teste recentemente.")
                .putString("msg_reseller",
                        "Faça seu cadastro de revenda neste link:\\n" +
                        "https://masterflix.sigmab.pro/#/rs/en12xeNDPE/ryJDz2KDge\\n\\n" +
                        "Depois envie aqui o mesmo e-mail usado no cadastro.")
                .putString("msg_email", "Envie o e-mail cadastrado na sua revenda.")
                .putString("msg_confirm", "Serão adicionados 50 créditos. Digite CONFIRMAR para continuar.")
                .putString("msg_credit_ok", "✅ Foram adicionados 50 créditos à sua revenda.")
                .putString("msg_reseller_ok", "✅ Revenda localizada e 50 créditos iniciais adicionados.")
                .putString("msg_panel_error", "Não consegui confirmar a operação. Ela ficou registrada para conferência e não será repetida automaticamente.")
                .putString("msg_private", "Para proteger seus dados, envie esta solicitação no privado do atendimento.")
                .putString("msg_support", "Um atendente continuará seu atendimento.")
                .putString("group_menu",
                        "🤖 *MASTER RESPONDE — CENTRAL DE SUPORTE*\\n\\n" +
                        "1️⃣ Tutoriais\\n" +
                        "2️⃣ Promoções e Planos\\n" +
                        "3️⃣ Aplicativos Parceiros\\n" +
                        "4️⃣ Banners\\n" +
                        "5️⃣ Avisos\\n" +
                        "6️⃣ Apresentação do Servidor\\n" +
                        "7️⃣ Solicitar 50 Créditos\\n" +
                        "8️⃣ Gerar Teste\\n" +
                        "0️⃣ Falar com Suporte")
                .apply();
    }

    public static boolean bot(Context c) { return p(c).getBoolean("bot", false); }
    public static void bot(Context c, boolean v) { p(c).edit().putBoolean("bot", v).apply(); }

    public static String get(Context c, String k, String d) { return p(c).getString(k, d); }
    public static void put(Context c, String k, String v) { p(c).edit().putString(k, v).apply(); }
    public static int getInt(Context c, String k, int d) { return p(c).getInt(k, d); }
    public static void putInt(Context c, String k, int v) { p(c).edit().putInt(k, v).apply(); }

    public static void panelLogin(Context c, String user, String pass) {
        SecureStore.put(c, "panel_user", user == null ? "" : user.trim());
        SecureStore.put(c, "panel_pass", pass == null ? "" : pass);
        p(c).edit().putBoolean("panel_connected", false).apply();
    }
    public static String panelUser(Context c) { return SecureStore.get(c, "panel_user"); }
    public static String panelPass(Context c) { return SecureStore.get(c, "panel_pass"); }
    public static boolean hasPanelLogin(Context c) {
        return panelUser(c).length() > 0 && panelPass(c).length() > 0;
    }
    public static void panelConnected(Context c, boolean v) {
        p(c).edit().putBoolean("panel_connected", v).apply();
    }
    public static boolean panelConnected(Context c) {
        return p(c).getBoolean("panel_connected", false);
    }

    public static List<ResponseItem> items(Context c) {
        List<ResponseItem> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("items", "[]"));
            for (int x=0; x<a.length(); x++) {
                JSONObject o = a.optJSONObject(x);
                if (o != null) out.add(ResponseItem.fromJson(o));
            }
        } catch (Exception ignored) {}
        Collections.sort(out, new Comparator<ResponseItem>() {
            @Override public int compare(ResponseItem a, ResponseItem b) {
                return Integer.compare(a.order, b.order);
            }
        });
        return out;
    }

    public static List<ResponseItem> items(Context c, String category) {
        List<ResponseItem> out = new ArrayList<>();
        for (ResponseItem i : items(c)) {
            if (i.enabled && category.equals(i.category)) out.add(i);
        }
        return out;
    }

    public static void saveItem(Context c, ResponseItem item) {
        if (item.id == null || item.id.length() == 0) item.id = UUID.randomUUID().toString();
        List<ResponseItem> all = items(c);
        boolean found = false;
        for (int x=0; x<all.size(); x++) {
            if (item.id.equals(all.get(x).id)) {
                all.set(x, item);
                found = true;
                break;
            }
        }
        if (!found) all.add(item);
        JSONArray a = new JSONArray();
        for (ResponseItem i : all) a.put(i.toJson());
        p(c).edit().putString("items", a.toString()).apply();
    }

    public static void deleteItem(Context c, String id) {
        JSONArray a = new JSONArray();
        for (ResponseItem i : items(c)) if (!id.equals(i.id)) a.put(i.toJson());
        p(c).edit().putString("items", a.toString()).apply();
    }

    public static List<BotRule> rules(Context c) {
        List<BotRule> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(p(c).getString("rules", "[]"));
            for (int x=0; x<a.length(); x++) {
                JSONObject o = a.optJSONObject(x);
                if (o != null) out.add(BotRule.fromJson(o));
            }
        } catch (Exception ignored) {}
        return out;
    }

    public static void saveRule(Context c, BotRule r) {
        if (r.id == null || r.id.length() == 0) r.id = UUID.randomUUID().toString();
        List<BotRule> all = rules(c);
        boolean found = false;
        for (int x=0; x<all.size(); x++) {
            if (r.id.equals(all.get(x).id)) {
                all.set(x, r);
                found = true;
                break;
            }
        }
        if (!found) all.add(r);
        JSONArray a = new JSONArray();
        for (BotRule b : all) a.put(b.toJson());
        p(c).edit().putString("rules", a.toString()).apply();
    }

    public static void deleteRule(Context c, String id) {
        JSONArray a = new JSONArray();
        for (BotRule b : rules(c)) if (!id.equals(b.id)) a.put(b.toJson());
        p(c).edit().putString("rules", a.toString()).apply();
    }

    public static void state(Context c, String key, String value) {
        p(c).edit().putString("state_" + hash(key), value).apply();
    }
    public static String state(Context c, String key) {
        return p(c).getString("state_" + hash(key), "");
    }
    public static void clearState(Context c, String key) {
        p(c).edit().remove("state_" + hash(key)).apply();
    }

    public static void link(Context c, String key, String email) {
        p(c).edit().putString("link_" + hash(key), email.toLowerCase(Locale.ROOT)).apply();
    }
    public static String linked(Context c, String key) {
        return p(c).getString("link_" + hash(key), "");
    }

    public static long lastTest(Context c, String key) {
        return p(c).getLong("test_" + hash(key), 0L);
    }
    public static void lastTest(Context c, String key, long when) {
        p(c).edit().putLong("test_" + hash(key), when).apply();
    }

    public static void history(Context c, String type, String who, String detail, boolean ok) {
        try {
            JSONArray old = new JSONArray(p(c).getString("history", "[]"));
            JSONObject o = new JSONObject();
            o.put("time", System.currentTimeMillis());
            o.put("type", type);
            o.put("who", who == null ? "" : who);
            o.put("detail", detail == null ? "" : detail);
            o.put("ok", ok);
            old.put(o);
            JSONArray trimmed = new JSONArray();
            int start = Math.max(0, old.length() - 200);
            for (int x=start; x<old.length(); x++) trimmed.put(old.get(x));
            p(c).edit()
                    .putString("history", trimmed.toString())
                    .putString("last_activity", type + " • " + (ok ? "OK" : "PENDENTE"))
                    .apply();
        } catch (Exception ignored) {}
    }

    public static JSONArray history(Context c) {
        try { return new JSONArray(p(c).getString("history", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }
    public static void clearHistory(Context c) { p(c).edit().remove("history").apply(); }
    public static String lastActivity(Context c) {
        return p(c).getString("last_activity", "Nenhuma");
    }

    public static int queueCount(Context c) {
        try { return new JSONArray(p(c).getString("queue", "[]")).length(); }
        catch (Exception e) { return 0; }
    }

    public static synchronized void enqueue(Context c, JSONObject task) {
        try {
            JSONArray a = new JSONArray(p(c).getString("queue", "[]"));
            a.put(task);
            p(c).edit().putString("queue", a.toString()).commit();
        } catch (Exception ignored) {}
    }

    public static synchronized JSONObject dequeue(Context c) {
        try {
            JSONArray a = new JSONArray(p(c).getString("queue", "[]"));
            if (a.length() == 0) return null;
            JSONObject first = a.optJSONObject(0);
            JSONArray next = new JSONArray();
            for (int x=1; x<a.length(); x++) next.put(a.get(x));
            p(c).edit().putString("queue", next.toString()).commit();
            return first;
        } catch (Exception e) {
            return null;
        }
    }

    private static String hash(String value) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return Base64.encodeToString(
                    md.digest((value == null ? "" : value).getBytes("UTF-8")),
                    Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
        } catch (Exception e) {
            return Integer.toHexString((value == null ? "" : value).hashCode());
        }
    }
}
