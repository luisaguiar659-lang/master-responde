package com.masterresponde.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private LinearLayout content;
    private Switch botSwitch;
    private TextView botStatus, waStatus, panelStatus, queueStatus, activityStatus;

    private String pickCategory, pickType, pickTitle;
    private int pickOrder;
    private static final int PICK = 9001;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Store.defaults(this);
        notificationPermission();
        shell();
        dashboard();
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void shell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,9,11));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14),dp(10),dp(10),dp(8));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("logo_master_responde","drawable",getPackageName()));
        top.addView(logo,new LinearLayout.LayoutParams(dp(52),dp(52)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(9),0,0,0);
        titles.addView(txt("MASTER RESPONDE",20,Color.WHITE,true));
        titles.addView(txt("WhatsApp Business • MASTERFLIX",11,Color.rgb(145,155,165),false));
        top.addView(titles,new LinearLayout.LayoutParams(0,dp(58),1f));

        Button home = small("INÍCIO");
        home.setOnClickListener(v -> dashboard());
        top.addView(home);
        root.addView(top);

        View line = new View(this);
        line.setBackgroundResource(id("line"));
        root.addView(line,new LinearLayout.LayoutParams(-1,dp(3)));

        ScrollView sv = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(15),dp(15),dp(15),dp(40));
        sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1f));

        setContentView(root);
    }

    private void dashboard() {
        content.removeAllViews();

        LinearLayout hero = card();
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("logo_master_responde","drawable",getPackageName()));
        row.addView(logo,new LinearLayout.LayoutParams(dp(72),dp(72)));

        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(dp(10),0,0,0);
        h.addView(txt("MASTER RESPONDE",21,Color.WHITE,true));
        h.addView(txt("Central inteligente de atendimento",12,Color.rgb(155,165,175),false));
        row.addView(h,new LinearLayout.LayoutParams(0,dp(76),1f));

        botSwitch = new Switch(this);
        botSwitch.setChecked(Store.bot(this));
        botSwitch.setOnCheckedChangeListener((b,v)->{
            Store.bot(this,v);
            refresh();
        });
        row.addView(botSwitch);
        hero.addView(row);
        content.addView(hero);
        gap(12);

        GridLayout statuses = new GridLayout(this);
        statuses.setColumnCount(2);
        botStatus = status(statuses,"Bot","● Desativado",true,()->botSwitch.setChecked(!botSwitch.isChecked()));
        waStatus = status(statuses,"WhatsApp Business","● Verificando",false,this::openNotificationAccess);
        panelStatus = status(statuses,"MASTERFLIX","● Não configurado",false,this::settingsPage);
        queueStatus = status(statuses,"Fila","0 aguardando",true,null);
        activityStatus = status(statuses,"Última ação","Nenhuma",true,this::historyPage);
        content.addView(statuses);

        gap(18);
        section("ATALHOS");
        GridLayout quick = new GridLayout(this);
        quick.setColumnCount(2);
        quick(quick,"Gerar teste",true,this::manualTest);
        quick(quick,"Nova revenda",false,this::resellerPage);
        quick(quick,"Créditos +50",true,this::manualCredit);
        quick(quick,"@infor grupos",false,this::groupsPage);
        content.addView(quick);

        gap(18);
        section("MÓDULOS");
        GridLayout modules = new GridLayout(this);
        modules.setColumnCount(2);
        module(modules,"Regras",this::rulesPage);
        module(modules,"Mídias",this::mediaPage);
        module(modules,"Revendas",this::resellerPage);
        module(modules,"Grupos",this::groupsPage);
        module(modules,"Histórico",this::historyPage);
        module(modules,"Configurações",this::settingsPage);
        content.addView(modules);

        refresh();
    }

    private void refresh() {
        if (botStatus != null) {
            boolean v = Store.bot(this);
            botStatus.setText(v ? "● Ativo" : "● Desativado");
            botStatus.setTextColor(v ? Color.rgb(0,184,255) : Color.rgb(145,155,165));
        }
        if (waStatus != null) {
            boolean installed = installed("com.whatsapp.w4b");
            boolean access = Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners") != null &&
                    Settings.Secure.getString(getContentResolver(),"enabled_notification_listeners").contains(getPackageName());
            waStatus.setText(!installed ? "● Não instalado" : access ? "● Ativo" : "● Permissão necessária");
            waStatus.setTextColor(installed && access ? Color.rgb(0,184,255) : Color.rgb(255,145,0));
        }
        if (panelStatus != null) {
            boolean has = Store.hasPanelLogin(this), ok = Store.panelConnected(this);
            panelStatus.setText(ok ? "● Conectado" : has ? "● Configurado" : "● Não configurado");
            panelStatus.setTextColor(ok ? Color.rgb(255,145,0) : has ? Color.rgb(0,184,255) : Color.rgb(145,155,165));
        }
        if (queueStatus != null) queueStatus.setText(Store.queueCount(this) + " aguardando");
        if (activityStatus != null) activityStatus.setText(Store.lastActivity(this));
    }

    private void rulesPage() {
        content.removeAllViews();
        section("REGRAS");
        Button add = action("+ ADICIONAR REGRA",true);
        add.setOnClickListener(v->ruleDialog());
        content.addView(add);
        gap(12);

        List<BotRule> list = Store.rules(this);
        if (list.size()==0) {
            content.addView(txt("Nenhuma regra manual cadastrada.",14,Color.rgb(160,170,180),false));
            return;
        }
        for (BotRule r:list) {
            LinearLayout c=card();
            c.addView(txt(r.trigger,16,Color.WHITE,true));
            c.addView(txt(r.category+" • "+r.target+(r.exact?" • exata":" • contém"),12,Color.rgb(150,160,170),false));
            Button del=small("EXCLUIR");
            del.setOnClickListener(v->{Store.deleteRule(this,r.id);rulesPage();});
            c.addView(del);
            content.addView(c); gap(8);
        }
    }

    private void ruleDialog() {
        LinearLayout box=dialogBox();
        EditText trigger=field("Palavra ou frase"); box.addView(trigger);
        Spinner cat=spinner(Store.CATEGORIES); box.addView(cat);
        Spinner target=spinner(new String[]{"Ambos","Privado","Grupo"}); box.addView(target);
        CheckBox exact=new CheckBox(this); exact.setText("Correspondência exata"); box.addView(exact);

        new AlertDialog.Builder(this).setTitle("Nova regra").setView(box)
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton("SALVAR",(d,w)->{
                    if(trigger.getText().toString().trim().length()==0)return;
                    BotRule r=new BotRule();
                    r.trigger=trigger.getText().toString().trim();
                    r.category=String.valueOf(cat.getSelectedItem());
                    r.target=target.getSelectedItemPosition()==1?"PRIVATE":target.getSelectedItemPosition()==2?"GROUP":"BOTH";
                    r.exact=exact.isChecked();
                    Store.saveRule(this,r); rulesPage();
                }).show();
    }

    private void mediaPage() {
        content.removeAllViews();
        section("TEXTOS E MÍDIAS");
        content.addView(txt("Cada categoria aceita várias respostas em sequência.",13,Color.rgb(160,170,180),false));
        gap(10);
        Button add=action("+ ADICIONAR RESPOSTA",true);
        add.setOnClickListener(v->responseDialog());
        content.addView(add); gap(14);

        List<ResponseItem> all=Store.items(this);
        for(String cat:Store.CATEGORIES){
            section(cat.toUpperCase(Locale.ROOT));
            boolean any=false;
            for(ResponseItem i:all){
                if(!cat.equals(i.category))continue;
                any=true;
                LinearLayout c=card();
                c.addView(txt(i.title,16,Color.WHITE,true));
                c.addView(txt(i.type+" • ordem "+i.order,12,Color.rgb(145,155,165),false));
                if(ResponseItem.TEXT.equals(i.type)){
                    TextView t=txt(i.value,13,Color.rgb(205,210,215),false); t.setMaxLines(5); c.addView(t);
                }
                Button del=small("EXCLUIR");
                del.setOnClickListener(v->{Store.deleteItem(this,i.id);mediaPage();});
                c.addView(del); content.addView(c); gap(7);
            }
            if(!any)content.addView(txt("Nenhuma resposta cadastrada.",12,Color.rgb(120,130,140),false));
            gap(12);
        }
    }

    private void responseDialog() {
        LinearLayout box=dialogBox();
        EditText title=field("Nome da resposta"); box.addView(title);
        Spinner cat=spinner(Store.CATEGORIES); box.addView(cat);
        Spinner type=spinner(new String[]{"Texto","Foto","Vídeo","Áudio"}); box.addView(type);
        EditText order=field("Ordem"); order.setInputType(InputType.TYPE_CLASS_NUMBER); box.addView(order);
        EditText value=field("Texto da resposta"); value.setMinLines(3); box.addView(value);

        type.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> p,View v,int pos,long id){value.setVisibility(pos==0?View.VISIBLE:View.GONE);}
            public void onNothingSelected(AdapterView<?> p){}
        });

        new AlertDialog.Builder(this).setTitle("Adicionar resposta").setView(box)
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton("CONTINUAR",(d,w)->{
                    pickTitle=title.getText().toString().trim();
                    if(pickTitle.length()==0)pickTitle="Resposta";
                    pickCategory=String.valueOf(cat.getSelectedItem());
                    try{pickOrder=Integer.parseInt(order.getText().toString().trim());}catch(Exception e){pickOrder=Store.items(this).size()+1;}
                    int pos=type.getSelectedItemPosition();
                    if(pos==0){
                        ResponseItem i=new ResponseItem();
                        i.title=pickTitle;i.category=pickCategory;i.order=pickOrder;i.type=ResponseItem.TEXT;i.value=value.getText().toString();
                        Store.saveItem(this,i);mediaPage();
                    }else{
                        pickType=pos==1?ResponseItem.IMAGE:pos==2?ResponseItem.VIDEO:ResponseItem.AUDIO;
                        Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        in.addCategory(Intent.CATEGORY_OPENABLE);
                        in.setType(pos==1?"image/*":pos==2?"video/*":"audio/*");
                        startActivityForResult(in,PICK);
                    }
                }).show();
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){
            Uri u=data.getData();
            try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            ResponseItem i=new ResponseItem();
            i.title=pickTitle;i.category=pickCategory;i.type=pickType;i.order=pickOrder;i.value=u.toString();
            Store.saveItem(this,i);mediaPage();
        }
    }

    private void resellerPage(){
        content.removeAllViews();section("REVENDAS");
        content.addView(txt("Fluxo automático:\\n\\n• Cliente envia “Quero ser Revenda”.\\n• Bot envia o link de cadastro.\\n• Cliente envia o e-mail.\\n• MASTER RESPONDE pesquisa a revenda.\\n• Adiciona 50 créditos.\\n• Só confirma quando o saldo aumentar exatamente 50.\\n• Vincula a conversa ao e-mail da revenda.\\n\\nPedidos futuros de créditos usam o vínculo já salvo.",14,Color.rgb(205,210,215),false));
        gap(14);
        Button b=action("ADICIONAR 50 CRÉDITOS MANUALMENTE",true);b.setOnClickListener(v->manualCredit());content.addView(b);
    }

    private void groupsPage(){
        content.removeAllViews();section("GRUPOS");
        content.addView(txt("Comando: "+Store.get(this,"group_command","@infor"),15,Color.WHITE,true));gap(8);
        LinearLayout c=card();c.addView(txt(Store.get(this,"group_menu",""),14,Color.rgb(220,225,230),false));content.addView(c);gap(10);
        content.addView(txt("Teste e créditos são direcionados para o privado para evitar expor dados no grupo.",12,Color.rgb(145,155,165),false));
    }

    private void historyPage(){
        content.removeAllViews();section("HISTÓRICO");
        Button clear=small("LIMPAR");clear.setOnClickListener(v->{Store.clearHistory(this);historyPage();});content.addView(clear);gap(10);
        JSONArray a=Store.history(this);
        if(a.length()==0){content.addView(txt("Nenhuma atividade registrada.",14,Color.rgb(150,160,170),false));return;}
        SimpleDateFormat f=new SimpleDateFormat("dd/MM HH:mm",Locale.getDefault());
        for(int i=a.length()-1;i>=0&&i>=a.length()-60;i--){
            JSONObject o=a.optJSONObject(i);if(o==null)continue;
            boolean ok=o.optBoolean("ok");
            LinearLayout c=card();
            c.addView(txt((ok?"✓ ":"! ")+o.optString("type"),15,ok?Color.rgb(0,184,255):Color.rgb(255,100,100),true));
            c.addView(txt(f.format(new Date(o.optLong("time")))+" • "+o.optString("who")+"\\n"+o.optString("detail"),12,Color.rgb(165,175,185),false));
            content.addView(c);gap(7);
        }
    }

    private void settingsPage(){
        content.removeAllViews();section("CONFIGURAÇÕES");

        LinearLayout pc=card();pc.addView(txt("MASTERFLIX",17,Color.WHITE,true));
        EditText user=field("Usuário ou e-mail");user.setText(Store.panelUser(this));pc.addView(user);
        EditText pass=field("Senha");pass.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);pass.setText(Store.panelPass(this));pc.addView(pass);
        Button save=action("SALVAR LOGIN MASTERFLIX",true);
        save.setOnClickListener(v->{Store.panelLogin(this,user.getText().toString(),pass.getText().toString());toast("Login salvo com criptografia do Android.");refresh();});
        pc.addView(save);content.addView(pc);gap(10);

        setting("Comando dos grupos","group_command","@infor",false);
        setting("Palavras para gerar teste","test_triggers","teste,quero um teste",false);
        setting("Palavras para nova revenda","reseller_triggers","quero ser revenda",false);
        setting("Palavras para solicitar créditos","credit_triggers","creditos,solicitar creditos",false);
        settingNumber("Limite de teste em horas (0 = sem limite)","test_limit_hours",0);
        setting("Mensagem: gerando teste","msg_test_wait","",true);
        setting("Mensagem: nova revenda + link","msg_reseller","",true);
        setting("Mensagem: pedir e-mail","msg_email","",true);
        setting("Mensagem: confirmar 50 créditos","msg_confirm","",true);
        setting("Mensagem: crédito concluído","msg_credit_ok","",true);
        setting("Mensagem: revenda ativada","msg_reseller_ok","",true);
        setting("Mensagem: erro do painel","msg_panel_error","",true);
        setting("Mensagem: enviar para privado","msg_private","",true);
        setting("Menu @infor","group_menu","",true);

        Button notif=action("LIBERAR ACESSO ÀS NOTIFICAÇÕES",false);
        notif.setOnClickListener(v->openNotificationAccess());content.addView(notif);gap(10);
        content.addView(txt("O app usa apenas o login normal do MASTERFLIX e não tenta contornar CAPTCHA ou verificação humana.",12,Color.rgb(140,150,160),false));
    }

    private void setting(String label,String key,String def,boolean multi){
        LinearLayout c=card();c.addView(txt(label,13,Color.rgb(255,150,0),true));
        EditText e=field(label);if(multi)e.setMinLines(3);e.setText(Store.get(this,key,def));c.addView(e);
        Button b=small("SALVAR");b.setOnClickListener(v->{Store.put(this,key,e.getText().toString());toast("Salvo.");});c.addView(b);
        content.addView(c);gap(7);
    }

    private void settingNumber(String label,String key,int def){
        LinearLayout c=card();c.addView(txt(label,13,Color.rgb(255,150,0),true));
        EditText e=field(label);e.setInputType(InputType.TYPE_CLASS_NUMBER);e.setText(String.valueOf(Store.getInt(this,key,def)));c.addView(e);
        Button b=small("SALVAR");b.setOnClickListener(v->{try{Store.putInt(this,key,Integer.parseInt(e.getText().toString().trim()));toast("Salvo.");}catch(Exception ex){toast("Número inválido.");}});c.addView(b);
        content.addView(c);gap(7);
    }

    private void manualTest(){
        if(!Store.hasPanelLogin(this)){toast("Configure o login MASTERFLIX primeiro.");settingsPage();return;}
        new AlertDialog.Builder(this).setTitle("Teste do MASTERFLIX")
                .setMessage("Gerar MASTERFLIX TESTE COMPLETO 1H para diagnóstico? O conteúdo ficará no Histórico.")
                .setNegativeButton("CANCELAR",null).setPositiveButton("GERAR",(d,w)->{
                    try{
                        JSONObject o=new JSONObject();o.put("id","manual-test-"+System.currentTimeMillis());o.put("type","TEST");
                        o.put("contactKey","manual");o.put("contactLabel","Manual");o.put("email","");o.put("initial",false);
                        Store.enqueue(this,o);PanelService.start(this);toast("Teste colocado na fila.");
                    }catch(Exception ignored){}
                }).show();
    }

    private void manualCredit(){
        if(!Store.hasPanelLogin(this)){toast("Configure o login MASTERFLIX primeiro.");settingsPage();return;}
        EditText e=field("E-mail exato da revenda");
        new AlertDialog.Builder(this).setTitle("Adicionar 50 créditos").setMessage("Valor fixo: 50 créditos.").setView(e)
                .setNegativeButton("CANCELAR",null).setPositiveButton("CONTINUAR",(d,w)->{
                    String mail=e.getText().toString().trim();if(mail.length()==0)return;
                    try{
                        JSONObject o=new JSONObject();o.put("id","manual-credit-"+System.currentTimeMillis());o.put("type","CREDIT");
                        o.put("contactKey","manual|"+mail);o.put("contactLabel",mail);o.put("email",mail);o.put("initial",false);
                        Store.enqueue(this,o);PanelService.start(this);toast("Operação colocada na fila.");
                    }catch(Exception ignored){}
                }).show();
    }

    private TextView status(GridLayout g,String title,String value,boolean blue,Runnable click){
        LinearLayout c=card();GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(96);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(4),dp(4),dp(4),dp(4));c.setLayoutParams(p);
        c.addView(txt(title,12,Color.rgb(145,155,165),false));
        TextView s=txt(value,15,blue?Color.rgb(0,184,255):Color.rgb(255,145,0),true);s.setPadding(0,dp(9),0,0);c.addView(s);
        if(click!=null)c.setOnClickListener(v->click.run());g.addView(c);return s;
    }

    private void quick(GridLayout g,String label,boolean orange,Runnable r){
        Button b=action(label,orange);GridLayout.LayoutParams p=new GridLayout.LayoutParams();p.width=0;p.height=dp(58);p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(dp(4),dp(4),dp(4),dp(4));b.setLayoutParams(p);b.setOnClickListener(v->r.run());g.addView(b);
    }
    private void module(GridLayout g,String label,Runnable r){quick(g,label,false,r);}

    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(13),dp(13),dp(13),dp(13));c.setBackgroundResource(id("card"));return c;}
    private LinearLayout dialogBox(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(18),dp(8),dp(18),dp(8));return c;}
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(Color.rgb(120,130,140));e.setTextColor(Color.WHITE);e.setTextSize(14);e.setBackgroundResource(id("input"));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(8));e.setLayoutParams(p);return e;}
    private Spinner spinner(String[] values){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values);s.setAdapter(a);s.setBackgroundResource(id("input"));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(5),0,dp(8));s.setLayoutParams(p);return s;}
    private Button action(String label,boolean orange){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setTypeface(null,1);b.setBackgroundResource(id(orange?"orange":"dark_button"));return b;}
    private Button small(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(10);b.setBackgroundResource(id("dark_button"));return b;}
    private TextView txt(String v,int sp,int color,boolean bold){TextView t=new TextView(this);t.setText(v);t.setTextSize(sp);t.setTextColor(color);if(bold)t.setTypeface(null,1);return t;}
    private void section(String s){TextView t=txt(s,12,Color.rgb(255,150,0),true);t.setLetterSpacing(.07f);t.setPadding(0,0,0,dp(7));content.addView(t);}
    private void gap(int n){View v=new View(this);content.addView(v,new LinearLayout.LayoutParams(1,dp(n)));}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private int id(String n){return getResources().getIdentifier(n,"drawable",getPackageName());}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
    private void openNotificationAccess(){startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));}
    private boolean installed(String p){try{getPackageManager().getPackageInfo(p,0);return true;}catch(Exception e){return false;}}
    private void notificationPermission(){if(android.os.Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},77);}
}
