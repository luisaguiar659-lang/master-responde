package com.masterresponde.app;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class RuntimeHub {
    private static final Map<String, ReplyTarget> replies = new ConcurrentHashMap<>();
    private static final Handler main = new Handler(Looper.getMainLooper());

    public static void remember(String key, ReplyTarget target) {
        if (key != null && target != null) replies.put(key, target);
    }

    public static ReplyTarget reply(String key) {
        return replies.get(key);
    }

    public static void sendCategory(final Context c, final String key, String category) {
        final ReplyTarget target = reply(key);
        if (target == null) return;
        List<ResponseItem> list = Store.items(c, category);
        long delay = 0L;
        for (final ResponseItem item : list) {
            delay += 750L;
            main.postDelayed(new Runnable() {
                @Override public void run() {
                    boolean ok;
                    if (ResponseItem.TEXT.equals(item.type)) {
                        ok = target.text(c, item.value);
                    } else {
                        String mime = ResponseItem.IMAGE.equals(item.type) ? "image/*" :
                                ResponseItem.VIDEO.equals(item.type) ? "video/*" : "audio/*";
                        ok = target.media(c, Uri.parse(item.value), mime);
                    }
                    Store.history(c, "RESPOSTA " + item.type, key, item.title, ok);
                }
            }, delay);
        }
    }

    public static void panelResult(Context c, String taskId, String contactKey,
                                   String contactLabel, String type, String email,
                                   boolean initial, boolean ok, String payload, String code) {
        ReplyTarget target = reply(contactKey);

        if ("TEST".equals(type)) {
            if (ok) {
                Store.lastTest(c, contactKey, System.currentTimeMillis());
                if (target != null) target.text(c, payload);
                Store.history(c, "TESTE", contactLabel, "Teste entregue", true);
            } else {
                if (target != null) target.text(c, Store.get(c, "msg_panel_error", "Falha."));
                Store.history(c, "TESTE", contactLabel, code + " • " + payload, false);
            }
            return;
        }

        if ("CREDIT".equals(type)) {
            if (ok) {
                if (email != null && email.length() > 0) Store.link(c, contactKey, email);
                String msg = Store.get(c, initial ? "msg_reseller_ok" : "msg_credit_ok",
                        initial ? "✅ Revenda ativada." : "✅ 50 créditos adicionados.");
                if (target != null) target.text(c, msg);
                Store.clearState(c, contactKey);
                Store.history(c, "CRÉDITOS +50", contactLabel, payload, true);
            } else {
                if (target != null) target.text(c, Store.get(c, "msg_panel_error", "Falha."));
                Store.history(c, "CRÉDITOS +50", contactLabel, code + " • " + payload, false);
            }
        }
    }
}
