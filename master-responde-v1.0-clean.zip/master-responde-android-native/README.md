# MASTER RESPONDE v1.0 CLEAN

Reconstrução completa do projeto, feita do zero.

## Objetivo da reconstrução
A primeira base usava AndroidX e dependências externas. Esta versão foi refeita usando apenas APIs nativas do Android para reduzir problemas de Gradle e compatibilidade.

## Incluído
- Dashboard MASTER RESPONDE.
- WhatsApp Business via NotificationListenerService + RemoteInput.
- Bot liga/desliga.
- Regras manuais.
- Categorias com várias respostas.
- Texto, foto, vídeo e áudio cadastráveis.
- Menu de grupo @infor.
- Teste MASTERFLIX TESTE COMPLETO 1H.
- Nova revenda + 50 créditos.
- Pedido de +50 créditos para revenda já vinculada.
- Fila persistente de tarefas.
- Histórico.
- Login MASTERFLIX criptografado com Android Keystore.
- Verificação de saldo antes/depois do crédito.
- Sem repetição automática quando a transferência fica incerta.
- Teste/crédito de grupo direcionados ao privado.
- Limite de teste configurável; padrão 0 = sem limite.

## Importante
O envio de texto por RemoteInput é o caminho confiável.
Foto/vídeo/áudio só são enviados automaticamente quando a ação de resposta da notificação do WhatsApp Business declarar suporte ao tipo de arquivo.

O projeto não tenta contornar CAPTCHA ou verificação anti-bot.
