MASTER RESPONDE v1.17.15

Base: v1.17.12 estável.

Esta versão preserva o comportamento e o motor da v1.17.12, incluindo a correção que impede a geração de testes em loop.
Não incorpora as alterações experimentais de Sigma genérico das versões v1.17.13/v1.17.14.

Alterações desta versão:
- versionName 1.17.15
- versionCode 59
- texto visual da Dashboard atualizado para v1.17.15
- nenhuma alteração funcional no motor estável da v1.17.12
