MASTER RESPONDE v1.17.12

Correção do motor de teste:
- Mantém o motor antigo funcional reutilizado do backup.
- Corrige loop que gerava testes sem parar.
- Ao finalizar com sucesso ou erro, limpa o estado persistido de teste pendente (BackgroundRuntime.clearTestPending).
- Isso impede o NotificationAccessService de reiniciar automaticamente o mesmo teste após o cleanup.

Versão:
- versionName 1.17.12
- versionCode 56
